-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 05, 2022 at 10:06 AM
-- Server version: 10.3.32-MariaDB-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myamexle_amm_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(225) NOT NULL,
  `sender_id` int(225) NOT NULL,
  `receiver_id` int(225) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_id` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` enum('true','false') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'false',
  `type` enum('text','image','video') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `visible_for_receiver` enum('true','false') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'true',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `sender_id`, `receiver_id`, `message`, `public_id`, `is_read`, `type`, `visible_for_receiver`, `created_at`) VALUES
(1, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 18:46:51'),
(2, 4, 3, 'hi', NULL, 'false', 'text', 'true', '2021-06-03 18:47:53'),
(3, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 19:16:27'),
(4, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 19:48:21'),
(5, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 19:57:37'),
(6, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 20:16:05'),
(7, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 20:30:06'),
(8, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 20:53:02'),
(9, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-03 21:07:26'),
(10, 1, 2, 'hi there, from web', 'urlshiiud', 'false', 'image', 'true', '2021-06-04 07:44:14'),
(11, 5, 4, 'hello ????????????????????????????????', NULL, 'false', 'text', 'true', '2021-06-06 20:37:55'),
(12, 5, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623026288/cwnwk3mryx6jaxz89otq.jpg', 'cwnwk3mryx6jaxz89otq', 'false', 'image', 'true', '2021-06-06 20:38:10'),
(13, 5, 4, 'hello????????????', NULL, 'false', 'text', 'true', '2021-06-06 20:41:01'),
(14, 5, 4, 'hel', NULL, 'false', 'text', 'true', '2021-06-06 20:41:46'),
(15, 4, 5, 'okpor ', NULL, 'false', 'text', 'true', '2021-06-06 20:58:48'),
(16, 5, 4, '????????????', NULL, 'false', 'text', 'true', '2021-06-06 20:59:23'),
(17, 4, 5, '????????????????????????????', NULL, 'false', 'text', 'true', '2021-06-06 20:59:32'),
(18, 5, 4, 'Gbayi bro', NULL, 'false', 'text', 'true', '2021-06-06 21:00:01'),
(19, 5, 4, 'is it possible to delete a message?', NULL, 'false', 'text', 'true', '2021-06-06 21:00:50'),
(20, 4, 5, 'omoh. lemme add that too. I forgot o', NULL, 'false', 'text', 'true', '2021-06-06 21:01:18'),
(21, 4, 5, '????????????????', NULL, 'false', 'text', 'true', '2021-06-06 22:57:58'),
(22, 4, 5, '????????', NULL, 'false', 'text', 'true', '2021-06-06 23:00:19'),
(23, 4, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-06 23:02:01'),
(24, 4, 5, '????????????????', NULL, 'false', 'text', 'true', '2021-06-06 23:02:09'),
(25, 4, 5, '🤲🏾😂', NULL, 'false', 'text', 'true', '2021-06-06 23:07:54'),
(26, 4, 5, 'tesokg messaging', NULL, 'false', 'text', 'true', '2021-06-06 23:08:19'),
(27, 4, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-07 01:11:56'),
(28, 4, 5, 'hi\n', NULL, 'false', 'text', 'true', '2021-06-07 01:17:50'),
(29, 4, 12, 'hi', NULL, 'false', 'text', 'true', '2021-06-11 19:40:22'),
(30, 12, 4, 'hello', NULL, 'false', 'text', 'true', '2021-06-11 19:40:54'),
(31, 12, 4, 'Watsup', NULL, 'false', 'text', 'true', '2021-06-11 19:43:36'),
(32, 4, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-12 06:24:10'),
(33, 4, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-12 06:24:10'),
(34, 5, 4, 'hello', NULL, 'false', 'text', 'true', '2021-06-12 06:27:50'),
(35, 5, 4, 'reply', NULL, 'false', 'text', 'true', '2021-06-12 06:30:51'),
(36, 4, 5, 'hello sir', NULL, 'false', 'text', 'true', '2021-06-12 06:42:05'),
(37, 7, 5, 'hello', NULL, 'false', 'text', 'true', '2021-06-12 09:07:29'),
(38, 7, 5, 'hello', NULL, 'false', 'text', 'true', '2021-06-12 09:07:29'),
(40, 7, 5, 'hello', NULL, 'false', 'text', 'true', '2021-06-12 09:07:31'),
(41, 5, 7, 'bro', NULL, 'false', 'text', 'true', '2021-06-12 09:07:54'),
(42, 7, 5, 'dami', NULL, 'false', 'text', 'true', '2021-06-12 09:08:44'),
(43, 4, 12, 'big man ', NULL, 'false', 'text', 'true', '2021-06-12 23:11:37'),
(44, 4, 12, 'big man ', NULL, 'false', 'text', 'true', '2021-06-12 23:11:37'),
(45, 4, 13, 'hi', NULL, 'false', 'text', 'true', '2021-06-15 11:07:40'),
(46, 4, 13, 'hi', NULL, 'false', 'text', 'true', '2021-06-15 11:07:40'),
(47, 4, 13, 'hello', NULL, 'false', 'text', 'true', '2021-06-15 11:09:50'),
(48, 13, 4, 'Cheeee', NULL, 'false', 'text', 'true', '2021-06-15 11:12:58'),
(49, 14, 9, 'brother', NULL, 'false', 'text', 'true', '2021-06-16 17:58:24'),
(50, 5, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(51, 5, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(52, 5, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(53, 5, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(54, 5, 5, 'hi\n', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(55, 5, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(56, 5, 5, 'hi\n', NULL, 'false', 'text', 'true', '2021-06-18 18:58:51'),
(57, 13, 5, 'hi', NULL, 'false', 'text', 'true', '2021-06-18 19:12:31'),
(58, 5, 13, 'hello ', NULL, 'false', 'text', 'true', '2021-06-18 19:14:52'),
(59, 13, 5, 'it\'s Shola, testing from my emulator', NULL, 'false', 'text', 'true', '2021-06-18 19:16:02'),
(60, 5, 13, 'yeah. I\'m trying to run the app on this end too', NULL, 'false', 'text', 'true', '2021-06-18 19:16:56'),
(61, 5, 13, 'to see if everything now works', NULL, 'false', 'text', 'true', '2021-06-18 19:17:07'),
(62, 13, 5, 'ok boss. I tried to style the pop up but it wasn\'t that easy cos of the plugin I used. ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:08'),
(63, 13, 5, 'I\'m thinking I should take it of since the dot is working fine ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:33'),
(64, 13, 5, 'I\'m thinking I should take it of since the dot is working fine ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:36'),
(65, 13, 5, 'I\'m thinking I should take it of since the dot is working fine ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:43'),
(66, 13, 5, 'I\'m thinking I should take it of since the dot is working fine ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:46'),
(67, 13, 5, 'I\'m thinking I should take it of since the dot is working fine ', NULL, 'false', 'text', 'true', '2021-06-18 19:18:52'),
(68, 5, 13, 'yeah please d9', NULL, 'false', 'text', 'true', '2021-06-18 19:18:59'),
(69, 5, 13, 'do I mean', NULL, 'false', 'text', 'true', '2021-06-18 19:19:04'),
(70, 5, 13, 'it\'s glitching to be honest', NULL, 'false', 'text', 'true', '2021-06-18 19:19:15'),
(71, 5, 13, 'the pop', NULL, 'false', 'text', 'true', '2021-06-18 19:19:19'),
(72, 5, 13, 'you can bring it down now', NULL, 'false', 'text', 'true', '2021-06-18 19:19:30'),
(73, 5, 13, 'like take it off', NULL, 'false', 'text', 'true', '2021-06-18 19:19:37'),
(74, 5, 13, 'like take it off', NULL, 'false', 'text', 'true', '2021-06-18 19:19:38'),
(75, 13, 5, 'ok boss. I will ', NULL, 'false', 'text', 'true', '2021-06-18 19:21:41'),
(76, 5, 13, 'sola', NULL, 'false', 'text', 'true', '2021-06-18 20:24:19'),
(77, 5, 13, 'I told you to increase the age to 100', NULL, 'false', 'text', 'true', '2021-06-18 20:24:32'),
(78, 5, 13, 'also I said put state differently', NULL, 'false', 'text', 'true', '2021-06-18 20:24:47'),
(79, 5, 13, 'and country differently', NULL, 'false', 'text', 'true', '2021-06-18 20:24:58'),
(80, 5, 13, 'you asked me several times', NULL, 'false', 'text', 'true', '2021-06-18 20:25:07'),
(81, 13, 5, 'I\'m sorry. it\'s the api that I\'m using, they merged it but I\'ll try to split and make it work. ', NULL, 'false', 'text', 'true', '2021-06-18 20:30:14'),
(82, 13, 5, 'I\'ll set age to 100 now ', NULL, 'false', 'text', 'true', '2021-06-18 20:31:14'),
(83, 17, 18, 'hello', NULL, 'false', 'text', 'true', '2021-06-20 10:39:49'),
(84, 18, 17, 'hi', NULL, 'false', 'text', 'true', '2021-06-20 10:40:55');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(225) NOT NULL,
  `title` varchar(225) NOT NULL,
  `content` mediumtext NOT NULL,
  `user_id` int(225) NOT NULL,
  `has_user` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `content`, `user_id`, `has_user`, `created_at`) VALUES
(1, 'ibikunle Oluwadamilola ', 'sent you a friend request', 4, 5, '2021-06-06 20:38:43'),
(2, 'Geeky geeky', 'has accepted your friend request', 5, 4, '2021-06-06 20:54:22'),
(10, 'Geeky joe', 'sent you a friend request', 9, 4, '2021-06-11 19:10:44'),
(11, 'Geeky joe', 'sent you a friend request', 9, 4, '2021-06-11 19:14:57'),
(12, 'Geeky joe', 'sent you a friend request', 9, 4, '2021-06-11 19:16:10'),
(13, 'Geeky joe', 'sent you a friend request', 10, 4, '2021-06-11 19:17:08'),
(14, 'Geeky joe', 'sent you a friend request', 12, 4, '2021-06-11 19:38:50'),
(15, 'Sammy sam', 'has accepted your friend request', 4, 12, '2021-06-11 19:39:23'),
(16, 'Geeky joe', 'sent you a friend request', 13, 4, '2021-06-15 11:05:10'),
(17, 'Samuel', 'has accepted your friend request', 4, 13, '2021-06-15 11:06:03'),
(18, 'ibikunle Oluwadamilola ', 'sent you a friend request', 14, 5, '2021-06-18 18:57:16'),
(19, 'ibikunle Oluwadamilola ', 'sent you a friend request', 13, 5, '2021-06-18 18:57:31'),
(20, 'ibikunle Oluwadamilola ', 'sent you a friend request', 5, 5, '2021-06-18 18:58:24'),
(21, 'ibikunle Oluwadamilola ', 'has accepted your friend request', 5, 5, '2021-06-18 18:58:30'),
(22, 'Samuel', 'has accepted your friend request', 5, 13, '2021-06-18 19:12:21'),
(23, 'QA guy', 'sent you a friend request', 17, 18, '2021-06-20 10:38:34'),
(24, 'pecu babalola', 'has accepted your friend request', 18, 17, '2021-06-20 10:39:16'),
(25, 'geeky geeky', 'sent you a friend request', 9, 19, '2021-08-05 15:47:23'),
(26, 'Emmanuel', 'sent you a friend request', 24, 24, '2021-10-21 17:06:01'),
(27, 'Emmanuel', 'sent you a friend request', 24, 24, '2021-10-21 17:09:55'),
(28, 'Emmanuel', 'has accepted your friend request', 24, 24, '2021-10-21 17:12:10');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `photo_url` text NOT NULL,
  `public_id` mediumtext DEFAULT NULL,
  `caption` varchar(180) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `user_id`, `photo_url`, `public_id`, `caption`, `created_at`) VALUES
(1, 3, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1615953577/jxu5h5wv6twvsopcuesk.png', NULL, NULL, '2021-03-17 04:59:36'),
(2, 3, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1615953625/sblxitduwxnuramx3drc.png', NULL, 'some cap', '2021-03-17 05:00:24'),
(3, 3, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1615953779/ovt7wewcmzlrzytieoof.png', NULL, 'some cap', '2021-03-17 05:02:58'),
(4, 5, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623026889/ziaqdjuctvvoqfxovdnr.heic', 'ziaqdjuctvvoqfxovdnr', 'yo guys', '2021-06-06 20:48:12'),
(7, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623094415/elbcdqkx4dxegx1xdg8l.png', 'elbcdqkx4dxegx1xdg8l', NULL, '2021-06-07 20:33:35'),
(8, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623094505/c8rzsoitirg2sjqwh87g.png', 'c8rzsoitirg2sjqwh87g', NULL, '2021-06-07 20:35:05'),
(9, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623095241/tfen9qoxdoqjmmgmqe9k.png', 'tfen9qoxdoqjmmgmqe9k', NULL, '2021-06-07 20:47:22'),
(10, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623099830/xeipozb0aexjyqxpbtxn.png', 'xeipozb0aexjyqxpbtxn', NULL, '2021-06-07 22:03:50'),
(11, 6, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623102341/i7otjoe3kfxddufwtkgm.jpg', 'i7otjoe3kfxddufwtkgm', NULL, '2021-06-07 17:45:42'),
(12, 6, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623102399/krbqsloqekm8pibkbqjj.jpg', 'krbqsloqekm8pibkbqjj', NULL, '2021-06-07 17:46:40'),
(13, 6, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623102449/fjp1oktkqvwvgywkdy2p.jpg', 'fjp1oktkqvwvgywkdy2p', NULL, '2021-06-07 17:47:32'),
(14, 4, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623182500/ysahcqtr3owxlohalnku.jpg', 'ysahcqtr3owxlohalnku', NULL, '2021-06-08 16:01:40'),
(15, 10, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623288488/xyyyeblucmro2bpwexib.jpg', 'xyyyeblucmro2bpwexib', NULL, '2021-06-09 21:28:09'),
(16, 17, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1624200173/j6sogt4b65h4e2mfzr1o.jpg', 'j6sogt4b65h4e2mfzr1o', NULL, '2021-06-20 10:42:54'),
(17, 17, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1624200193/jwxbtn0tatmvvhb8ipqz.jpg', 'jwxbtn0tatmvvhb8ipqz', NULL, '2021-06-20 10:43:13'),
(18, 17, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1624200219/we73ado4hc44b4iyvrux.png', 'we73ado4hc44b4iyvrux', NULL, '2021-06-20 10:43:40'),
(19, 21, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1625928712/wvsyqjqekdka2p089hts.png', 'wvsyqjqekdka2p089hts', NULL, '2021-07-10 10:51:53'),
(20, 21, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1625928733/qx3aeiji0zsl7yf26m5q.jpg', 'qx3aeiji0zsl7yf26m5q', NULL, '2021-07-10 10:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dob` date DEFAULT NULL,
  `is_verified` enum('true','false') NOT NULL DEFAULT 'false',
  `bio` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `likes` text DEFAULT NULL,
  `dislikes` text DEFAULT NULL,
  `church` varchar(225) DEFAULT NULL,
  `doctrine` varchar(225) DEFAULT NULL,
  `city` varchar(225) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `lat` double NOT NULL DEFAULT 0,
  `lng` double NOT NULL DEFAULT 0,
  `signal_id` text DEFAULT NULL,
  `notify` enum('true','false') NOT NULL DEFAULT 'true',
  `gender` enum('male','female') DEFAULT NULL,
  `ethnicity` enum('asian','black_african_descent','east_indian','latino_hispanic','middle_eastern','native_american','pacific_islander','white_caucasian','other') NOT NULL DEFAULT 'other',
  `profile_photo` text DEFAULT NULL,
  `profile_photo_id` text DEFAULT NULL,
  `cover_photo` text DEFAULT NULL,
  `cover_photo_id` text DEFAULT NULL,
  `subscription_status` enum('free','1_month','3_month','none') NOT NULL DEFAULT 'free',
  `subscription_expiry` datetime DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `username`, `email`, `password`, `dob`, `is_verified`, `bio`, `created_at`, `likes`, `dislikes`, `church`, `doctrine`, `city`, `address`, `lat`, `lng`, `signal_id`, `notify`, `gender`, `ethnicity`, `profile_photo`, `profile_photo_id`, `cover_photo`, `cover_photo_id`, `subscription_status`, `subscription_expiry`, `token`) VALUES
(1, 'folahanmi0001', 'folahanmi0001', 'folahanmi0001@gmail.com', '$2b$10$/qZk2CFWi7aTi.pEv6trd.SGCtYvfrcK3JTzYhXuO4zi/Lg3xW/cW', '2014-06-03', 'true', NULL, '2021-03-15 00:55:17', NULL, NULL, NULL, NULL, 'madonna', NULL, 0, 0, NULL, 'true', 'male', 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(3, 'other name', 'someusername', 'someemail@mail.com', '$2b$10$g/P0dAQ7ymdJo2oquRpaNe3lSpb4.muxUnaCjQJVvCCpqFxX8WqfG', '2001-12-05', 'true', NULL, '2021-03-15 01:58:33', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '322614'),
(5, 'ibikunle Oluwadamilola ', 'daminix', 'vistalordz@gmail.com', '$2b$10$XIixRQo6fjQ/yX2jaWE6deKvH37CKqdVzDcn85Hpig1UOO5hBhPQq', '1994-01-17', 'true', 'hsjsjsjejdbrbdhdjrnr rhrurjrnrmr', '2021-06-06 20:28:28', 'football', 'lies', 'baptist', 'Baptist', NULL, NULL, 0, 0, 'c68abbb6-7307-4da2-b5fc-38e45c2b8cde', 'true', 'female', 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623026813/ktmq8y932yulaeuxsjc7.jpg', 'ktmq8y932yulaeuxsjc7', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623026834/pcgzm3sgur7hoqvqtz1q.jpg', 'pcgzm3sgur7hoqvqtz1q', 'none', NULL, NULL),
(6, 'Fadare Solomon', 'fad jr', 'fadare.solomon@yahoo.com', '$2b$10$B2/i6tBzauvy4U9RMCW.9O89HeUhYgA90KeJj3.nQWqABcGUW0qXy', '2000-10-16', 'true', 'Photographer', '2021-06-07 17:13:23', 'Truth ', 'lie and dishonest ', 'baptist', 'Baptist', NULL, NULL, 0, 0, NULL, 'true', 'male', 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623100687/nwozrat1ph6udylq1y2t.jpg', 'nwozrat1ph6udylq1y2t', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623100747/xck7nd1kzokeukl5yqtb.jpg', 'xck7nd1kzokeukl5yqtb', 'none', NULL, NULL),
(7, 'Joshua Adebisi', 'opeyemi', 'adebisijoshua48@gmail.com', '$2b$10$Pnt.vfWYxBJWY28Yqh4bre2B9uGG53wK81a/laF0Lop1yoLvNGGFq', NULL, 'true', NULL, '2021-06-07 20:09:24', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '29ebcdef-f428-4f2f-a96b-65e30ff17380', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(8, 'Maggie', 'maggielove', 'angelicconectionmatchmakers@gmail.com', '$2b$10$OGZjaVC4Gd2nypfTXdCx2eUbHggvs6r.1Taqh9tyoLm5P6G1M.VEW', NULL, 'false', NULL, '2021-06-09 20:47:42', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '334700'),
(9, 'adlibs', 'adlibs', 'daminixdamilola@gmail.com', '$2b$10$VedMJBk0TGsvQz7K9I.SIOTkunWCBEFQRx3R.UchuXQbOXgvGvjWC', '1993-03-03', 'true', 'Creative Artist', '2021-06-09 20:54:10', 'huir', 'devil', 'TFOLC', 'Pentecostal', NULL, NULL, 0, 0, NULL, 'true', 'male', 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(10, 'maggie', 'maggielove33', 'lodav1@yahoo.com', '$2b$10$uw1/zqPUI2WiQ3bwoD7yt.LGCBiFB1yMnwIjvn.KR41dYNLlHGRd2', '1960-01-15', 'true', 'Looking for a 6\' 4\" handsome young Pastor ', '2021-06-09 21:01:21', 'God, good food', 'Dishonesty, devil', 'CAC oke iyan', 'Celestial', NULL, NULL, 0, 0, '9a8512ba-4e5e-4847-8928-0ac3c602e7bc', 'true', NULL, 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623288607/xzza8b55uck0lcuwtygn.jpg', 'xzza8b55uck0lcuwtygn', NULL, NULL, 'none', NULL, NULL),
(11, 'abioye Opeyemi ', 'opy12', 'opyso12@gamil.com', '$2b$10$jUCoBYIJKG9iL1aE.dENSufN7I2SGTKe2ONWrTWuepxPF3QBPsMgy', NULL, 'false', NULL, '2021-06-10 04:27:55', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '851540'),
(12, 'Sammy sam', 'sam', 'opadotunsamuel03@gmail.com', '$2b$10$uWm5ccsGE8GxqQL0xUkZb.gwKhGx8BNmo2LdEAu788iu.SKnCjrq.', NULL, 'true', NULL, '2021-06-11 19:18:54', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '477e4ebe-172d-450c-93e0-9edb7aaea1c6', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(13, 'Samuel', 'samsky', 'samuelomorayewa17@gmail.com', '$2b$10$n4535kYqfXGp8/TBU/3Dqu6ArR5vgA40DA896iAFIvreLC947xnxm', NULL, 'true', 'Hi, I\'m new here', '2021-06-12 00:17:11', NULL, NULL, NULL, NULL, 'Abia State, Nigeria', NULL, 0, 0, '223e4f03-c10d-4686-864e-0d1f2705f7a0', 'true', NULL, 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1623511963/ae28dumr2zrrpelfk4ol.jpg', 'ae28dumr2zrrpelfk4ol', NULL, NULL, 'none', NULL, NULL),
(14, 'afolabi', 'afolabi25', 'afolabiogunleye25@gmail.com', '$2b$10$VgtTEV7vyR.PV.Em72dXfuCk603GiwG9IZLhajWAFj1HyRadYxqKa', NULL, 'true', NULL, '2021-06-16 17:53:57', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '79cc2021-8fbf-4fdd-8740-ba248275a87e', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(15, 'edeh benita', 'benny', 'edehbenita@gmail.com', '$2b$10$3pz8AslmduDuQyJhL/R0y.ahA2JZtLgOiIJBBnK.bB1pIgjIYf.y6', NULL, 'false', NULL, '2021-06-20 09:07:18', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '284362'),
(16, 'edeh benita', 'benni', 'edehbenita97@gmail.com', '$2b$10$c5YA0/mKsUZg0/YuHFd40OY3RLvkZFnevvLiGhtyISQIV8frZnKeW', NULL, 'true', NULL, '2021-06-20 09:09:21', NULL, NULL, NULL, 'Pentecostal', NULL, NULL, 0, 0, 'a43ad61e-4151-4449-ad76-b6a3fb72675d', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(17, 'pecu babalola', 'peculiar', 'peculiarbabalola@gmail.com', '$2b$10$IMhqQ2znuFwCC/l2iDEHoOVbiAwg9J6cvgS06wFNI.HZZ.s7BXwD6', NULL, 'true', NULL, '2021-06-20 10:31:01', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '7fa68b86-fe56-4921-9743-554afc122c76', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(18, 'QA guy', 'qa', 'dataslid@gmail.com', '$2b$10$33FqYOCINwZXYTfUeuZtEu2JDHpxx/5k3vrUePC52EeULO/shmh62', NULL, 'true', NULL, '2021-06-20 10:33:27', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '337cd015-922c-430b-bbec-f32ae7b82a04', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(19, 'geeky geeky', 'geeky', 'tobyolushola@gmail.com', '$2b$10$/F/aXrorNm4zxdD1TpPIrOzeNUO9TwM6WJ1.dxz3GGFOiKAlDzeoS', NULL, 'true', NULL, '2021-06-20 11:28:02', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 'a25fed91-542c-428c-959b-d54e031cd205', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '193857'),
(20, 'oginni olatunde', 'bigtuna', 'adlibsdirect@gmail.com', '$2b$10$j5xmISh2qHJQ.t.fgoodcuuZArrsLDyK0fHcCNRNmUM/qS7XZNdgy', NULL, 'true', NULL, '2021-06-26 18:31:14', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 'c68abbb6-7307-4da2-b5fc-38e45c2b8cde', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(21, 'Juliet Wilson', 'julz', 'aishatadebayor0@gmail.com', '$2b$10$6c7jmZxdeKpLWY8aQ.Pv3esPRGMQ9X/t5PRX.UdJwu0TG8VUNJ81q', NULL, 'true', NULL, '2021-07-10 10:47:54', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 'aea639fe-df50-4ab3-85fc-730fc83d3e86', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(22, 'Temidayo Adefioye ', 'temidjoy', 'temidjoy@gmail.com', '$2b$10$DUCe3P/Q84Lxb/twXO/xxumxO6DeCdIMc1usltkSXvQ3NQX7.1rZO', NULL, 'true', NULL, '2021-09-16 10:26:30', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '994ba0e8-936f-11ec-9c66-0e2cb7d3f376', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(23, 'Famutimi Olayinka', 'smartyinkuse', 'olayinkafamutimi@gmail.com', '$2b$10$66KE2QomSpN5JTDv8k5GsOEfPmBUuFMWT7aKmUT/oCFzZ5vkrfQdS', NULL, 'false', NULL, '2021-10-14 09:00:13', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '261070'),
(24, 'Emmanuel', 'iimmaa', 'iimmaannuueell@live.com', '$2b$10$JH9rrxr/1tblXa8BzxMo9.Vi6/OtPXwv0nM19AQGjZYMXQwGyl6qG', '1990-01-25', 'true', NULL, '2021-10-20 17:12:25', NULL, NULL, 'Dominion City', 'Pentecostal', 'Lagos, Nigeria', NULL, 0, 0, '6083600f-fbc1-48dc-aa1b-8ded610099c1', 'true', 'male', 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(25, 'Facebook', 'fb', 'fb@gmail.com', '$2b$10$RGs.v2.OMUIqQzGZ33Jjsu5rcUfo7W1SmkBs0GeZUiFq./9P9mUQ6', NULL, 'false', NULL, '2021-11-05 02:58:44', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, '718310'),
(26, 'Moses Omobolaji', 'omobolaji', 'omobolaji.moses@gmail.com', '$2b$10$gVy/RMieDf0m55En8xT8BOOsMtSAqPHL/T2a0JVJw7YMq7VIBJrxy', NULL, 'true', NULL, '2021-11-05 14:04:59', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 'a84d28b3-0345-4fc1-b434-d6ffb906151e', 'true', NULL, 'other', NULL, NULL, 'https://res.cloudinary.com/geeky-bucket/image/upload/v1636135747/urjupjymapm0bzitvm3y.jpg', 'urjupjymapm0bzitvm3y', 'none', NULL, NULL),
(27, 'josh', 'josh', 'josh@yopmail.com', '$2b$10$xRYrpK5VkoyMlumA.bupRO/SqmeLuQbW7u7RQ8wmyx.2PMvCnSA96', NULL, 'true', NULL, '2021-11-20 09:57:02', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '6083600f-fbc1-48dc-aa1b-8ded610099c1', 'true', NULL, 'other', NULL, NULL, NULL, NULL, 'none', NULL, NULL),
(28, 'Candice Berryhill', 'candice', 'kpopfreak93@gmail.com', '$2b$10$w79BKQdhIqS9JYZGIOaXg.O88gl5kGjog13guHBrrGSCaImk1YE2S', '1993-08-21', 'true', 'I\'m a tomboy and I am recently divorced and I\'m trying to find someone to love', '2021-11-25 19:34:30', 'K-pop, go karting, bowling and mini golf', 'my dislikes are liars, cheaters, alcohol', NULL, 'Baptist', 'Florida, United States', NULL, 0, 0, '877179c1-1b31-48d5-8615-542b729e646b', 'true', 'female', 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1637887048/qkilif9rv3nuird6b7qo.jpg', 'qkilif9rv3nuird6b7qo', NULL, NULL, 'none', NULL, NULL),
(29, 'peff', 'lodav', 'tommtobb@yahoo.com', '$2b$10$bKa6c./PK8FLRc4cqZm3W.6IqrqjeuAEDcWz9z24H4Bdr9wDr.P7i', NULL, 'true', NULL, '2022-02-28 11:15:03', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'true', 'female', 'other', NULL, NULL, NULL, NULL, 'free', '2022-03-07 11:15:03', NULL),
(30, 'Frederic', 'drtommy', 'jw3455663@gmail.com', '$2b$10$tUJJK.HTB.RJPxgTRT.OXOI.Qr0.bEy7o.pyoZDmeNutTW1cA7Bou', NULL, 'true', NULL, '2022-03-03 05:56:43', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '6d807754-9ae0-11ec-9ed7-8e4b15bd1e91', 'true', NULL, 'other', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1646305355/dwfqwotuxerlrdplvumq.jpg', 'dwfqwotuxerlrdplvumq', 'https://res.cloudinary.com/geeky-bucket/image/upload/v1646305384/w94iwrlrzu5ubrpd96m6.jpg', 'w94iwrlrzu5ubrpd96m6', 'free', '2022-03-10 05:56:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usersfriends`
--

CREATE TABLE `usersfriends` (
  `id` int(225) NOT NULL,
  `sender_id` int(225) NOT NULL,
  `receiver_id` int(225) NOT NULL,
  `status` enum('true','false') NOT NULL DEFAULT 'false',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersfriends`
--

INSERT INTO `usersfriends` (`id`, `sender_id`, `receiver_id`, `status`, `created_at`) VALUES
(1, 19, 9, 'false', '2021-08-05 15:47:23'),
(3, 24, 24, 'true', '2021-10-21 17:09:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `usersfriends`
--
ALTER TABLE `usersfriends`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `usersfriends`
--
ALTER TABLE `usersfriends`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
