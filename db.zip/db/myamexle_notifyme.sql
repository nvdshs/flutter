-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 05, 2022 at 10:06 AM
-- Server version: 10.3.32-MariaDB-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myamexle_notifyme`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(200) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `role` enum('admin','suspended','super_admin') NOT NULL DEFAULT 'admin',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `fullname`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@admin.com', '$2b$10$V9o0syUmJLcqg1L4IOPHY.oMCwGttI6EzITwZSSjx7T0lu4ggwwvW', NULL, 'admin', '2021-06-21 04:40:59'),
(2, 'superadmin', 'superadmin@admin.com', '$2b$10$V9o0syUmJLcqg1L4IOPHY.oMCwGttI6EzITwZSSjx7T0lu4ggwwvW', NULL, 'super_admin', '2021-06-21 04:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` int(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `created_by`, `created_at`) VALUES
(1, 'hello', 1, '2021-08-13 03:20:51');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `type` enum('event','news') NOT NULL DEFAULT 'event',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `title`, `content`, `type`, `created_at`) VALUES
(1, 'Popular event coming up', '<h4>The event go make sense</h4>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. <b>Lorem</b> Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at <b>dapibus</b> nibh elementum imperdiet. <b>Sed</b> Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris <b>Fusce</b> massa. Vestibulum lacinia arcu eget nulla. Class aptent <b>augue</b> taciti sociosqu ad litora torquent per conubia nostra, <b>sociosqu</b> per inceptos himenaeos. Curabitur <b>taciti</b> sodales ligula in libero. Sed dignissim lacinia nunc. Curabitur tortor. Pellentesque nibh. Aenean quam. In scelerisque sem <b>lacinia</b> at dolor. Maecenas <i>sodales</i> mattis. <b>Aenean</b> Sed convallis tristique sem. Proin ut ligula <b>mattis.</b> vel nunc egestas porttitor. Morbi lectus risus, iaculis vel, suscipit <b>porttitor.</b> quis, <b>egestas</b> luctus <b>egestas</b> non, massa. Fusce ac turpis quis ligula lacinia aliquet. Mauris ipsum. Nulla metus metus, ullamcorper vel, tincidunt <b>turpis</b> sed, euismod <i>Fusce</i> in, nibh. Quisque volutpat condimentum velit. Class <b>sed,</b> aptent taciti <b>nibh.</b> sociosqu ad litora torquent per <i>ullamcorper</i> conubia nostra, per inceptos himenaeos. Nam nec ante. Sed lacinia, urna non tincidunt mattis, tortor neque adipiscing diam, a cursus ipsum ante quis turpis. Nulla facilisi. Ut fringilla. <b>ante</b> Suspendisse <i>non</i> potenti. Nunc feugiat mi a tellus <b>fringilla.</b> consequat imperdiet. Vestibulum sapien. Proin quam. Etiam <i>diam,</i> ultrices. Suspendisse in justo eu <i>mi</i> magna luctus <b>ultrices.</b> suscipit. Sed lectus. Integer euismod <b>Suspendisse</b> lacus luctus <i>consequat</i> magna. Quisque cursus, metus vitae pharetra auctor, sem massa mattis sem, <b>Quisque</b> at interdum magna augue eget diam. Vestibulum ante <i>auctor,</i> ipsum primis <b>at</b> in faucibus orci luctus et ultrices <i>mattis</i> posuere cubilia Curae; Morbi <i>mattis</i> lacinia molestie dui. Praesent blandit dolor. Sed non quam. In vel <i>in</i> mi sit amet <i>molestie</i> augue congue elementum. Morbi in ipsum sit amet pede <b>augue</b> facilisis laoreet. Donec lacus nunc, <b>sit</b> viverra nec.</p>\r\n<p>Date: <strong> 25th of june, 2021 </strong></p>\r\n', 'event', '2021-06-23 10:07:27');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `creator` int(255) DEFAULT NULL,
  `notification_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notification_text` text NOT NULL,
  `notification_sender_ip` varchar(100) DEFAULT NULL,
  `notification_extra` varchar(255) DEFAULT NULL,
  `notification_title` varchar(255) NOT NULL,
  `notification_platform` varchar(50) NOT NULL,
  `notification_where` varchar(150) DEFAULT NULL,
  `is_scheduled` enum('yes','no') NOT NULL DEFAULT 'no',
  `has_category` varchar(200) NOT NULL,
  `notification_success` int(200) NOT NULL DEFAULT 0,
  `notification_fail` int(255) NOT NULL DEFAULT 0,
  `notification_lat` float DEFAULT NULL,
  `notification_lng` float DEFAULT NULL,
  `notification_radius` double NOT NULL DEFAULT 0,
  `notification_start` datetime DEFAULT NULL,
  `notification_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `creator`, `notification_date`, `notification_text`, `notification_sender_ip`, `notification_extra`, `notification_title`, `notification_platform`, `notification_where`, `is_scheduled`, `has_category`, `notification_success`, `notification_fail`, `notification_lat`, `notification_lng`, `notification_radius`, `notification_start`, `notification_expiry`) VALUES
(18, NULL, '2021-06-23 07:23:52', 'Testing notification', NULL, NULL, 'Hello there', 'both', 'world', '', '', 0, 1, NULL, NULL, 0, NULL, NULL),
(19, NULL, '2021-06-23 07:28:33', 'Testing notification', NULL, NULL, 'Hello there', 'both', 'world', '', '', 1, 0, NULL, NULL, 0, NULL, NULL),
(20, NULL, '2021-06-23 07:30:48', 'This was sent from the dashboard', NULL, NULL, 'Weather today', 'both', 'area', '', '', 1, 0, NULL, NULL, 0, NULL, NULL),
(21, NULL, '2021-06-24 06:07:57', 'There will be a mild cloud and possibly rain today. Stay alert and go out with umbrella!', NULL, NULL, 'Weather update today', 'both', 'area', '', '', 2, 0, NULL, NULL, 0, NULL, NULL),
(22, NULL, '2021-09-05 21:53:41', 'some message body', NULL, NULL, 'hello there', 'both', NULL, 'no', '', 0, 0, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notified_users`
--

CREATE TABLE `notified_users` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `notification_id` int(255) NOT NULL,
  `expiry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_email` varchar(200) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `password` varchar(200) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `role` enum('user','suspended') NOT NULL DEFAULT 'user',
  `notify` enum('true','false') NOT NULL DEFAULT 'true',
  `user_android_token` varchar(255) DEFAULT NULL,
  `user_ios_token` varchar(255) DEFAULT NULL,
  `user_date` datetime NOT NULL DEFAULT current_timestamp(),
  `user_lat` decimal(11,7) DEFAULT NULL,
  `user_lon` decimal(11,7) DEFAULT NULL,
  `user_ip` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `fullname`, `password`, `user_name`, `role`, `notify`, `user_android_token`, `user_ios_token`, `user_date`, `user_lat`, `user_lon`, `user_ip`) VALUES
(10, 'test@gmail.com', 'John doe', '$2b$10$RMa/n3nZEcb/wJPlbBp7reFkXU6r89IeqfI1.g.ia/fXocI2Mo7Z2', 'jdoe', 'user', 'true', 'eowzw45lQ6WIvLmjTHVGj6:APA91bELnq4pldpLOjl2fQyNTm2O1EJtoFUiMeMM0fAKmiTFcDM5XHQFWwCQb5-K_RQaCZbxqRkZC7M52NcAOiT7bVexVZ9ozOYJ2NwZvC0SgNmtm9qOPox2-s2s-MWDVbsxqY4ZBQVy', '', '2021-01-16 15:24:00', 8.4444527, 4.5445533, '197.210.65.249'),
(20, 'sam@gmail.com', 'sammy samy', '$2b$10$.6ecVly2ju9/G5LTgcBPg.AQoEXWTRWpkBeFU6xN2q6axUlZTIsBu', 'samyy', 'user', 'true', 'dVReteewQN2ozVnCl6nB7P:APA91bE6hTeQCTnUTtfLfSR-uTOs8EbO72jFFRmxj6I2atTW4QfMUrk_du8tXYnVFpc3y0m1_XprU-pEBpoJRkAWU9dC56mo24QOM09eheEJxJ7EZqJhO9Gqmpdtrqostw78fiHI3Eej', NULL, '2021-06-23 15:34:02', 8.4440106, 4.5432925, ''),
(21, 'toby@gmail.com', 'Toby Olushola', '$2b$10$RMa/n3nZEcb/wJPlbBp7reFkXU6r89IeqfI1.g.ia/fXocI2Mo7Z2', 'geeky', 'user', 'true', 'eeelf49kT9mbxqc_E3R033:APA91bHWVCYqxp3EEVO8qjlht9oS7Z3VdweRHZyqywxE_vpGS3vmlgyrEwFH8XUMN3ZcOZRhKpNS5y2enxkvmzgveQSeaPkw_0aUtNC2WmNU7VOZyEwsQXzJjfEAmi2Lye7Y7Gfq67Z9', NULL, '2021-09-11 16:40:54', NULL, NULL, ''),
(22, 'hello@gmail.com', 'hello hi', '$2b$10$ojS6vTuZVRg3J5jvh1MS5.VPXgyn3eVDFnIyJUJ2t1175S9PUUJ36', 'hello', 'user', 'true', 'eeelf49kT9mbxqc_E3R033:APA91bHWVCYqxp3EEVO8qjlht9oS7Z3VdweRHZyqywxE_vpGS3vmlgyrEwFH8XUMN3ZcOZRhKpNS5y2enxkvmzgveQSeaPkw_0aUtNC2WmNU7VOZyEwsQXzJjfEAmi2Lye7Y7Gfq67Z9', NULL, '2021-09-11 16:55:46', NULL, NULL, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `notified_users`
--
ALTER TABLE `notified_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `notified_users`
--
ALTER TABLE `notified_users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
