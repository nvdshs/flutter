import 'package:amm/app/route_constants.dart';
import 'package:flutter/material.dart';
import 'package:amm/ui/screens/home/users/friends.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'navigation_service.dart';

class OneSignalService {
  static const String APP_ID = "80066dd1-9428-4a41-9574-a98720a2ef83";

  static void init() async {
    await OneSignal.shared.init(OneSignalService.APP_ID, iOSSettings: {
      OSiOSSettings.autoPrompt: false,
      OSiOSSettings.inAppLaunchUrl: false,
    });

    OneSignal.shared
        .setInFocusDisplayType(OSNotificationDisplayType.notification);
    OneSignal.shared
        .setNotificationOpenedHandler((OSNotificationOpenedResult result) {
      // This will be called whenever a notification is opened.
      String title = result.notification.payload.title;
      // result.notification.payload.additionalData;
      if (title == 'New friend request' || title == 'Now friends') {
        NavigationService.instance.navigateToRoute(
          MaterialPageRoute(
            builder: (_) => FriendsScreen(),
          ),
        );
      } else if (title == 'New message') {
        NavigationService.instance.navigateTo(RouteConstants.IndexScreen, 1);
      }
    });
    OneSignal.shared
        .setNotificationReceivedHandler((OSNotification notification) {
      //This will be called whenever a notification is received
    });
    // OneSignal.shared.
  }

  static Future<String> savePlayerId() async {
//Call the required instances.

    try {
      final subState = await OneSignal.shared.getPermissionSubscriptionState();

      final deviceId = subState.subscriptionStatus.userId;
      print(deviceId);
      return deviceId;
    } catch (e) {
      throw e;
    }
  }
}
