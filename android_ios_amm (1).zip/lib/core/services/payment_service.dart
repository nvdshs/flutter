import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart' show BuildContext;
import 'package:http/http.dart' as http;
import 'package:stripe_payment/stripe_payment.dart';
import '../models/response_data.dart';
import '../../ui/utils.dart';

class StripeService {
  static String apiBase = "https://api.myammapp.com/api/v1";
  static String paymentApiUrl =
      "${StripeService.apiBase}/create_payment_intents";
  static Map<String, String> headers = {
    'Authorization': "Bearer 123",
    'Content-Type': "application/json"
  };
  static init() {
    StripePayment.setOptions(StripeOptions(
        publishableKey:
            "pk_test_51Ii8l2LQg4HoRuTfC85LCIixF52d6mlNhAOYdgFkZySz49I8J6DLuKtwE7wik0YQJH8R3Iih1uZTbAZZArWghWVR00APLzXCQR",
        merchantId: "Test",
        androidPayMode: 'test'));
  }

  static Future<ResponseData> payViaExistingCard(BuildContext context,
      {@required String amount,
      @required String currency,
      @required CreditCard card}) async {
    try {
      var paymentMethod =
          await StripePayment.createPaymentMethod(PaymentMethodRequest(
        card: card,
      ));
      //show loading
      progressModal(context);

      var paymentIntent = await _createPaymentIntent(amount, currency);

      var response = await StripePayment.confirmPaymentIntent(PaymentIntent(
          clientSecret: paymentIntent['client_secret'],
          paymentMethodId: paymentMethod.id));
      if (response.status == "succeeded") {
        return ResponseData(true, "Transaction successful");
      } else {
        return ResponseData(false, "Transaction failed. please try again");
      }
    } on PlatformException catch (e) {
      String message = "Something went wrong";
      if (e.code == 'cancelled') message = "Transaction cancelled";
      return ResponseData(false, message);
    } catch (e) {
      return ResponseData(false, "Transaction failed, please try again");
    }
  }

  static Future<ResponseData> payWithNewCard(BuildContext context,
      {@required String amount, String currency = "usd"}) async {
    try {
      var paymentMethod = await StripePayment.paymentRequestWithCardForm(
          CardFormPaymentRequest());
      //show loading
      progressModal(context);

      var paymentIntent = await _createPaymentIntent(amount, currency);

      if (paymentIntent.containsKey("client_secret")) {
        var response = await StripePayment.confirmPaymentIntent(PaymentIntent(
            clientSecret: paymentIntent['client_secret'],
            paymentMethodId: paymentMethod.id));
        if (response.status == "succeeded") {
          return ResponseData(true, "Transaction successful");
        } else {
          return ResponseData(false, "Transaction failed. please try again");
        }
      } else {
        return ResponseData(false, "Unable to charge card. please try again");
      }
    } on PlatformException catch (e) {
      String message = "Something went wrong";
      if (e.code == 'cancelled') message = "Transaction cancelled";
      // return ResponseData(false, message);
      throw message;
    } catch (e) {
      throw "Transaction failed, please try again";
      // return ResponseData(false, "Transaction failed, please try again");
    }
  }

  static Future<ResponseData> payWithNativePay(BuildContext context,
      {@required String amount, String currency = "usd"}) async {
    try {
      var canMakeNativePay = await StripePayment.deviceSupportsNativePay();
      if (canMakeNativePay) {
        var nativePayRequest = await StripePayment.paymentRequestWithNativePay(
          androidPayOptions: AndroidPayPaymentRequest(
            totalPrice: "1.20",
            currencyCode: "USD",
          ),
          applePayOptions: ApplePayPaymentOptions(
            countryCode: 'US',
            currencyCode: 'USD',
            items: [
              ApplePayItem(
                label: 'Angelic match makers premium subscription',
                amount: '10',
              )
            ],
          ),
        );
        if (nativePayRequest.tokenId != null) {
          await StripePayment.completeNativePayRequest();
          return ResponseData(true, "Your subscription payment was successful");
        } else {
          return ResponseData(false, "Unable to confirm payment");
        }
        // print(nativePayRequest.toJson());
      } else {
        return ResponseData(false, "Your device does not support native pay");
      }
      //show loading
      // progressModal(context);

      // var paymentIntent = await _createPaymentIntent(amount, currency);

    } on PlatformException catch (e) {
      String message = "Something went wrong";
      if (e.code == 'cancelled') message = "Transaction cancelled";
      return ResponseData(false, message);
    } catch (e) {
      return ResponseData(false, "Transaction failed, please try again");
    }
  }

  static Future<Map<String, dynamic>> _createPaymentIntent(
      String amount, String currency) async {
    try {
      Map<String, dynamic> body = {
        'amount': amount,
        'currency': currency,
      };
      http.Response response = await http.post(StripeService.paymentApiUrl,
          body: body, headers: StripeService.headers);
      return jsonDecode(response.body);
    } catch (e) {
      print("Error payment intent: ${e.toString()}");
    }
    return {};
  }
}
