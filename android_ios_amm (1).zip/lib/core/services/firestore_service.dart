import 'package:amm/core/models/notification_alert.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final notificationRef =
      FirebaseFirestore.instance.collection("notifications");

  Stream<NotificationAlert> getUserNotification(int uid) {
    return notificationRef
        .where("uid", isEqualTo: uid)
        .limit(1)
        .snapshots()
        .map<NotificationAlert>((e) {
      if (e.docs.isEmpty) {
        return NotificationAlert(false, false);
      } else {
        return NotificationAlert(
          e.docs.first.get("notification") ?? false,
          e.docs.first.get("chat") ?? false,
        );
      }
    });
  }
}
