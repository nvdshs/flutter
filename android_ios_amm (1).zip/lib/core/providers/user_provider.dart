import 'dart:convert';
import 'dart:io';

import 'package:amm/core/models/friend.dart';
import 'package:amm/core/models/friend_preference.dart';
import 'package:amm/core/models/gallery_image.dart';
import 'package:amm/core/models/other_user.dart';
import 'package:amm/core/models/user_notification.dart';
import 'package:amm/core/models/country.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';
import '../models/response_data.dart';

class UserProvider with ChangeNotifier {
  // static const String Baseurl = "http://192.168.43.159:3000/api/v1";
  // static const String Baseurl = "http://192.168.43.194:3000/api/v1";

  // static String Baseurl = Platform.isIOS
  //     ? "http://127.0.0.1:3000/api/v1"
  //     : "http://192.168.43.194:3000/api/v1";
  static const String Baseurl = "https://api.myammapp.com/api/v1";

  Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  /*
  set preferences
 */
  bool _searchPreference = true;
  bool _notificationPreference = true;
  bool _locationPreference = false;
  DateTime _bibleVerseLastShown = DateTime.now();

  bool get searchPreference => _searchPreference;
  bool get notificationPreference => _notificationPreference;
  bool get locationPreference =>
      isSubscriptionActive ? _locationPreference : false;
  DateTime get bibleVerseLastShown => _bibleVerseLastShown;

  void setShownBibleVerseLast() async {
    SharedPreferences pref = await _prefs;
    await pref.setString('bible_verse',
        DateTime.now().add(Duration(hours: 23)).toIso8601String());
  }

  void setNotification(bool value) async {
    SharedPreferences pref = await _prefs;
    _notificationPreference = value;
    await pref.setBool("notify_pref", value);
    notifyListeners();
  }

  void setSearchPreference(bool value) async {
    SharedPreferences pref = await _prefs;
    _searchPreference = value;
    await pref.setBool("search_pref", value);
    notifyListeners();
  }

  void setLocationPreference(bool value) async {
    SharedPreferences pref = await _prefs;
    _locationPreference = value;
    await pref.setBool("location_pref", value);
    notifyListeners();
  }
  /*
  set preferences
 */

  /*
   *  set data fetched properties
   * 
   */
  bool _hasLoadedProfile = false;
  bool _hasFetchedRandomUser = false;
  bool _hasFetchedGallery = false;
  bool get hasFetchedGallery => _hasFetchedGallery;
  bool get hasFetchedRandomUser => _hasFetchedRandomUser;
  /*
   *  set data fetched properties
   * 
   */

  String _userToken;
  User _currentUser;
  FriendPreference _friendPreference;
  List<OtherUser> _randomUsers = [];
  List<OtherUser> _preferenceUsers = [];
  List<OtherUser> _friends = [];
  List<OtherUser> _friendsRequests = [];
  List<UserNotification> _notifications = [];
  List<GalleryImage> _galleryImages = [];

  String get userToken => _userToken;
  User get currentUser => _currentUser;
  FriendPreference get friendPreference => _friendPreference;
  List<OtherUser> get randomUsers => _randomUsers;
  List<OtherUser> get preferenceUsers => _preferenceUsers;
  List<OtherUser> get friends => _friends;
  List<OtherUser> get friendsRequests => _friendsRequests;
  List<UserNotification> get userNotifications => _notifications;
  List<GalleryImage> get galleryImages => _galleryImages;
  bool get isSubscriptionActive =>
      _currentUser.subscriptionExpiry != null &&
      _currentUser.subscriptionExpiry.isAfter(DateTime.now());

  void removeFriendRequest(int index) {
    _friendsRequests.removeAt(index);
    notifyListeners();
  }

  Future<ResponseData> login(String email, String password) async {
    // SharedPreferences sharedPreferences = await _prefs;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // var box = Hive.box('user');

    try {
      var response = await http.post("$Baseurl/users/login", body: {
        'email': email,
        'password': password,
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        await prefs.setString('userdata', json.encode(decodedData['data']));
        await prefs.setString('userkey', decodedData['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());
        await prefs.setString("page", "/");
        _userToken = decodedData['token'];
        _currentUser = User.fromJson(decodedData['data']);
        _hasLoadedProfile = true;
        // notifyListeners();
        print(prefs.getString('userkey'));
        print(prefs.getString('timer'));
        print(decodedData['token'].runtimeType);
      }
      return ResponseData.fromMap(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchUserDetails() async {
    if (_hasLoadedProfile) return;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var response = await http.get(
        "$Baseurl/users/details",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        await prefs.setString('userdata', json.encode(decodedData['data']));
        _currentUser = User.fromJson(decodedData['data']);
        _hasLoadedProfile = true;
      }
      print(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<ResponseData> signup(Map<String, dynamic> data) async {
    try {
      var response = await http.post("$Baseurl/users/signup", body: data);
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;

      return ResponseData.fromMap(decodedData);
    } catch (e) {
      throw e;
    }
  }

  Future<ResponseData> resendVerificationToken(
      Map<String, dynamic> data) async {
    try {
      var response = await http.post(
        "$Baseurl/users/signup/resend_verification",
        body: data,
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;

      return ResponseData.fromMap(decodedData);
    } catch (e) {
      throw e;
    }
  }

  Future<ResponseData> forgotPassword(String email) async {
    try {
      var response = await http.post(
        "$Baseurl/users/forgot_password",
        body: {"email": email},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      print(decodedData);
      return ResponseData.fromMap(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<ResponseData> updateForgotPassword(
      String code, String password) async {
    try {
      var response = await http.post(
        "$Baseurl/users/update_forgot_password",
        body: {
          "token": code,
          "password": password,
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;

      return ResponseData.fromMap(decodedData);
    } catch (e) {
      throw e;
    }
  }

  Future<void> setPreference(String gender, int minAge, int maxAge,
      String doctrine, String city) async {
    SharedPreferences sharedPreferences = await _prefs;
    _friendPreference = FriendPreference(
      gender: gender,
      minAge: minAge,
      maxAge: maxAge,
      doctrine: doctrine,
      city: city,
    );
    await sharedPreferences.setString(
      "friend_pref",
      json.encode(
        _friendPreference.toMap(),
      ),
    );
    notifyListeners();
  }

  Future<ResponseData> verifySignUpToken(String token) async {
    SharedPreferences sharedPreferences = await _prefs;

    try {
      var response = await http.get("$Baseurl/users/verify/$token");
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      await sharedPreferences.setString("page", "/");
      await sharedPreferences.remove("email");

      return ResponseData.fromMap(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchRandomUsers(String filter, double lat, double lng) async {
    try {
      var response = await http.get(
        "$Baseurl/users/random?filter=$filter&lat=$lat&lng=$lng",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        var users = decodedData['data'] as List<dynamic>;
        _randomUsers.clear();
        users.forEach((user) {
          _randomUsers.add(OtherUser.fromJson(user));
        });
        _hasFetchedRandomUser = true;
        notifyListeners();
      }
      print(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<List<OtherUser>> searchUsers(String query) async {
    try {
      final response = await http.get(
        "$Baseurl/users/search/$query",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        var users = decodedData['data'] as List<dynamic>;

        return users.map((user) => OtherUser.fromJson(user)).toList();
      }
      print(decodedData);
      return [];
    } catch (e) {
      throw e;
    }
  }

  Future<void> fetchPreferenceUsers() async {
    if (_friendPreference == null) return;
    try {
      var response = await http.get(
        "$Baseurl/users/preference/search?gender=${_friendPreference.gender}&min_age=${_friendPreference.minAge}&max_age=${_friendPreference.maxAge}&doc=${_friendPreference.doctrine}&city=${_friendPreference.city}",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        var users = decodedData['data'] as List<dynamic>;
        _preferenceUsers.clear();
        users.forEach((user) {
          _preferenceUsers.add(OtherUser.fromJson(user));
        });
        notifyListeners();
      }
      print(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<Friend> fetchUserProfile(int uid) async {
    try {
      var response = await http.get(
        "$Baseurl/users/profile/$uid",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        print(decodedData['data']);
        return Friend.fromJson(decodedData['data']);

        // var users = decodedData['data'] as List<dynamic>;
        // users.forEach((user) {
        //   _randomUsers.add(OtherUser.fromJson(user));
        // });
        // notifyListeners();
      }
      return null;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchNotifications() async {
    try {
      var response = await http.get(
        "$Baseurl/users/notifications",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        print(decodedData['data']);

        var notifications = decodedData['data'] as List<dynamic>;
        _notifications.clear();
        notifications.forEach((user) {
          _notifications.add(UserNotification.fromMap(user));
        });
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> deleteNotification(int id) async {
    try {
      var response = await http.post(
        "$Baseurl/users/notifications/delete",
        body: {'id': id},
        headers: {
          'authorization': 'Bearer $_userToken',
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        _notifications.removeWhere((n) => n.id == id);
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> removeDotNotification(String type) async {
    try {
      var response = await http.put(
        "$Baseurl/users/remove_notification/$type",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      print(decodedData);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<Map<String, dynamic>> updatePassword(
      String oldpass, String newpass) async {
    try {
      final response = await http.post(
        "$Baseurl/users/update_password",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        body: {'oldpassword': oldpass, 'newpassword': newpass},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      return result;
    } catch (e) {
      throw e;
    }
  }

  /*
   * [ UPDATE PROFILE DETAILS PROVIDER ] 
   */
  Future<void> updateSignalToken(String token) async {
    try {
      final response = await http.post(
        "$Baseurl/users/update_push_token",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        body: {'signal_id': token},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      print(result);
    } catch (e) {
      throw e;
    }
  }

  Future<void> updateDob(String dob) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await http.post(
        "$Baseurl/users/update_dob",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        body: {'dob': dob},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }
/*
  Future<void> updateProfile(String data, String type) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await http.post(
        "$Baseurl/users/update_$type",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        body: {type: data},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }
  */

  Future<void> updateUserDetails(String data, String type) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await http.put(
        "$Baseurl/users/update/$type",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        body: {'data': data},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> updateUserSubscription(String subscriptionPlan) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await http.post(
        "$Baseurl/users/upgrade",
        body: {'plan': subscriptionPlan},
        headers: {
          'authorization': 'Bearer $_userToken',
        },
        // body: {'data': data},
      );
      //Get the response from the server
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  /*
   * [ END UPDATE PROFILE DETAILS PROVIDER ] 
   */

  /*
   * [ FRIENDS PROVIDER ] 
   */

  Future<bool> addFriend(int userId) async {
    try {
      var response = await http.post("$Baseurl/users/friends/add", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'userId': userId.toString()
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData.containsKey("success") && decodedData['success'] is bool)
        return decodedData['success'];
      else
        return false;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<bool> acceptFriendRequest(int userId) async {
    try {
      var response = await http.post("$Baseurl/users/friends/accept", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'userId': userId.toString()
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData.containsKey("success") && decodedData['success'] is bool)
        return decodedData['success'];
      else
        return false;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<bool> cancelFriendRequest(int userId) async {
    try {
      var response = await http.post("$Baseurl/users/friends/cancel", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'userId': userId.toString()
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData.containsKey("success") && decodedData['success'] is bool)
        return decodedData['success'];
      else
        return false;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<bool> rejectFriendRequest(int userId) async {
    try {
      var response = await http.post("$Baseurl/users/friends/reject", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'userId': userId.toString()
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData.containsKey("success") && decodedData['success'] is bool)
        return decodedData['success'];
      else
        return false;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<bool> deleteFriend(int userId) async {
    try {
      var response = await http.post("$Baseurl/users/friends/delete", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'userId': userId.toString()
      });
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData.containsKey("success") && decodedData['success'] is bool)
        return decodedData['success'];
      else
        return false;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchFriends() async {
    try {
      var response = await http.get(
        "$Baseurl/users/friends",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        print(decodedData['data']);

        var users = decodedData['data'] as List<dynamic>;
        _friends.clear();
        users.forEach((user) {
          _friends.add(OtherUser.fromJson(user));
        });
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchFriendRequests() async {
    try {
      var response = await http.get(
        "$Baseurl/users/friend_requests",
        headers: {
          'authorization': 'Bearer $_userToken',
        },
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        print(decodedData['data']);

        var users = decodedData['data'] as List<dynamic>;
        _friendsRequests.clear();
        users.forEach((user) {
          _friendsRequests.add(OtherUser.fromJson(user));
        });
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  /*
   * [ END FRIENDS PROVIDER ] 
   */

  /*
   * [ GALLERY PROVIDER ] 
   */

  Future<void> addGalleryImage(File file) async {
    try {
      var request = http.MultipartRequest(
          'POST', Uri.parse("$Baseurl/users/upload/photo"));
      request.files.add(await http.MultipartFile.fromPath('image', file.path));
      // request.fields.addAll({
      //   'caption': caption,
      // });
      request.headers.addAll({
        'authorization': 'Bearer $_userToken',
      });
      var res = await request.send();

      //Get the response from the server

      var responseData = await res.stream.toBytes();
      var responseString = String.fromCharCodes(responseData);
      var result = json.decode(responseString) as Map<String, dynamic>;
      if (result['success'] == true) {
        _galleryImages.add(GalleryImage.fromMap(result['data']));
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> deleteGalleryPhoto(int id, String publicId) async {
    try {
      var response = await http.post("$Baseurl/users/photos/delete", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'photoId': '$id',
        'publicId': publicId
      });
      var result = json.decode(response.body) as Map<String, dynamic>;
      print(result);
      if (result['success'] == true) {
        _galleryImages.removeWhere((i) => i.id == id);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  Future<List<GalleryImage>> _fetchGalleryImages(int uid) async {
    try {
      var response = await http.get(
        "$Baseurl/users/photos/$uid",
        headers: {'authorization': 'Bearer $_userToken'},
      );
      var decodedData = jsonDecode(response.body) as Map<String, dynamic>;
      if (decodedData['success'] == true) {
        var images = decodedData['data'] as List<dynamic>;
        return images.map((e) => GalleryImage.fromMap(e)).toList();
      }
      return null;
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<List<GalleryImage>> fetchUserGalleryImages(int uid) async {
    try {
      return await _fetchGalleryImages(uid);
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<void> fetchLoggedInUserGalleryImages() async {
    try {
      var result = await _fetchGalleryImages(currentUser.uid);
      if (result is List<GalleryImage>) {
        _galleryImages = result;
        _hasFetchedGallery = true;
        notifyListeners();
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }

  /*
   * [ END GALLERY PROVIDER ] 
   */

  /*
   * [ PHOTO PROVIDER ] 
   */

  Future<void> addProfilePhoto(File file) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var request = http.MultipartRequest(
          'POST', Uri.parse("$Baseurl/users/profile_photo/upload"));
      request.files.add(await http.MultipartFile.fromPath('image', file.path));

      request.headers.addAll({
        'authorization': 'Bearer $_userToken',
      });
      var res = await request.send();

      //Get the response from the server

      var responseData = await res.stream.toBytes();
      var responseString = String.fromCharCodes(responseData);
      var result = json.decode(responseString) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> addCoverPhoto(File file) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var request = http.MultipartRequest(
          'POST', Uri.parse("$Baseurl/users/cover_photo/upload"));
      request.files.add(await http.MultipartFile.fromPath('image', file.path));

      request.headers.addAll({
        'authorization': 'Bearer $_userToken',
      });
      var res = await request.send();

      //Get the response from the server

      var responseData = await res.stream.toBytes();
      var responseString = String.fromCharCodes(responseData);
      var result = json.decode(responseString) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> deleteProfilePhoto(String publicId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var response =
          await http.post("$Baseurl/users/profile_photo/delete", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'publicId': publicId
      });
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> deleteCoverPhoto(String publicId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var response =
          await http.post("$Baseurl/users/cover_photo/delete", headers: {
        'authorization': 'Bearer $_userToken',
      }, body: {
        'publicId': publicId
      });
      var result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        await prefs.setString('userdata', json.encode(result['data']));
        await prefs.setString('userkey', result['token']);

        await prefs.setString(
            'timer', DateTime.now().add(Duration(days: 27)).toIso8601String());

        _userToken = result['token'];
        _currentUser = User.fromJson(result['data']);
        notifyListeners();
      }
    } catch (e) {
      throw e;
    }
  }

  /*
   * [ END PHOTO PROVIDER ] 
   */

  void tryLogin(String userData, String token, String date, String friendPref,
      bool searchPref, notifyPref, String bibleVerse) async {
    DateTime dateTime = date == null
        ? DateTime.now().subtract(Duration(seconds: 5))
        : DateTime.parse(date);
    if (DateTime.now().isAfter(dateTime)) {
      SharedPreferences sharedPreferences = await _prefs;
      sharedPreferences.remove('userkey');
      sharedPreferences.remove('userdata');
      sharedPreferences.remove("timer");
      // notifyListeners();
    }
    // print(token);
    if (token != null && userData != null && _currentUser == null) {
      _currentUser = User.fromJson(json.decode(userData));
      _userToken = token;
      _searchPreference = searchPref;
      _notificationPreference = notifyPref;
      _bibleVerseLastShown = bibleVerse == null
          ? DateTime.now().subtract(Duration(seconds: 5))
          : DateTime.parse(date);
      if (friendPref != null)
        _friendPreference = FriendPreference.fromMap(json.decode(friendPref));
      // var t = Timer(dateTime.difference(DateTime.now()), () {});
      // notifyListeners();
    }
  }

  Future<void> logout() async {
    SharedPreferences sharedPreferences = await _prefs;
    sharedPreferences.remove('userkey');
    sharedPreferences.remove('userdata');
    sharedPreferences.remove("timer");
    sharedPreferences.setString("page", "login");
    _hasFetchedRandomUser = false;
    _hasFetchedGallery = false;
    // var box = Hive.box('user');
    // box.delete('userkey');
    // box.delete('userdata');
    notifyListeners();
  }

  Future<List<Country>> getCountryCities() async {
    try {
      var response = await http
          .get("https://countriesnow.space/api/v0.1/countries/states");
      var decoded = json.decode(response.body) as Map<String, dynamic>;
      List<Country> allCountries = [];
      if (decoded.containsKey("error") && decoded['error'] == false) {
        var data = decoded['data'] as List<dynamic>;
        print(data);
        allCountries = data
            .map(
              (c) => Country(c['name'],
                  c['states'].map((e) => e['name']).toList().cast<String>()),
            )
            .toList();

        print(allCountries.length);
        return allCountries;
      } else {
        return [];
      }
    } catch (e) {
      print(e);
      throw e;
    }
  }
}
