import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';

import 'user_provider.dart';

class ChatProvider with ChangeNotifier {
  UserProvider _userProvider;

  static const Baseurl = "https://api.myammapp.com/api/v1";
  // static String Baseurl = Platform.isIOS
  //     ? "http://127.0.0.1:3000/api/v1"
  //     : "http://192.168.43.194:3000/api/v1";

  void update(UserProvider userProvider) {
    // Do some custom work based on userProvider that may call `notifyListeners`
    _userProvider = userProvider;
  }

  int get userId => _userProvider.currentUser.uid;

  List<ChatMessage> _recentChats = [];

  List<ChatMessage> get recentChats => _recentChats;

  Future<void> fetchRecentChats() async {
    try {
      final response = await http.get(
        "$Baseurl/users/recent_chats",
        headers: {'authorization': 'Bearer ${_userProvider.userToken}'},
      );
      final result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        var chats = result['data'] as List<dynamic>;
        _recentChats.clear();
        chats.forEach((chat) {
          _recentChats.add(ChatMessage.fromMap(chat));
        });
        // _recentChats.sort();
      }
      notifyListeners();
      print(result);
    } catch (e) {
      throw e;
    }
  }

  Future<List<ChatMessage>> fetchChatMessage(String uid) async {
    try {
      final response = await http.get(
        "$Baseurl/users/chat/$uid",
        headers: {'authorization': 'Bearer ${_userProvider.userToken}'},
      );
      final result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        var chats = result['data'] as List<dynamic>;
        if (chats.isNotEmpty) print(chats.last);
        return chats.map((chat) => ChatMessage.fromMap(chat)).toList();
        // chats.forEach((chat) {
        //   _recentChats.add(ChatMessage.fromMap(chat));
        // });
      }
      return [];
    } catch (e) {
      print(e);
      throw e;
    }
  }

  Future<Map<String, dynamic>> fetchMoreChatMessage(
      String uid, int page) async {
    print("Current Page: ${page + 1}");
    try {
      final response = await http.get(
        "$Baseurl/users/chat/$uid?page=${page + 1}",
        headers: {'authorization': 'Bearer ${_userProvider.userToken}'},
      );
      final result = json.decode(response.body) as Map<String, dynamic>;
      if (result['success'] == true) {
        var chats = result['data'] as List<dynamic>;
        print(chats.last);
        List<ChatMessage> theMessages =
            chats.map((chat) => ChatMessage.fromMap(chat)).toList();
        return {
          'hasdata': result['hasData'],
          'messages': theMessages,
          'page': int.tryParse(result['currentPage']) ?? page + 1
        };
        // chats.forEach((chat) {
        //   _recentChats.add(ChatMessage.fromMap(chat));
        // });
      }
      return {};
    } catch (e) {
      throw e;
    }
  }

  Future<Map<String, dynamic>> addChatImage(File file) async {
    try {
      var request =
          http.MultipartRequest('POST', Uri.parse("$Baseurl/users/chat/photo"));
      request.files.add(await http.MultipartFile.fromPath('image', file.path));
      request.headers.addAll({
        'authorization': 'Bearer ${_userProvider.userToken}',
      });
      var res = await request.send();

      //Get the response from the server

      var responseData = await res.stream.toBytes();
      var responseString = String.fromCharCodes(responseData);
      var result = json.decode(responseString) as Map<String, dynamic>;
      if (result['success'] == true) {
        return {
          'url': result['data']['photo_url'],
          'public_id': result['data']['public_id'],
        };
      }
      return {};
    } catch (e) {
      throw e;
    }
  }

  Future<bool> deleteUserChat(int chatId) async {
    try {
      final response = await http.delete(
        "$Baseurl/users/chat/$chatId",
        headers: {'authorization': 'Bearer ${_userProvider.userToken}'},
      );
      final result = json.decode(response.body) as Map<String, dynamic>;
      print(result);
      return result['success'] is bool ? result['success'] : false;
    } catch (e) {
      throw e;
    }
  }
}
