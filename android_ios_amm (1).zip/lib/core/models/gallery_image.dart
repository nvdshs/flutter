class GalleryImage {
  final int id;
  final String url;
  final String publicId;
  final String caption;

  GalleryImage.fromMap(Map<String, dynamic> data)
      : id = data['id'],
        url = data['photo_url'],
        publicId = data['public_id'],
        caption = data['caption'];
}
