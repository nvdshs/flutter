class User {
  final int uid;
  final String name;
  final String username;
  final DateTime dob;
  final String email;
  final DateTime joinedOn;
  final String likes;
  final String dislikes;
  final String bio;
  final String church;
  final String doctrine;
  final String city;
  final String gender;
  final String ethnicity;
  final String photo;
  final String photoId;
  final String cover;
  final String coverId;
  final String subscriptionStatus;
  final DateTime subscriptionExpiry;

  User.fromJson(Map<String, dynamic> data)
      : uid = data['id'],
        username = data['username'],
        name = data['fullname'],
        email = data['email'],
        dob = data['dob'] == null ? null : DateTime.tryParse(data['dob']),
        joinedOn = DateTime.tryParse(data['created_at']),
        likes = data['likes'],
        dislikes = data['dislikes'],
        bio = data['bio'],
        church = data['church'],
        doctrine = data['doctrine'],
        city = data['city'],
        gender = data['gender'],
        ethnicity = data['ethnicity'],
        photo = data['profile_photo'],
        photoId = data['profile_photo_id'],
        cover = data['cover_photo'],
        coverId = data['cover_photo_id'],
        subscriptionStatus = data['subscription_status'],
        subscriptionExpiry = data['subscription_expiry'] == null
            ? null
            : DateTime.tryParse(data['subscription_expiry']);
}
