class Country {
  final String countryName;
  final List<String> states;

  Country(this.countryName, this.states);
}
