class ChatMessage {
  final int id;
  final int senderId;
  final int receiverId;
  final String username;
  final String photo;
  final String message;
  final String publicId;
  final String isRead;
  final String type;
  final DateTime date;
  ChatMessage.fromMap(Map<String, dynamic> data)
      : id = data['id'],
        senderId = data['sender_id'],
        receiverId = data['receiver_id'],
        photo =
            data.containsKey('profile_photo') ? data['profile_photo'] : null,
        username = data.containsKey('username') ? data['username'] : null,
        message = data['message'],
        publicId = data['public_id'],
        isRead = data['is_read'],
        type = data['type'],
        date = DateTime.tryParse(data['created_at']);
}
