//

class NotificationAlert {
  final bool notification;
  final bool chat;
  NotificationAlert(this.notification, this.chat);
}
