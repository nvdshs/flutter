class ResponseData {
  final bool status;
  final String message;
  ResponseData(this.status, this.message);
  ResponseData.fromMap(Map<String, dynamic> data)
      : status = data['success'],
        message = data['message'];
}
