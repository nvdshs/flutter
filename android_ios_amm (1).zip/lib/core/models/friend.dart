class Friend {
  final int uid;
  final String name;
  final String username;
  final DateTime dob;
  // final String email;
  final String likes;
  final String dislikes;
  final String bio;
  final String church;
  final String doctrine;
  final String city;
  final String gender;
  final String ethnicity;
  final String photo;
  final String cover;
  bool isFriend;
  bool sentFriendRequest;
  bool youSentRequest;

  Friend.fromJson(Map<String, dynamic> data)
      : uid = data['id'],
        username = data['username'],
        name = data['fullname'],
        // email = data['email'],
        dob = data['dob'] == null ? null : DateTime.tryParse(data['dob']),
        // joinedOn = DateTime.tryParse(data['created_at']),
        likes = data['likes'],
        dislikes = data['dislikes'],
        bio = data['bio'],
        church = data['church'],
        doctrine = data['doctrine'],
        city = data['city'],
        gender = data['gender'],
        ethnicity = data['ethnicity'],
        photo = data['profile_photo'],
        cover = data['cover_photo'],
        isFriend = data['is_friend'],
        sentFriendRequest = data['sent_friend_request'],
        youSentRequest = data['you_sent_request'];
}
