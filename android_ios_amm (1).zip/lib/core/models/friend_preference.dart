class FriendPreference {
  final String gender;
  final int minAge;
  final int maxAge;
  final String doctrine;
  final String ethnicity;
  final String city;

  FriendPreference({
    this.gender,
    this.minAge,
    this.maxAge,
    this.city,
    this.ethnicity,
    this.doctrine,
  });

  FriendPreference.fromMap(Map<String, dynamic> data)
      : gender = data['gender'],
        minAge = data['min_age'],
        maxAge = data['max_age'],
        city = data['city'],
        ethnicity = data['ethnicity'],
        doctrine = data['doc'];

  Map<String, dynamic> toMap() => {
        'gender': this.gender,
        'min_age': this.minAge,
        'max_age': this.maxAge,
        'city': this.city,
        'ethnicity': this.ethnicity,
        'doc': this.doctrine,
      };
}
