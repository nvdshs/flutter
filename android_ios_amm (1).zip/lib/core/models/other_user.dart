class OtherUser {
  final int uid;
  final String name;
  final String username;
  final DateTime dob;
  final String email;
  final String city;
  final String gender;
  final String photo;

  OtherUser.fromJson(Map<String, dynamic> data)
      : uid = data['id'],
        username = data['username'],
        name = data['fullname'],
        email = data['email'],
        city = data['city'] == null ? null : data['city'],
        gender = data['gender'] == null ? null : data['gender'],
        dob = data['dob'] == null ? null : DateTime.tryParse(data['dob']),
        photo = data['profile_photo'];
}
