class UserNotification {
  final int id;
  final String title;
  final String content;
  final int hasUser;
  final DateTime date;

  UserNotification.fromMap(Map<String, dynamic> data)
      : id = data['id'],
        title = data['title'],
        content = data['content'],
        hasUser = data['has_user'],
        date = DateTime.tryParse(data['created_at']);
}
