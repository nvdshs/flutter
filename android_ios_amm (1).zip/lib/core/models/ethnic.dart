class Ethnic {
  final String title;
  final String slug;
  Ethnic(this.title, this.slug);
}
