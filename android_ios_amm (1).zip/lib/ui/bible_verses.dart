const List<Map<String, String>> BIBLE_VERSES = [
  {
    'content':
        'For God so loved the world, that he gave up his only begotten son, that whosoever believeth in Him should not perish but have everlasting life.',
    'verse': 'John 3 vs 16',

  },
  {
    'content': 'If we confess our sins, he is faithful and just to forgive us our sins, and to cleanse us from all unrighteousness.',
    'verse': '1 John 1 vs 9'
  },
   {
    'content': 'Cause me to hear thy lovingkindness in the morning; for in thee do I  trust: cause me to know the way wherein I should walk; for I lift up my soul unto thee.',
    'verse': 'Psalm 143 vs 8'
  },
   {
    'content': 'Husbands, love your wives, even as Christ also loved the church, and gave himself for it; That he might sanctify and cleanse it with the washing of water by the word.',
    'verse': 'Ephesians 5 vs 25-26'
  },
   {
    'content': 'And the Lord make you to increase and abound in love one toward another, and toward all men, even as we do toward you.',
    'verse': '1 Thessalonians 3 vs 12'
  },
   {
    'content': 'He that loveth not knoweth not God; for God is love.',
    'verse': '11 John 4 vs 8'
  },
   {
    'content': 'Beloved, if God so loved us, we ought also to love one another.',
    'verse': '1 John 4 vs 11'
  },
];
