import 'dart:io';

import 'package:amm/core/models/ethnic.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';

class AmmColor {
  static const Color blue = Color(0XFF002273);
  static const Color secondaryColor = Color(0XFF6D6E71);
  static const Color black = Color(0XFF1F2021);
  static const Color lightGrey = Color(0XFFEAEAEB);

  static const MaterialColor primaryColor = const MaterialColor(
    0XFFD62828,
    const {
      50: const Color(0XFFD62828),
      100: const Color(0XFFD62828),
      200: const Color(0XFFD62828),
      300: const Color(0XFFD62828),
      400: const Color(0XFFD62828),
      500: const Color(0XFFD62828),
      600: const Color(0XFFD62828),
      700: const Color(0XFFD62828),
      800: const Color(0XFFD62828),
      900: const Color(0XFFD62828)
    },
  );
  static const MaterialColor white = const MaterialColor(
    0XFFFFFFFF,
    const {
      50: const Color(0XFFFFFFFF),
      100: const Color(0XFFFFFFFF),
      200: const Color(0XFFFFFFFF),
      300: const Color(0XFFFFFFFF),
      400: const Color(0XFFFFFFFF),
      500: const Color(0XFFFFFFFF),
      600: const Color(0XFFFFFFFF),
      700: const Color(0XFFFFFFFF),
      800: const Color(0XFFFFFFFF),
      900: const Color(0XFFFFFFFF)
    },
  );
}

class SizeMargin {
  static SizedBox height([double height = 0.0]) {
    return SizedBox(
      height: height,
    );
  }

  static SizedBox width([double width = 0.0]) {
    return SizedBox(
      width: width,
    );
  }

  static double fullScreenHeight(BuildContext context, {double h = 1}) {
    return MediaQuery.of(context).size.height * h;
  }

  static double fullScreenWidth(BuildContext context, {double w = 1}) {
    return MediaQuery.of(context).size.width * w;
  }
}

class FlatProgressButton extends StatelessWidget {
  final GestureTapCallback onPressed;
  final bool isBusy;
  final Color color;
  final Color textColor;
  final String label;
  const FlatProgressButton(
      {Key key,
      this.onPressed,
      this.color = AmmColor.primaryColor,
      this.textColor = Colors.white,
      @required this.label,
      this.isBusy = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      elevation: 0.0,
      minWidth: double.infinity,
      height: 50.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
      color: this.color,
      textColor: this.textColor,
      child: this.isBusy
          ? CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(Colors.white),
            )
          : Text(
              this.label,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
      onPressed: this.isBusy ? () {} : this.onPressed,
    );
  }
}

Widget platformBackButton() {
  return Platform.isIOS ? Icon(Icons.arrow_back_ios) : Icon(Icons.arrow_back);
}

void showToast(String message) {
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      // backgroundColor: Colors.red,
      // textColor: Colors.white,
      fontSize: 16.0);
}

void progressModal(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return WillPopScope(
        onWillPop: () => Future.value(false),
        child: Dialog(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                ),
                SizeMargin.width(8.0),
                const Text("Please wait..."),
              ],
            ),
          ),
        ),
      );
    },
  );
}

void showInfoDialog(BuildContext context, String message) {
  showDialog(
      context: context,
      builder: (_) => AlertDialog(
            content: Text(message),
            actions: [
              MaterialButton(
                elevation: 0.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6.0),
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text("Ok"),
                textColor: Colors.white,
                color: AmmColor.primaryColor,
              ),
            ],
          ));
}

String getEthnicity(String slug) => ethnics
    .firstWhere((e) => e.slug == slug, orElse: () => Ethnic('Other', 'other'))
    .title;

final List<Ethnic> ethnics = [
  Ethnic('Asian', 'asian'),
  Ethnic('Black / African descent', 'black_african_descent'),
  Ethnic('East Indian', 'east_indian'),
  Ethnic('Latino / Hispanic', 'latino_hispanic'),
  Ethnic('Middle Eastern', 'middle_eastern'),
  Ethnic('Native American', 'native_american'),
  Ethnic('Pacific Islander', 'pacific_islander'),
  Ethnic('White / Caucasian', 'white_caucasian'),
];
