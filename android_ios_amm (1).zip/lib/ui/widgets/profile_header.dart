import 'package:amm/ui/utils.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

import 'avatar.dart';
import 'full_screen_background_image.dart';

class ProfileHeader extends StatelessWidget {
  final ImageProvider<dynamic> coverImage;
  final ImageProvider<dynamic> avatar;
  final String title;
  final String subtitle;
  final List<Widget> actions;
  final String coverUrl;
  final String imageUrl;

  const ProfileHeader(
      {Key key,
      @required this.coverImage,
      @required this.coverUrl,
      @required this.imageUrl,
      @required this.avatar,
      @required this.title,
      this.subtitle,
      this.actions})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        GestureDetector(
          onTap: () {
            if (coverUrl != null)
              Navigator.push(
                  context,
                  PageTransition(
                      child: FullScreenBackgroundImage(
                        imageUrl: coverUrl,
                      ),
                      type: PageTransitionType.fade));
          },
          child: Container(
            height: 200,
            decoration: coverImage == null
                ? BoxDecoration(color: AmmColor.primaryColor.withOpacity(0.8))
                : BoxDecoration(
                    image:
                        DecorationImage(image: coverImage, fit: BoxFit.cover),
                  ),
          ),
        ),
        Ink(
          height: 200,
          decoration: BoxDecoration(
            color: Colors.black38,
          ),
        ),
        if (actions != null && actions.length > 0)
          Container(
            width: double.infinity,
            height: 200,
            padding: const EdgeInsets.only(bottom: 0.0, right: 0.0),
            alignment: Alignment.bottomRight,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [actions[0]],
            ),
          ),
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(top: 160),
          child: Column(
            children: <Widget>[
              Stack(
                children: [
                  GestureDetector(
                    onTap: () {
                      if (imageUrl != null)
                        Navigator.push(
                          context,
                          PageTransition(
                              child: FullScreenBackgroundImage(
                                imageUrl: imageUrl,
                              ),
                              type: PageTransitionType.fade),
                        );
                    },
                    child: Avatar(
                      image: avatar,
                      radius: 60,
                      backgroundColor: Colors.white,
                      borderColor: Colors.grey.shade300,
                      borderWidth: 4.0,
                    ),
                  ),
                  if (actions.length > 1)
                    Positioned(
                      bottom: 0,
                      right: -20.0,
                      child: actions[1],
                    )
                ],
              ),
              const SizedBox(height: 4.0),
              Text(title, style: Theme.of(context).textTheme.headline6),
              if (subtitle != null) ...[
                const SizedBox(height: 5.0),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.subtitle1,
                ),
              ]
            ],
          ),
        )
      ],
    );
  }
}
