import 'package:amm/ui/utils.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class DisplayWebview extends StatelessWidget {
  final String url;
  const DisplayWebview({Key key, this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Builder(builder: (BuildContext context) {
      return Scaffold(
          appBar: AppBar(
            backgroundColor: AmmColor.primaryColor,
            elevation: 0.0,
            automaticallyImplyLeading: false,
            leading: IconButton(
                icon: platformBackButton(),
                color: AmmColor.white,
                onPressed: () {
                  Navigator.pop(context);
                }),
          ),
          body: SafeArea(
              child: WebView(
            initialUrl: this.url,
            javascriptMode: JavascriptMode.unrestricted,
            onPageStarted: (String url) {
              print('Page started loading: $url');
              // progressModal(context);
            },
            onPageFinished: (String url) {
              // Navigator.pop(context);
              print('Page finished loading: $url');
            },
          )));
    });
  }
}
