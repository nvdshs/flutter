import 'package:amm/core/models/gallery_image.dart';
import 'package:amm/ui/utils.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class GalleryViewWidget extends StatefulWidget {
  final List<GalleryImage> galleryImages;
  final int currentIndex;
  const GalleryViewWidget({Key key, this.galleryImages, @required this.currentIndex}) : super(key: key);

  @override
  _GalleryViewWidgetState createState() => _GalleryViewWidgetState();
}

class _GalleryViewWidgetState extends State<GalleryViewWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: platformBackButton(),
          onPressed: () {
            Navigator.pop(context);
          },
          color: AmmColor.white,
        ),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
      ),
      body: Center(
        child: CarouselSlider.builder(
          itemCount: widget.galleryImages.length,
          itemBuilder: (BuildContext context, int itemIndex, pageView) =>
              Container(
            alignment: Alignment.center,
            child: Center(
              child: CachedNetworkImage(
                imageUrl: widget.galleryImages[itemIndex].url,
                fit: BoxFit.cover,
              ),
            ),
          ),
          options: CarouselOptions(
            // height: 400,
            aspectRatio: 1,
            viewportFraction: 1,
            initialPage: widget.currentIndex,
            enableInfiniteScroll: false,
            reverse: false,
            // autoPlay: true,
            // autoPlayInterval: Duration(seconds: 3),
            // autoPlayAnimationDuration: Duration(milliseconds: 800),
            autoPlayCurve: Curves.fastOutSlowIn,
            enlargeCenterPage: true,
            scrollDirection: Axis.horizontal,
          ),
        ),
      ),
    );
  }
}
