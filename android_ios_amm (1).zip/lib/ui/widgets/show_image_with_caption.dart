import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';

import '../utils.dart';

class ShowImageWithCaption extends StatefulWidget {
  final File imageFile;
  ShowImageWithCaption(this.imageFile);

  @override
  _ShowImageWithCaptionState createState() => _ShowImageWithCaptionState();
}

class _ShowImageWithCaptionState extends State<ShowImageWithCaption> {
  File endFile;
  String caption;
  @override
  void initState() {
    super.initState();
    endFile = widget.imageFile;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Container(
                // height: SizeMargin.fullScreenHeight(context),
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: FileImage(endFile), fit: BoxFit.cover),
                ),
              ),
            ),
            SizeMargin.height(8.0),
            /*  Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextField(
                onChanged: (val) {
                  if (val.trim().length > 0) {
                    setState(() {
                      caption = val;
                    });
                  } else {
                    setState(() {
                      caption = null;
                    });
                  }
                },
                decoration: InputDecoration(
                  labelText: "Caption",
                  hintText: "Enter your caption",
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black54))
                ),
              ),
            )*/
          ],
        ),
      ),
      floatingActionButton: Container(
        margin: const EdgeInsets.only(top: 16.0),
        child: FloatingActionButton(
          child: Icon(Icons.crop),
          onPressed: _cropImage,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(8.0),
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                height: 40.0,
                child: Text("Cancel"),
                onPressed: () {
                  Navigator.pop(context, false);
                },
                textColor: AmmColor.primaryColor,
                shape: RoundedRectangleBorder(
                    side: BorderSide(
                      color: AmmColor.primaryColor,
                    ),
                    borderRadius: BorderRadius.circular(6.0)),
              ),
            ),
            SizeMargin.width(12.0),
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                height: 40.0,
                child: Text("Upload"),
                onPressed: () {
                  Navigator.pop(
                    context,
                    {'file': endFile, 'caption': caption},
                  );
                },
                color: Colors.green,
                textColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6.0),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<Null> _cropImage() async {
    File croppedFile = await ImageCropper.cropImage(
        sourcePath: widget.imageFile.path,
        aspectRatioPresets: Platform.isAndroid
            ? [
                CropAspectRatioPreset.square,
                CropAspectRatioPreset.ratio3x2,
                CropAspectRatioPreset.original,
                CropAspectRatioPreset.ratio4x3,
                CropAspectRatioPreset.ratio16x9
              ]
            : [
                CropAspectRatioPreset.original,
                CropAspectRatioPreset.square,
                CropAspectRatioPreset.ratio3x2,
                CropAspectRatioPreset.ratio4x3,
                CropAspectRatioPreset.ratio5x3,
                CropAspectRatioPreset.ratio5x4,
                CropAspectRatioPreset.ratio7x5,
                CropAspectRatioPreset.ratio16x9
              ],
        androidUiSettings: AndroidUiSettings(
            toolbarTitle: 'Crop image',
            toolbarColor: AmmColor.primaryColor,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false),
        iosUiSettings: IOSUiSettings(
          title: 'Crop image',
        ));
    if (croppedFile != null) {
      setState(() {
        endFile = croppedFile;
      });
    }
  }
}
