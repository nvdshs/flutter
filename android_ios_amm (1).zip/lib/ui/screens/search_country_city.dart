import 'package:amm/core/models/country.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/ui/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchCountryCity extends StatefulWidget {
  const SearchCountryCity({Key key}) : super(key: key);

  @override
  _SearchCountryCityState createState() => _SearchCountryCityState();
}

class _SearchCountryCityState extends State<SearchCountryCity> {
  List<Country> _allData = [];
  List<String> _results = [];
  bool _isLoading = true;

  var focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  void fetchData() async {
    try {
      var data = await Provider.of<UserProvider>(context, listen: false)
          .getCountryCities();

      if (data is List<Country> && data.isNotEmpty) {
        FocusScope.of(context).requestFocus(focusNode);
        setState(() {
          _allData.addAll(data);
          _isLoading = false;
        });
      } else {
        showToast("Countries and states could not be retrieved");
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      showToast("Countries and states could not be retrieved");
    }
  }

  void _searchData(String input) {
    if (_allData.isEmpty) return;
    if (input.trim().length > 1) {
      _results = [];
      input = input.toLowerCase();
      var countries = <Country>[];
      _allData.forEach((c) {
        var data = c.states
            .where(
              (d) => d.toLowerCase().startsWith(input),
              // (d) => d.toLowerCase().startsWith(input) || d.toLowerCase().contains(input),
            )
            .toList();
        if (data.isNotEmpty) {
          countries.add(Country(c.countryName, data));
        }
      });
      countries.forEach((country) {
        country.states.forEach((city) {
          _results.add("$city, ${country.countryName}");
        });
      });
      setState(() {
        // do nothing but refresh the widget
      });
    } else {
      setState(() {
        _results = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        title: TextField(
          onChanged: _searchData,
          focusNode: focusNode,
          readOnly: _isLoading,
          decoration: InputDecoration(
            hintText: "Enter your state ...",
            border: UnderlineInputBorder(
              borderSide: BorderSide(
                color: AmmColor.primaryColor.withOpacity(0.3),
              ),
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: AmmColor.primaryColor.withOpacity(0.3),
              ),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: AmmColor.primaryColor.withOpacity(0.3),
              ),
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.clear_rounded),
            onPressed: () {
              Navigator.pop(context, null);
            },
          ),
        ],
      ),
      body:
          //  _isLoading
          //     ? Center(child: Text("")
          //         // CircularProgressIndicator(
          //         //   valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
          //         // ),
          //         )
          //     :
          _results.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(36.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.search,
                          size: 80.0,
                        ),
                        SizeMargin.height(12.0),
                        Text(
                          "Get search results relating to your country and/or state ...",
                          style: TextStyle(fontSize: 16.0),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16.0),
                  itemCount: _results.length,
                  itemBuilder: (_, index) {
                    var countryCity = _results[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.pop(context, countryCity);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(countryCity),
                            )
                          ],
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (_, index) => Divider(),
                ),
    );
  }
}
