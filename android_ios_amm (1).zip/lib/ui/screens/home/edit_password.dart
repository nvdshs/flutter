import 'package:amm/core/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../utils.dart';

class EditPasswordScreen extends StatefulWidget {
  @override
  _EditPasswordScreenState createState() => _EditPasswordScreenState();
}

class _EditPasswordScreenState extends State<EditPasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  String oldPass;
  String newPass;
  String newPassA;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0.0,
        leading: IconButton(
            icon: platformBackButton(),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: Text(
          "Change Password",
          style: Theme.of(context).textTheme.headline5,
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Old password",
                style: GoogleFonts.poppins(fontSize: 16.0),
              ),
              SizeMargin.height(4.0),
              TextFormField(
                validator: (val) {
                  if (val.trim().isEmpty) return "This field is required";
                  if (val.trim().length < 6)
                    return "This field must be at least 6 characters";
                  return null;
                },
                onSaved: (val) {
                  oldPass = val;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0XFFE5E5E5),
                  hintText: "Enter your old password",
                  border: OutlineInputBorder(
                      borderRadius: const BorderRadius.all(
                        const Radius.circular(10.0),
                      ),
                      borderSide: BorderSide.none),
                ),
              ),
              SizeMargin.height(16.0),
              Text(
                "New password",
                style: GoogleFonts.poppins(fontSize: 16.0),
              ),
              SizeMargin.height(4.0),
              TextFormField(
                validator: (val) {
                  if (val.trim().isEmpty) return "This field is required";
                  if (val.trim().length < 6)
                    return "This field must be at least 6 characters";
                  return null;
                },
                onSaved: (val) {
                  newPass = val;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0XFFE5E5E5),
                  hintText: "Enter your new password",
                  border: OutlineInputBorder(
                      borderRadius: const BorderRadius.all(
                        const Radius.circular(10.0),
                      ),
                      borderSide: BorderSide.none),
                ),
              ),
              SizeMargin.height(16.0),
              Text(
                "Confirm new password",
                style: GoogleFonts.poppins(fontSize: 16.0),
              ),
              SizeMargin.height(4.0),
              TextFormField(
                validator: (val) {
                  if (val.trim().isEmpty) return "This field is required";
                  if (val.trim().length < 6)
                    return "This field must be at least 6 characters";
                  return null;
                },
                onSaved: (val) {
                  newPassA = val;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0XFFE5E5E5),
                  hintText: "Enter your new password again",
                  border: OutlineInputBorder(
                      borderRadius: const BorderRadius.all(
                        const Radius.circular(10.0),
                      ),
                      borderSide: BorderSide.none),
                ),
              ),
              SizeMargin.height(36.0),
              MaterialButton(
                elevation: 0.0,
                minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                textColor: Colors.white,
                color: AmmColor.primaryColor,
                child: _isLoading
                    ? CircularProgressIndicator()
                    : Text(
                        "Update Password",
                        style: TextStyle(),
                      ),
                onPressed: _isLoading ? () {} : _updatePassword,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _updatePassword() async {
    if (!_formKey.currentState.validate()) return;
    if (newPass != newPassA) {
      showToast("New passwords do not match");
      return;
    }
    setState(() {
      _isLoading = true;
    });
    try {
      //
      var result = await Provider.of<UserProvider>(context, listen: false)
          .updatePassword(oldPass, newPass);
      if (result['success'] == true) {
        _formKey.currentState.reset();
      }
      showToast(result['message']);
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      showToast("Unable to update password, try again!");
      throw e;
    }
  }
}
