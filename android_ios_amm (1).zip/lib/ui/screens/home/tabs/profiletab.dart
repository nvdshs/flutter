import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../../../../core/providers/user_provider.dart';
import '../../../utils.dart';
import '../../../widgets/profile_header.dart';
import '../../../widgets/show_image.dart';
import '../settings.dart';
import '../user_gallery.dart';

class ProfileTab extends StatefulWidget {
  ProfileTab({Key key}) : super(key: key);

  @override
  _ProfileTabState createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final picker = ImagePicker();
  bool _isLoading = true;
  @override
  void initState() {
    super.initState();
    if (Provider.of<UserProvider>(context, listen: false).hasFetchedGallery ==
        false)
      fetchGallery();
    else
      _isLoading = false;
  }

  void fetchGallery() async {
    try {
      await Provider.of<UserProvider>(context, listen: false)
          .fetchLoggedInUserGalleryImages();
      if (this.mounted)
        setState(() {
          _isLoading = false;
        });
    } catch (e) {
      if (this.mounted)
        setState(() {
          _isLoading = false;
        });
      showToast("An error occured");
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Consumer<UserProvider>(
          // consume the user provider
          builder: (_, uProvider, __) {
        var user = uProvider.currentUser;
        return Column(
          children: [
            ProfileHeader(
              imageUrl: user.photo,
              coverUrl: user.cover,
              avatar: user.photo == null
                  ? AssetImage("assets/images/default_user.png")
                  : CachedNetworkImageProvider(user.photo),
              coverImage: user.cover == null
                  ? null
                  : CachedNetworkImageProvider(user.cover),
              title: user.name,
              subtitle: "@${user.username}",
              actions: <Widget>[
                MaterialButton(
                  color: Colors.white,
                  shape: CircleBorder(),
                  elevation: 0,
                  child: Icon(Icons.camera_alt),
                  onPressed: () {
                    _imageBottomSheet("cover", user.cover, user.coverId);
                  },
                ),
                MaterialButton(
                  color: Colors.white,
                  shape: CircleBorder(),
                  elevation: 0,
                  child: Icon(Icons.camera_alt),
                  onPressed: () {
                    _imageBottomSheet("profile", user.photo, user.photoId);
                  },
                ),
              ],
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Text(
                      user.bio ?? 'Add a little info about yourself here',
                      style: GoogleFonts.poppins(
                        color: Color(0XFFA0A0A0),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizeMargin.height(16.0),
                  MaterialButton(
                    elevation: 0.0,
                    minWidth: double.infinity,
                    height: 50.0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    textColor: Colors.white,
                    color: AmmColor.primaryColor,
                    child: Text(
                      "Settings",
                      style: TextStyle(),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => SettingsScreen()));
                    },
                  ),
                  SizeMargin.height(16.0),
                  _tile("Subscription status", user.subscriptionStatus),
                  _tile(
                    "Born on",
                    user.dob == null
                        ? "N/A"
                        : "${DateFormat.yMMMd().format(user.dob)}",
                  ),
                  _tile("Hobbies", user.likes ?? 'N/A'),
                  _tile("Ethnicity", getEthnicity(user.ethnicity) ?? 'other'),
                  _tile("Interests", user.dislikes ?? 'N/A'),
                  _tile("Church", user.church ?? 'N/A'),
                  SizeMargin.height(4.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Photos",
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w600,
                          fontSize: 18.0,
                        ),
                      ),
                      MaterialButton(
                        elevation: 0.0,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => UserGalleryScreen()));
                        },
                        child: Text("Gallery"),
                        textColor: AmmColor.primaryColor,
                        height: 28.0,
                      )
                    ],
                  ),
                  Divider(
                    height: 2.0,
                  ),
                  _isLoading
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: CircularProgressIndicator(
                              valueColor:
                                  AlwaysStoppedAnimation(AmmColor.primaryColor),
                            ),
                          ),
                        )
                      : uProvider.galleryImages.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.image_search,
                                    size: 80.0,
                                  ),
                                  SizeMargin.height(16.0),
                                  Text(
                                    "Your gallery is empty!",
                                    style: TextStyle(fontSize: 18.0),
                                  ),
                                  SizeMargin.height(8.0),
                                  Text(
                                    "Add images to your gallery so that they appear here",
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: Colors.grey,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            )
                          : GridView.builder(
                              padding: const EdgeInsets.only(top: 12.0),
                              itemCount: uProvider.galleryImages.take(8).length,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (BuildContext context, int index) {
                                var image = uProvider.galleryImages
                                    .take(8)
                                    .toList()[index];
                                return Container(
                                  margin: const EdgeInsets.only(
                                      left: 8.0, right: 8.0),
                                  height: 150,
                                  // width: 180.0,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image:
                                          CachedNetworkImageProvider(image.url),
                                    ),
                                  ),
                                );
                              },
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      mainAxisSpacing: 8.0,
                                      childAspectRatio: 1.1),
                            )
                ],
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _tile(String title, String content) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
          ),
          SizeMargin.height(2.0),
          Text(
            content,
            style: GoogleFonts.poppins(fontSize: 12.0),
          ),
        ],
      ),
    );
  }

  void _imageBottomSheet(String type, String url, String publicId) {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10.0),
          topRight: Radius.circular(10.0),
        ),
      ),
      context: context,
      builder: (_) {
        return Container(
          height: 150.0,
          padding: const EdgeInsets.all(36.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  uploadImage(ImageSource.gallery, type);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.file_upload,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Gallery", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
              SizeMargin.width(24.0),
              GestureDetector(
                onTap: () {
                  uploadImage(ImageSource.camera, type);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Camera", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
              if (url != null) ...[
                SizeMargin.width(24.0),
                GestureDetector(
                  onTap: () async {
                    _onLoading();
                    try {
                      if (type == 'profile') {
                        await Provider.of<UserProvider>(context, listen: false)
                            .deleteProfilePhoto(publicId);
                      } else {
                        await Provider.of<UserProvider>(context, listen: false)
                            .deleteCoverPhoto(publicId);
                      }
                      if (Navigator.canPop(context)) Navigator.pop(context);
                      showToast("$type image has been deleted");
                    } catch (e) {
                      if (Navigator.canPop(context)) Navigator.pop(context);
                      showToast("An unknown error occurred, please try again");
                    }
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 24.0,
                        backgroundColor: AmmColor.primaryColor,
                        child: Icon(
                          Icons.delete_forever,
                          color: Colors.white,
                        ),
                      ),
                      SizeMargin.height(6.0),
                      Text("Remove", style: TextStyle(fontSize: 16.0))
                    ],
                  ),
                )
              ]
            ],
          ),
        );
      },
    );
  }

  void uploadImage(ImageSource source, String type) async {
    Navigator.pop(context);
    final PickedFile pickedFile = await picker.getImage(source: source);
    if (pickedFile != null) {
      var result = await Navigator.push(context,
          MaterialPageRoute(builder: (_) => ShowImage(File(pickedFile.path))));
      if (result is File) {
        // if (result)
        updateUserImage(result, type);
        // else
        //   Helper.showToast("Image not uploaded");
      } else {
        showToast("Operation has been cancelled");
      }
    } else {
      showToast("Operation was cancelled");
    }
  }

  void updateUserImage(File image, String type) async {
    _onLoading();
    try {
      if (type == 'profile') {
        await Provider.of<UserProvider>(context, listen: false)
            .addProfilePhoto(image);
      } else {
        await Provider.of<UserProvider>(context, listen: false)
            .addCoverPhoto(image);
      }
      if (Navigator.canPop(context)) Navigator.pop(context);
      showToast("$type image has been updated");
    } catch (e) {
      if (Navigator.canPop(context)) Navigator.pop(context);
      showToast("An unknown error occurred, please try again");
    }
  }

  void _onLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () => Future.value(false),
          child: Dialog(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                  ),
                  SizeMargin.width(8.0),
                  const Text("Please wait..."),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
