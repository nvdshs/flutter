import 'package:amm/app/route_constants.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../utils.dart';

class NotificationsTab extends StatefulWidget {
  NotificationsTab({Key key}) : super(key: key);

  @override
  _NotificationsTabState createState() => _NotificationsTabState();
}

class _NotificationsTabState extends State<NotificationsTab> {
  bool _isLoading = true;
  int selectedId = 0;
  @override
  void initState() {
    super.initState();
    fetchNotifications();
    Provider.of<UserProvider>(context, listen: false)
        .removeDotNotification("notification")
        .then((_) => null)
        .catchError((_) => null);
  }

  void fetchNotifications() async {
    try {
      await Provider.of<UserProvider>(context, listen: false)
          .fetchNotifications();
      setState(() {
        _isLoading = !_isLoading;
      });
    } catch (e) {
      setState(() {
        _isLoading = !_isLoading;
      });
    }
  }

  void deleteNotification() async {
    _onLoading();
    try {
      await Provider.of<UserProvider>(context, listen: false)
          .deleteNotification(selectedId);
      Navigator.pop(context);
      showToast("Deleted successfully");
    } catch (e) {
      Navigator.pop(context);
      showToast("Unable to delete, try again");
    }
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => Future.delayed(Duration(seconds: 6)),
      color: AmmColor.primaryColor,
      child: NestedScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        floatHeaderSlivers: true,
        // slivers:[
        //   Center(
        //     child: Text("Home"),
        //   ),
        // ],
        body: Consumer<UserProvider>(
            //
            builder: (context, uProvider, snapshot) {
          if (_isLoading) return loadingNotifications();
          if (uProvider.userNotifications.isEmpty) return emptyNotification();
          return RefreshIndicator(
            onRefresh: () => Future.delayed(Duration(seconds: 6)),
            color: AmmColor.primaryColor,
            child: ListView.separated(
              padding: const EdgeInsets.only(top: 12.0),
              itemCount: uProvider.userNotifications.length,
              physics: BouncingScrollPhysics(),
              itemBuilder: (BuildContext context, int index) {
                var notif = uProvider.userNotifications[index];
                return ListTile(
                  onLongPress: () {
                    setState(() {
                      selectedId = notif.id;
                    });
                  },
                  selected: notif.id == selectedId,
                  selectedTileColor: AmmColor.primaryColor,
                  onTap: notif.hasUser != null
                      ? () => selectedId == notif.id
                          ? setState(() {
                              selectedId = 0;
                            })
                          : Navigator.pushNamed(
                              context, RouteConstants.UserProfileScreen,
                              arguments: {
                                  'uid': notif.hasUser,
                                  'isFromChat': false
                                })
                      : null,
                  title: Text(notif.title),
                  subtitle: Text(notif.content),
                  trailing: Text(
                    DateFormat.yMEd().format(notif.date),
                    style: TextStyle(fontSize: 12.0, color: Colors.grey),
                  ),
                );
              },
              separatorBuilder: (BuildContext context, int index) => Divider(),
            ),
          );
        }),
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return [
            SliverAppBar(
              // snap: true,
              automaticallyImplyLeading: false,
              // floating: true,
              pinned: true,
              title: Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: Image.asset(
                  "assets/images/logo1.png",
                  width: 80.0,
                ),
              ),
              centerTitle: true,
              toolbarHeight: 65.0,
              bottom: PreferredSize(
                preferredSize: Size.fromHeight(25.0),
                child: Container(
                  // alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.fromLTRB(16.0, 0.0, 16.0, 12.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Notifications",
                        style: GoogleFonts.poppins(
                            fontSize: 18.0,
                            color: AmmColor.secondaryColor,
                            fontWeight: FontWeight.bold),
                      ),
                      if (selectedId > 0)
                        TextButton.icon(
                          // textColor: AmmColor.primaryColor.withOpacity(0.9),
                          onPressed: deleteNotification,
                          label: Text("Delete"),
                          icon: Icon(Icons.delete_forever),
                          // height: 30.0,
                          style: ButtonStyle(
                            minimumSize:
                                MaterialStateProperty.all(Size(double.maxFinite, 30.0)),
                            foregroundColor: MaterialStateProperty.all(
                                AmmColor.primaryColor.withOpacity(0.9)),
                          ),
                        )
                    ],
                  ),
                ),
              ),
              // expandedHeight: 120,
              // flexibleSpace: FlexibleSpaceBar(
              //   background: ,
              //   title: TextField(),),
            )
          ];
        },
      ),
    );
  }

  Widget emptyNotification() {
    return
        // Container(
        //   height: SizeMargin.fullScreenHeight(context, h: 0.8),
        //   child:
        Padding(
      padding: const EdgeInsets.all(8.0),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 60.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.bellOff,
                size: 60.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "You have no notifications yet",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "Once you have notifications they will appear here",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
            ),
          ],
          // ),
        ),
      ),
    );
  }

  Widget loadingNotifications() {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.grey[100],
        enabled: true,
        child: ListView(
            padding: const EdgeInsets.all(8.0),
            children: List.generate(6, (index) {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        // Container(
                        //   height: 60.0,
                        //   width: 60.0,
                        //   decoration: ShapeDecoration(
                        //     shape: RoundedRectangleBorder(
                        //         borderRadius: BorderRadius.circular(30.0)),
                        //     color: Colors.white,
                        //   ),
                        // ),
                        // SizeMargin.width(16.0),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 10.0,
                              width: 120.0,
                              color: Colors.white,
                            ),
                            SizeMargin.height(16.0),
                            Container(
                              height: 10.0,
                              width: 200.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                        Spacer(),
                        Container(
                          height: 6.0,
                          width: 20.0,
                          color: Colors.white,
                        ),
                      ],
                    ),
                    Divider(),
                  ],
                ),
              );
            })));
  }

  void _onLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () => Future.value(false),
          child: Dialog(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                  ),
                  SizeMargin.width(8.0),
                  const Text("Please wait..."),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
