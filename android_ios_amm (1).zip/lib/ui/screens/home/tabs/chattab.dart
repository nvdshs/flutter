import 'package:amm/core/models/chat_message.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/providers/chat_provider.dart';
import '../../../../app/route_constants.dart';
import '../../../utils.dart';

class ChatTab extends StatefulWidget {
  ChatTab({Key key}) : super(key: key);

  @override
  _ChatTabState createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  ChatProvider _chatProvider;
  bool _isLoading = true;
  String _searchText = "";
  final TextEditingController _textController = TextEditingController();
  List<ChatMessage> _chats = [];
  @override
  void initState() {
    super.initState();
    _chatProvider = Provider.of<ChatProvider>(context, listen: false);
    fetchChats();
    Provider.of<UserProvider>(context, listen: false)
        .removeDotNotification("chat")
        .then((_) => null)
        .catchError((_) => null);
  }

  void fetchChats() async {
    try {
      await _chatProvider.fetchRecentChats();
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ChatProvider>(
        //
        builder: (_, cProvider, __) {
      if (cProvider.recentChats.isNotEmpty) {
        var messagecopy = [...cProvider.recentChats];
        _chats = _searchText.length > 0
            ? messagecopy
                .where(
                  (m) =>
                      m.message
                          .toLowerCase()
                          .contains(_searchText.toLowerCase()) ||
                      m.username
                          .toLowerCase()
                          .contains(_searchText.toLowerCase()),
                )
                .toList()
            : cProvider.recentChats;
      }
      return NestedScrollView(
        floatHeaderSlivers: true,
        // slivers:[
        //   Center(
        //     child: Text("Home"),
        //   ),
        // ],
        body: _isLoading
            ? loadingChats()
            : cProvider.recentChats.isEmpty
                ? emptychat()
                : RefreshIndicator(
                    onRefresh: () => _chatProvider.fetchRecentChats(),
                    backgroundColor: AmmColor.primaryColor,
                    child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Container(
                        constraints: BoxConstraints(minHeight: 400),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, top: 16.0, bottom: 0.0),
                              child: Text("Chats",
                                  style: GoogleFonts.poppins(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.w600)),
                            ),
                            _chats.isEmpty
                                ? emptySearch()
                                : ListView.builder(
                                    padding: const EdgeInsets.only(top: 12.0),
                                    itemCount: _chats.length,
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      var chat = _chats[index];
                                      return Container(
                                        padding:
                                            const EdgeInsets.only(bottom: 4.0),
                                        child: ListTile(
                                          onTap: () => Navigator.pushNamed(
                                              context,
                                              RouteConstants.ChatScreen,
                                              arguments: {
                                                'username': chat.username,
                                                'image': chat.photo,
                                                'room': cProvider.userId ==
                                                        chat.senderId
                                                    ? '${chat.senderId}-${chat.receiverId}'
                                                    : '${chat.receiverId}-${chat.senderId}'
                                              }),
                                          leading: CircleAvatar(
                                              radius: 24.0,
                                              backgroundImage: chat.photo ==
                                                      null
                                                  ? AssetImage(
                                                      "assets/images/default_user.png")
                                                  : CachedNetworkImageProvider(
                                                      chat.photo)),
                                          title: Text(chat.username),
                                          subtitle: chat.type == 'image'
                                              ? Container(
                                                  alignment: Alignment.topLeft,
                                                  child: Icon(Icons.image))
                                              : Text(
                                                  chat.message,
                                                ),
                                          trailing: Text(
                                            DateTime.now().day > chat.date.day
                                                ? DateFormat.yMEd()
                                                    .format(chat.date)
                                                : DateFormat.jm()
                                                    .format(chat.date),
                                            style: TextStyle(
                                                fontSize: 12.0,
                                                color: Color(0XFFA0A0A0)),
                                          ),
                                        ),
                                      );
                                    },
                                  )
                          ],
                        ),
                      ),
                    ),
                  ),

        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return [
            SliverAppBar(
              automaticallyImplyLeading: false,
              title: Image.asset(
                "assets/images/logo1.png",
                width: 80.0,
              ),
              centerTitle: true,
              toolbarHeight: 90.0,
              bottom: cProvider.recentChats.isEmpty
                  ? PreferredSize(
                      preferredSize: Size.fromHeight(0.0), child: Container())
                  : PreferredSize(
                      preferredSize: Size.fromHeight(20.0),
                      child: Padding(
                        padding:
                            const EdgeInsets.fromLTRB(16.0, 0.0, 16.0, 12.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _textController,
                                onChanged: (val) {
                                  setState(() {
                                    _searchText = val;
                                  });
                                },
                                cursorColor: AmmColor.secondaryColor,
                                decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Color(0XFFE5E5E5),
                                    hintText: "Search chat history",
                                    border: OutlineInputBorder(
                                        borderRadius: const BorderRadius.all(
                                          const Radius.circular(10.0),
                                        ),
                                        borderSide: BorderSide.none),
                                    contentPadding: const EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 12.0),
                                    suffixIcon: _searchText.length > 1
                                        ? IconButton(
                                            icon: Icon(
                                              Icons.clear,
                                              color: Colors.black54,
                                            ),
                                            onPressed: () {
                                              setState(() {
                                                _searchText = "";
                                                _textController.text = "";
                                              });
                                            })
                                        : Container(width: 0, height: 0)),
                              ),
                            ),
                            // SizeMargin.width(8.0),
                            // Container(
                            //     padding: const EdgeInsets.all(12.0),
                            //     decoration: ShapeDecoration(
                            //         color: Color(0XFFE5E5E5),
                            //         shape: RoundedRectangleBorder(
                            //           borderRadius: const BorderRadius.all(
                            //             const Radius.circular(10.0),
                            //           ),
                            //         )),
                            //     child: Icon(Icons.search)),
                          ],
                        ),
                      ),
                    ),
              // expandedHeight: 120,
              // flexibleSpace: FlexibleSpaceBar(
              //   background: ,
              //   title: TextField(),),
            )
          ];
        },
      );
    });
  }

  Widget emptychat() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 60.0,
          backgroundColor: AmmColor.primaryColor,
          child: Icon(
            FeatherIcons.messageCircle,
            size: 60.0,
          ),
        ),
        SizeMargin.height(16.0),
        Text(
          "You have no chats yet.",
          style: GoogleFonts.lato(
            textStyle: TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
          ),
        ),
        SizeMargin.height(16.0),
        Text(
          "Get to chat people that match your profile",
          style: GoogleFonts.lato(
            textStyle:
                TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
          ),
        ),
      ],
    );
  }

  Widget emptySearch() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizeMargin.height(24.0),
            CircleAvatar(
              radius: 50.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.search,
                size: 40.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "No chat messages matched your search query, try again!",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
            Text(
              "Get to search for message history by username or last messages",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget loadingChats() {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.grey[100],
        enabled: true,
        child: ListView(
            padding: const EdgeInsets.all(8.0),
            children: List.generate(6, (index) {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(
                  children: [
                    Container(
                      height: 60.0,
                      width: 60.0,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0)),
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.width(16.0),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 10.0,
                          width: 150.0,
                          color: Colors.white,
                        ),
                        SizeMargin.height(16.0),
                        Container(
                          height: 10.0,
                          width: 200.0,
                          color: Colors.white,
                        ),
                      ],
                    )
                  ],
                ),
              );
            })));
  }
}
