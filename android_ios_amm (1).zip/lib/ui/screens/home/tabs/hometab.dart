import 'package:amm/app/route_constants.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/core/services/location_service.dart';
import 'package:amm/ui/screens/home/users/search.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../utils.dart';
import '../profile_match.dart';

class HomeTab extends StatefulWidget {
  HomeTab({Key key}) : super(key: key);

  @override
  _HomeTabState createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  UserProvider _userProvder;
  bool _isLoadingTwo = true;
  bool _isLoadingOne = true;
  String _filterBy = "random";
  double _latitude = 0;
  double _longitude = 0;
  @override
  void initState() {
    super.initState();
    _userProvder = Provider.of<UserProvider>(context, listen: false);
    if (_userProvder.hasFetchedRandomUser) {
      _isLoadingTwo = false;
    } else {
      fetch();
    }
    fetchPreferences();
  }

  void fetch() async {
    try {
      await _userProvder.fetchRandomUsers(_filterBy, _latitude, _longitude);
      setState(() {
        _isLoadingTwo = !_isLoadingTwo;
      });
    } catch (e) {
      setState(() {
        _isLoadingTwo = !_isLoadingTwo;
      });
    }
  }

  void fetchPreferences() async {
    try {
      await _userProvder.fetchPreferenceUsers();
      setState(() {
        _isLoadingOne = !_isLoadingOne;
      });
    } catch (e) {
      setState(() {
        _isLoadingOne = !_isLoadingOne;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return NestedScrollView(
      key: UniqueKey(),
      floatHeaderSlivers: true,
      // slivers:[
      //   Center(
      //     child: Text("Home"),
      //   ),
      // ],
      body: RefreshIndicator(
        onRefresh: () => Future.wait([
          _userProvder.fetchPreferenceUsers(),
          _userProvder.fetchRandomUsers(_filterBy, _latitude, _longitude)
        ]),
        color: AmmColor.primaryColor,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Profiles that match",
                      style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          fontWeight: FontWeight.w600,
                          color: AmmColor.secondaryColor),
                    ),
                    InkWell(
                      onTap: () async {
                        var result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProfileMatchScreen(
                              isFromProfile: true,
                            ),
                          ),
                        );
                        if (result != null && result) {
                          setState(() {
                            _isLoadingOne = true;
                          });
                          this.fetchPreferences();
                        }
                      },
                      borderRadius: BorderRadius.circular(10.0),
                      child: Container(
                          padding: const EdgeInsets.all(8.0),
                          decoration: ShapeDecoration(
                              color: AmmColor.primaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: const BorderRadius.all(
                                  const Radius.circular(10.0),
                                ),
                              )),
                          child: Icon(
                            Icons.filter_list_rounded,
                            color: AmmColor.white,
                          )),
                    )
                  ],
                ),
              ),
              Consumer<UserProvider>(
                  //
                  builder: (_, uProvider, __) {
                if (_isLoadingOne) return loadingPreferences();
                if (uProvider.preferenceUsers.isEmpty)
                  return emptyPreferences();
                return Container(
                  margin: const EdgeInsets.only(bottom: 8.0),
                  height: 180.0,
                  child: ListView.builder(
                    physics: BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    itemCount: uProvider.preferenceUsers.length,
                    itemBuilder: (BuildContext context, int index) {
                      var user = uProvider.preferenceUsers[index];
                      return Container(
                        margin: const EdgeInsets.only(left: 16.0),
                        height: 180,
                        width: 180.0,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.0),
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: user.photo == null
                                ? AssetImage("assets/images/default_user.png")
                                : CachedNetworkImageProvider(user.photo),
                          ),
                        ),
                        child: GestureDetector(
                          onTap: () => Navigator.pushNamed(
                              context, RouteConstants.UserProfileScreen,
                              arguments: {
                                'uid': user.uid,
                                'isFromChat': false
                              }),
                          child: Container(
                            padding: const EdgeInsets.all(16.0),
                            decoration: ShapeDecoration(
                              color: Colors.black.withOpacity(0.4),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text("${user.username}",
                                    style: GoogleFonts.poppins(
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white)),
                                // SizeMargin.height(2.0),
                                _buildPreferenceInfo(user.dob, user.gender)
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                );
              }),
              Padding(
                padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Suggested people",
                      style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          fontWeight: FontWeight.w600,
                          color: AmmColor.secondaryColor),
                    ),
                    Container(
                      height: 40.0,
                      decoration: ShapeDecoration(
                        color: AmmColor.primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8.0,
                        vertical: 0.0,
                      ),
                      child: DropdownButton(
                        underline: Container(),
                        dropdownColor: AmmColor.primaryColor,
                        value: _filterBy,
                        items: [
                          DropdownMenuItem(
                            value: "random",
                            child: Text(
                              "Random",
                              style: TextStyle(
                                  color: AmmColor.white, fontSize: 13.0),
                            ),
                          ),
                          DropdownMenuItem(
                            value: "location",
                            child: Text(
                              "Location",
                              style: TextStyle(
                                  color: AmmColor.white, fontSize: 13.0),
                            ),
                          ),
                        ],
                        icon: Icon(Icons.keyboard_arrow_down),
                        iconEnabledColor: AmmColor.white,
                        onChanged: _onChangeFilter,
                      ),
                    )
                  ],
                ),
              ),
              Consumer<UserProvider>(
                  //consume user provider
                  builder: (_, uProvider, __) {
                if (_isLoadingTwo) return loadingSuggesstedPeople();
                if (uProvider.randomUsers.isEmpty)
                  return emptySuggesstedPeople();
                return GridView.builder(
                  padding: const EdgeInsets.only(top: 12.0),
                  itemCount: uProvider.randomUsers.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (BuildContext context, int index) {
                    var user = uProvider.randomUsers[index];
                    return Container(
                      margin: const EdgeInsets.only(left: 8.0, right: 8.0),
                      height: 250,

                      // width: 180.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: user.photo == null
                                ? AssetImage("assets/images/default_user.png")
                                : CachedNetworkImageProvider(user.photo),
                          ),
                          borderRadius: BorderRadius.circular(12.0)),
                      child: GestureDetector(
                        onTap: () => Navigator.pushNamed(
                            context, RouteConstants.UserProfileScreen,
                            arguments: {'uid': user.uid, 'isFromChat': false}),
                        child: Container(
                          padding: const EdgeInsets.all(16.0),
                          decoration: ShapeDecoration(
                            color: Colors.black.withOpacity(0.4),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text("${user.name}",
                                  style: GoogleFonts.poppins(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white)),
                              // SizeMargin.height(2.0),
                              if (user.city != null)
                                Text(
                                  "${user.city}",
                                  style: GoogleFonts.poppins(
                                    color: Colors.white,
                                  ),
                                ),
                              _buildInfo(user.dob, user.gender, user.username),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 8.0,
                    childAspectRatio: .8,
                  ),
                );
              }),
              SizeMargin.height(16.0),
              Center(
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SearchScreen(),
                      ),
                    );
                  },
                  child: Text(
                    "Find people you may know",
                    style: TextStyle(color: AmmColor.primaryColor),
                  ),
                ),
              ),
              SizeMargin.height(16.0),
            ],
          ),
        ),
      ),
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return [
          SliverAppBar(
            automaticallyImplyLeading: false,
            title: Image.asset(
              "assets/images/logo1.png",
              width: 80.0,
            ),
            centerTitle: true,
            // toolbarHeight: 90.0,
          )
        ];
      },
    );
  }

  void _onChangeFilter(String val) async {
    if (_filterBy == val) return;
    if (val == 'random') {
      setState(() {
        _filterBy = val;
        _isLoadingTwo = true;
      });
      fetch();
    } else {
      try {
        var location = await getUserLocation();
        if (location is LocationData) {
          setState(() {
            _filterBy = val;
            _latitude = location.latitude;
            _longitude = location.longitude;
            _isLoadingTwo = true;
          });
          fetch();
        } else {
          showToast("Unable to get location");
        }
      } catch (e) {
        showToast("Unable to get location");
      }
    }
  }

  Widget loadingPreferences() {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.grey[100],
        enabled: true,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8.0),
          height: 200.0,
          child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(8.0),
              children: List.generate(6, (index) {
                return Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 120.0,
                        width: 100.0,
                        decoration: ShapeDecoration(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6.0)),
                          color: Colors.white,
                        ),
                      ),
                      SizeMargin.height(8.0),
                      Container(
                        height: 4.0,
                        width: 70.0,
                        decoration: ShapeDecoration(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(2.0)),
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                );
              })),
        ));
  }

  Widget emptyPreferences() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.users,
                size: 40.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "No user matched your selected preference ",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
            Text(
              "You can always change your preference by clicking on the icon at the top right corner...",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
          ],
          // ),
        ),
      ),
    );
  }

  Widget loadingSuggesstedPeople() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300],
      highlightColor: Colors.grey[100],
      enabled: true,
      child: GridView(
        padding: const EdgeInsets.all(8.0),
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        children: List.generate(
          6,
          (index) {
            return Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 135.0,
                    // width: 160.0,
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6.0)),
                      color: Colors.white,
                    ),
                  ),
                  SizeMargin.height(8.0),
                  Container(
                    height: 4.0,
                    width: 70.0,
                    decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(2.0)),
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, mainAxisSpacing: 8.0, childAspectRatio: 1.1),
      ),
    );
  }

  Widget emptySuggesstedPeople() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.users,
                size: 40.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "We could not suggest people that matched your profile",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
            Text(
              "People who engage more or match profile will be displayed here",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
            // FlatButton(
            //   onPressed: () {
            //     Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (_) => SearchScreen(),
            //       ),
            //     );
            //   },
            //   child: Text(
            //     "Find new people",
            //     style: TextStyle(color: AmmColor.primaryColor),
            //   ),
            // )
          ],
          // ),
        ),
      ),
    );
  }

  Widget _buildInfo(DateTime dob, String gender, String username) {
    if (dob != null && gender != null) {
      return Text(
        "${(DateTime.now().difference(dob).inDays / 365).round()} / $gender",
        style: GoogleFonts.poppins(color: Colors.white),
      );
    } else if (dob != null) {
      return Text(
        "${(DateTime.now().difference(dob).inDays / 365).round()} years",
        style: GoogleFonts.poppins(color: Colors.white),
      );
    } else if (gender != null) {
      return Text(
        gender,
        style: GoogleFonts.poppins(color: Colors.white),
      );
    } else {
      return Text(
        username,
        style: GoogleFonts.poppins(color: Colors.white),
      );
    }
  }

  Widget _buildPreferenceInfo(DateTime dob, String gender) {
    if (dob == null && gender != null) {
      return Text(
        gender,
        style: GoogleFonts.poppins(color: Colors.white),
      );
    } else if (gender == null && dob != null) {
      return Text(
        "${(DateTime.now().difference(dob).inDays / 365).round()} years",
        style: GoogleFonts.poppins(color: Colors.white),
      );
    } else {
      return Text(
        "${(DateTime.now().difference(dob).inDays / 365).round()} / $gender",
        style: GoogleFonts.poppins(color: Colors.white),
      );
    }
  }
}
