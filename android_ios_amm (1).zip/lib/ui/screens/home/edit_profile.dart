import 'package:amm/core/models/user.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../utils.dart';
import '../search_country_city.dart';

class EditProfileScreen extends StatefulWidget {
  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  DateTime _selectedDate = DateTime(DateTime.now().year - 16);
  String _pickeddob = "";
  String _gender = "";
  String doctrine = 'Catholic';
  List<String> _doctrines = [
    'Catholic',
    'Pentecostal',
    'Celestial',
    'Anglican',
    'Baptist'
  ];
  UserProvider _userProvider;
  final TextEditingController _textController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _userProvider = Provider.of(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0.0,
          leading: IconButton(
              icon: platformBackButton(),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: Text(
            "Edit Profile",
            style: Theme.of(context).textTheme.headline5,
          ),
        ),
        body: Consumer<UserProvider>(
            //
            builder: (_, uProvider, __) {
          User user = uProvider.currentUser;
          return Theme(
            data: ThemeData(
              primarySwatch: Colors.red,
            ),
            child: Builder(
              builder: (context) => SingleChildScrollView(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    ListTile(
                      title: Text("Full name"),
                      subtitle: Text(user.name),
                      isThreeLine: true,
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'fullname'),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Username"),
                      subtitle: Text("@${user.username}"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'username'),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Date of birth"),
                      subtitle: Text(user.dob == null
                          ? "N/A"
                          : "${DateFormat.yMMMd().format(user.dob)}"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _selectDate(context, user.dob),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Gender"),
                      subtitle: Text(user.gender ??
                          "Select a gender to make people find you better"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _selectGenderModal(user.gender),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("State/Country"),
                      subtitle: Text(user.city ??
                          "Update to enable people find you better"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: updateCity,
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Ethnicity"),
                      subtitle: Text(user.ethnicity ??
                          "Update to get better profile match"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: _showEthnicsBottomSheet,
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Interests"),
                      subtitle: Text(user.dislikes ??
                          "Separate each interest with a comma"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'dislikes'),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Hobbies"),
                      subtitle: Text(
                          user.likes ?? "Separate each hobby with a comma"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'likes'),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Church"),
                      subtitle: Text(user.church ?? "N/A"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'church'),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Denomination"),
                      subtitle: Text(user.doctrine ?? "N/A"),
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () =>
                            _showEditDoctrineBottomSheet(user.doctrine),
                      ),
                    ),
                    Divider(),
                    ListTile(
                      title: Text("Bio"),
                      subtitle: Text(user.bio ?? "N/A"),
                      isThreeLine: true,
                      trailing: IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () => _showEditBottomSheet(user, 'bio'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }));
  }

  void _showEditBottomSheet(User user, String type) {
    _textController.text = getData(type, user);
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (_) {
          return Container(
            // height: SizeMargin.fullScreenHeight(context, h: 0.8),
            padding: const EdgeInsets.all(16.0),
            child: Wrap(
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Enter your $type"),
                SizeMargin.height(16.0),
                TextField(
                  autofocus: true,
                  controller: _textController,
                  cursorColor: AmmColor.secondaryColor,
                  minLines: 1,
                  maxLines: type == 'bio' ? 2 : 1,
                  maxLength: getLength(type),
                  decoration: InputDecoration(
                    hintText: "Type your $type here ...",
                    border: UnderlineInputBorder(
                      borderSide: BorderSide(color: AmmColor.secondaryColor),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: AmmColor.secondaryColor),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: AmmColor.secondaryColor),
                    ),
                  ),
                ),
                SizeMargin.height(16.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    MaterialButton(
                      elevation: 0.0,
                      textColor: AmmColor.primaryColor,
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Cancel"),
                    ),
                    SizeMargin.width(8.0),
                    MaterialButton(
                        elevation: 0.0,
                        onPressed: () {
                          Navigator.pop(context);

                          updateUserDetail(_textController.text, type);
                        },
                        child: Text("Save"))
                  ],
                )
              ],
            ),
          );
        });
  }

  void _showEditDoctrineBottomSheet(String doc) {
    doctrine = doc ?? 'Catholic';
    showModalBottomSheet(
        context: context,
        builder: (_) {
          return StatefulBuilder(builder: (context, setSheetState) {
            return Container(
              height: 300,
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Select your denomination"),
                  SizeMargin.height(16.0),
                  Container(
                    height: 50.0,
                    padding: const EdgeInsets.all(8.0),
                    decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                      side: BorderSide(color: Color(0XFFE5E5E5)),
                      borderRadius: const BorderRadius.all(
                        const Radius.circular(10.0),
                      ),
                    )),
                    child: DropdownButton(
                      isExpanded: true,
                      underline: Container(),
                      value: doctrine,
                      items: _doctrines
                          .map((doc) => DropdownMenuItem(
                                value: doc,
                                child: Text(doc),
                              ))
                          .toList(),
                      onChanged: (val) {
                        setSheetState(() {
                          doctrine = val;
                        });
                      },
                    ),
                  ),
                  SizeMargin.height(16.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      MaterialButton(
                        elevation: 0.0,
                        textColor: AmmColor.primaryColor,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text("Cancel"),
                      ),
                      SizeMargin.width(8.0),
                      MaterialButton(
                          elevation: 0.0,
                          onPressed: () {
                            Navigator.pop(context);
                            print(doctrine);
                            updateUserDetail(doctrine, "doctrine");
                          },
                          child: Text("Save"))
                    ],
                  )
                ],
              ),
            );
          });
        });
  }

  void _selectGenderModal(String gender) {
    _gender = gender ?? 'male';
    showDialog(
        context: context,
        builder: (_) {
          return StatefulBuilder(builder: (context, setDialogState) {
            return AlertDialog(
              title: Text("Select gender"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  RadioListTile(
                    title: Text("Male"),
                    value: "male",
                    groupValue: _gender,
                    onChanged: (value) {
                      setDialogState(() {
                        _gender = value;
                      });
                    },
                    activeColor: AmmColor.primaryColor,
                  ),
                  RadioListTile(
                    title: Text("Female"),
                    value: "female",
                    groupValue: _gender,
                    onChanged: (value) {
                      setDialogState(() {
                        _gender = value;
                      });
                    },
                    activeColor: AmmColor.primaryColor,
                  ),
                ],
              ),
              actions: [
                MaterialButton(
                  elevation: 0.0,
                  textColor: Colors.black,
                  child: Text("CLOSE",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      )),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  // shape: RoundedRectangleBorder(
                  //   borderRadius: BorderRadius.circular(4.0),
                  // ),
                  // color: FinergeColor.primaryColor,
                ),
                MaterialButton(
                  elevation: 0.0,
                  child: Text(
                    "Save",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  onPressed: () {
                    setState(() {/* Do nothing */});
                    Navigator.pop(context);
                    print(_gender);
                    updateUserDetail(_gender, "gender");
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  color: AmmColor.primaryColor,
                  textColor: Colors.white,
                )
              ],
            );
          });
        });
  }

  _selectDate(BuildContext context, DateTime dob) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: dob ?? _selectedDate,
      firstDate: DateTime(1960),
      lastDate: DateTime(DateTime.now().year - 16),
      initialDatePickerMode: DatePickerMode.year,
    );
    if (picked != null) {
      _pickeddob = picked.toLocal().toString().split(' ')[0];
      updateDob(_pickeddob);
    } else {
      showToast("Operation cancelled");
    }
    // setState(() {
    //   dob = picked.toLocal().toString().split(' ')[0];
    //   selectedDate = picked;
    // });
  }

  void updateDob(String theDob) async {
    progressModal(context);
    try {
      await _userProvider.updateDob(theDob);
      showToast("Date of birth updated");
      if (this.mounted) Navigator.pop(context);
    } catch (e) {
      showToast("Unable to complete process, try again");
      if (this.mounted) Navigator.pop(context);
      throw e;
    }
  }

  void _showEthnicsBottomSheet() {
    showModalBottomSheet(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        isScrollControlled: true,
        context: context,
        builder: (_) {
          return StatefulBuilder(builder: (_, stateSetter) {
            return Container(
              // height: 400,
              constraints: BoxConstraints(
                  maxHeight: SizeMargin.fullScreenHeight(context, h: 0.8)),
              padding:
                  const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
              child: ListView.builder(
                  // shrinkWrap: true,
                  // physics: Never,
                  itemCount: ethnics.length,
                  itemBuilder: (_, index) {
                    return ListTile(
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          print(ethnics[index]);
                          updateUserDetail(ethnics[index].slug, "ethnicity");
                        });
                      },
                      title: Text(ethnics[index].title),
                    );
                  }),
            );
          });
        });
  }

  /*void updateProfile(String data, String type) async {
    if (data == null || data.trim().length < 2) {
      showToast("Enter a $type");
      return;
    }
    progressModal(context);
    try {
      await _userProvider.updateProfile(data, type);
      showToast("Your $type has been updated");
      if (this.mounted) Navigator.pop(context);
    } catch (e) {
      showToast("Unable to complete process, try again");
      if (this.mounted) Navigator.pop(context);
      throw e;
    }
  }
  */

  void updateCity() async {
    var result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SearchCountryCity()),
    );
    if (result is String)
      updateUserDetail(result, "city");
    else
      showToast("Operation cancelled");
  }

  void updateUserDetail(String data, String type) async {
    if (data == null || data.trim().length < 2) {
      showToast("Enter a $type");
      return;
    }
    if (type == 'username' &&
        !RegExp(
          r"^[a-zA-Z0-9_]+$",
          caseSensitive: false,
        ).hasMatch(data)) {
      showInfoDialog(
        context,
        "Username can only contain letters, numbers and underscore",
      );
      return;
    }
    progressModal(context);
    try {
      await _userProvider.updateUserDetails(data, type);
      showToast("Your profile has been updated");
      if (this.mounted) Navigator.pop(context);
    } catch (e) {
      showToast("Unable to complete process, try again");
      if (this.mounted) Navigator.pop(context);
      throw e;
    }
  }

  String getData(String type, User user) {
    switch (type) {
      case 'fullname':
        return user.name;
        break;
      case 'username':
        return user.username;
        break;
      case 'likes':
        return user.likes;
        break;
      case 'dislikes':
        return user.dislikes;
        break;
      default:
        return '';
    }
  }

  int getLength(String type) {
    switch (type) {
      case 'fullname':
        return 36;
        break;
      case 'username':
        return 16;
        break;
      case 'likes':
        return 40;
        break;
      case 'dislikes':
        return 40;
        break;
      case 'bio':
        return 80;
        break;
      case 'church':
        return 40;
        break;
      default:
        return 12;
    }
  }
}
