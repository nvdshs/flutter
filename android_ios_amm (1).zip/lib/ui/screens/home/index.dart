import 'dart:math';

import 'package:amm/core/models/notification_alert.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/core/services/firestore_service.dart';
import 'package:amm/core/services/onesignal_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../../bible_verses.dart';
import '../../utils.dart';
import 'users/friends.dart';

import 'tabs/chattab.dart';
import 'tabs/hometab.dart';
import 'tabs/notificationstab.dart';
import 'tabs/profiletab.dart';

class IndexScreen extends StatefulWidget {
  final int currentIndex;
  IndexScreen({Key key, this.currentIndex}) : super(key: key);

  @override
  _IndexScreenState createState() => _IndexScreenState();
}

class _IndexScreenState extends State<IndexScreen> {
  // firestore service
  FirestoreService _firestoreService = FirestoreService();
  final _random = new Random();
  List<Widget> _tabPages = [];
  int _currentIndex = 0;
  int _userId = 0;
  @override
  void initState() {
    super.initState();
    _tabPages
      ..add(HomeTab())
      ..add(ChatTab())
      ..add(NotificationsTab())
      ..add(ProfileTab());
    _currentIndex = widget.currentIndex;
    _showBibleVerse();
    saveOneSignalDeviceId();
    Provider.of<UserProvider>(context, listen: false)
        .fetchUserDetails()
        .then((_) => null)
        .catchError((_) => null);
    _userId = Provider.of<UserProvider>(context, listen: false).currentUser.uid;
  }

  void _showBibleVerse() {
    var lastShown =
        Provider.of<UserProvider>(context, listen: false).bibleVerseLastShown;
    if (lastShown.isBefore(DateTime.now())) {
      Future.delayed(Duration.zero, () {
        showDailyBibleVerse();
        Provider.of<UserProvider>(context, listen: false)
            .setShownBibleVerseLast();
      });
    }
  }

  void saveOneSignalDeviceId() async {
    try {
      var result = await OneSignalService.savePlayerId();
      if (result is String)
        await Provider.of<UserProvider>(context, listen: false)
            .updateSignalToken(result);
      print(result);
    } catch (e) {
      print(e);
      // showToast("Unable to s")
      // throw nothing
    }
  }

  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   Future.delayed(Duration.zero, () {
  //     showDailyBibleVerse();
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _tabPages.elementAt(_currentIndex),
      bottomNavigationBar: StreamBuilder<NotificationAlert>(
          stream: _firestoreService.getUserNotification(_userId),
          initialData: NotificationAlert(false, false),
          builder: (context, snapshot) {
            var notify = snapshot.data;
            return BottomNavigationBar(
              currentIndex: _currentIndex,
              unselectedItemColor: Color(0XFFA0A0A0),
              selectedItemColor: AmmColor.primaryColor,
              type: BottomNavigationBarType.fixed,
              items: <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  label: "",
                  icon: Icon(FeatherIcons.home),
                ),
                BottomNavigationBarItem(
                  label: "",
                  icon: Stack(
                    children: [
                      Icon(FeatherIcons.messageCircle),
                      if (notify.chat)
                        Positioned(
                          top: 0,
                          right: 1.0,
                          child: CircleAvatar(
                            radius: 5.0,
                            backgroundColor: AmmColor.primaryColor,
                          ),
                        )
                    ],
                  ),
                ),
                BottomNavigationBarItem(
                  label: "",
                  icon: Stack(
                    children: [
                      Icon(FeatherIcons.bell),
                      if (notify.notification)
                        Positioned(
                          top: 0,
                          right: 1.0,
                          child: CircleAvatar(
                            radius: 5.0,
                            backgroundColor: AmmColor.primaryColor,
                          ),
                        )
                    ],
                  ),
                ),
                BottomNavigationBarItem(
                  label: "",
                  icon: Icon(FeatherIcons.user),
                )
              ],
              onTap: (val) {
                setState(() {
                  _currentIndex = val;
                });
              },
            );
          }),
      floatingActionButton: [1, 3].contains(_currentIndex)
          ? FloatingActionButton(
              child: Icon(FeatherIcons.users),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => FriendsScreen()));
              },
              backgroundColor: AmmColor.primaryColor,
              foregroundColor: Colors.white,
            )
          : Container(),
    );
  }

  void showDailyBibleVerse() {
    int index = randomNumber(0, BIBLE_VERSES.length - 1);
    showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black12,
        context: context,
        builder: (_) {
          return Dialog(
            backgroundColor: Colors.transparent,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      children: [
                        Text(
                          "Daily bible verse",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 18.0, fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizeMargin.height(12.0),
                        CircleAvatar(
                          radius: 40.0,
                          backgroundColor: AmmColor.primaryColor,
                          child: Icon(Icons.format_quote, size: 60.0),
                        ),
                        SizeMargin.height(12.0),
                        Text(BIBLE_VERSES[index]['content']),
                        SizeMargin.height(16.0),
                        Text(
                          "${BIBLE_VERSES[index]['verse']} (KJV)",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 18.0, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizeMargin.height(36.0),
                MaterialButton(
                  height: 45.0,
                  child: Icon(Icons.clear),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  color: Colors.white,
                  shape: CircleBorder(),
                )
              ],
            ),
          );
        });
  }

  int randomNumber(int min, int max) => min + _random.nextInt(max - min);
}
