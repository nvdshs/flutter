import 'dart:io';

import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/ui/utils.dart';
import 'package:amm/ui/widgets/gallery_view.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:amm/ui/widgets/show_image_with_caption.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class UserGalleryScreen extends StatefulWidget {
  @override
  _UserGalleryScreenState createState() => _UserGalleryScreenState();
}

class _UserGalleryScreenState extends State<UserGalleryScreen> {
  final picker = ImagePicker();
  int selectedId = 0;
  String publicId = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
            icon: platformBackButton(),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: Text("Your Gallery"),
        actions: [
          if (selectedId > 0)
            IconButton(
              icon: Icon(Icons.delete_forever),
              onPressed: () async {
                _onLoading();
                try {
                  await Provider.of<UserProvider>(context, listen: false)
                      .deleteGalleryPhoto(selectedId, publicId);
                  setState(() {
                    selectedId = 0;
                  });
                  Navigator.pop(context);
                  showToast("Image deleted");
                } catch (e) {
                  Navigator.pop(context);
                  showToast("An error occurred, try again");
                  // throw e;
                }
              },
            )
        ],
      ),
      body: Consumer<UserProvider>(builder: (context, uProvider, __) {
        var images = uProvider.galleryImages;
        return images.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.image_search,
                        size: 80.0,
                      ),
                      SizeMargin.height(16.0),
                      Text(
                        "Your gallery is empty!",
                        style: TextStyle(fontSize: 18.0),
                      ),
                      SizeMargin.height(8.0),
                      Text(
                        "Add images to your gallery by clicking the button at the bottom right corner so that they appear here",
                        style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : StaggeredGridView.countBuilder(
                padding: const EdgeInsets.all(8.0),
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 12,
                itemCount: images.length,
                itemBuilder: (context, index) {
                  var image = images[index];
                  return Stack(
                    children: [
                      GestureDetector(
                        onLongPress: () {
                          setState(() {
                            selectedId = image.id;
                            publicId = image.publicId;
                          });
                        },
                        onTap: () {
                          if (selectedId == image.id)
                            setState(() {
                              selectedId = 0;
                              publicId = '';
                            });
                          else
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) {
                              return GalleryViewWidget(
                                galleryImages: images,
                                currentIndex: index,
                              );
                            }));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.transparent,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(8))),
                          child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(8)),
                              child: CachedNetworkImage(
                                // width: 120,
                                imageUrl: image.url,
                                fit: BoxFit.cover,
                              )),
                        ),
                      ),
                      if (selectedId == image.id)
                        Positioned(
                          top: 8,
                          right: 12,
                          child: Icon(
                            Icons.check_circle,
                            color: AmmColor.primaryColor,
                          ),
                        )
                    ],
                  );
                },
                staggeredTileBuilder: (index) {
                  return StaggeredTile.count(1, index.isEven ? 1.2 : 1.8);
                });

        /*GridView.builder(
                padding: const EdgeInsets.only(top: 12.0),
                itemCount: images.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  var image = images[index];
                  return Stack(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 8.0, right: 8.0),
                        // height: 160,
                        // width: 180.0,

                        child: Column(
                          children: [
                            GestureDetector(
                              onLongPress: () {
                                setState(() {
                                  selectedId = image.id;
                                  publicId = image.publicId;
                                });
                              },
                              onTap: () {
                                if (selectedId == image.id)
                                  setState(() {
                                    selectedId = 0;
                                    publicId = '';
                                  });
                                else
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (_) {
                                    return FullScreenImage(
                                      imageUrl: image.url,
                                      tag: "gallery_img_$index",
                                    );
                                  }));
                              },
                              child: Hero(
                                tag: "gallery_img_$index",
                                child: CachedNetworkImage(
                                  width: 120,
                                  imageUrl: image.url,
                                ),
                              ),
                            ),
                            if (image.caption != null && 2 == 3)
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 12.0),
                                child: Text(
                                  image.caption +
                                      image.caption +
                                      image.caption +
                                      image.caption +
                                      image.caption +
                                      image.caption,
                                  textAlign: TextAlign.center,
                                ),
                              )
                          ],
                        ),
                      ),
                      if (selectedId == image.id)
                        Positioned(
                          top: 8,
                          right: 12,
                          child: Icon(
                            Icons.check_circle,
                            color: AmmColor.primaryColor,
                          ),
                        )
                    ],
                  );
                },
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 2.0,
                    childAspectRatio: 0.8),
              ); */
      }),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AmmColor.primaryColor,
        foregroundColor: Colors.white,
        child: Icon(Icons.image),
        onPressed: _imageBottomSheet,
      ),
    );
  }

  void _imageBottomSheet() {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10.0),
          topRight: Radius.circular(10.0),
        ),
      ),
      context: context,
      builder: (_) {
        return Container(
          height: 150.0,
          padding: const EdgeInsets.all(36.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  uploadImage(ImageSource.gallery);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.file_upload,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Gallery", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
              SizeMargin.width(24.0),
              GestureDetector(
                onTap: () {
                  uploadImage(ImageSource.camera);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Camera", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void uploadImage(ImageSource source) async {
    Navigator.pop(context);
    final PickedFile pickedFile = await picker.getImage(source: source);
    if (pickedFile != null) {
      var result = await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ShowImageWithCaption(File(pickedFile.path))));
      if (result is Map<String, dynamic>) {
        // if (result)
        uploadGalleryImage(result);
        // else
        //   Helper.showToast("Image not uploaded");
      } else {
        showToast("Operation has been cancelled");
      }
    } else {
      showToast("Operation was cancelled");
    }
  }

  void uploadGalleryImage(Map<String, dynamic> data) async {
    _onLoading();
    try {
      await Provider.of<UserProvider>(context, listen: false)
          .addGalleryImage(data['file']);

      if (Navigator.canPop(context)) Navigator.pop(context);
      showToast("Gallery image has been uploaded");
    } catch (e) {
      if (Navigator.canPop(context)) Navigator.pop(context);
      showToast("An unknown error occurred, please try again");
    }
  }

  void _onLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () => Future.value(false),
          child: Dialog(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                  ),
                  SizeMargin.width(8.0),
                  const Text("Please wait..."),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
