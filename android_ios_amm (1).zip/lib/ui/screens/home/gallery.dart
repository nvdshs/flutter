import 'package:amm/core/models/gallery_image.dart';
import 'package:amm/ui/utils.dart';
import 'package:amm/ui/widgets/gallery_view.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class GalleryScreen extends StatelessWidget {
  final String username;
  final List<GalleryImage> images;
  GalleryScreen(this.username, this.images);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: IconButton(
              icon: platformBackButton(),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: Text("$username's Gallery"),
        ),
        body: StaggeredGridView.countBuilder(
            padding: const EdgeInsets.all(8.0),
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 12,
            itemCount: this.images.length,
            itemBuilder: (context, index) {
              var image = this.images[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) {
                    return GalleryViewWidget(
                      galleryImages: this.images,
                      currentIndex: index,
                    );

                    // FullScreenImage(
                    //   imageUrl: image.url,
                    //   tag: "gallery_img_$index",
                    // );
                  }));
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(8))),
                  child: ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                      child: CachedNetworkImage(
                        // width: 120,
                        imageUrl: image.url,
                        fit: BoxFit.cover,
                      )),
                  // child: ClipRRect(
                  //   borderRadius: BorderRadius.all(Radius.circular(8)),
                  //   child: FadeInImage.memoryNetwork(
                  //     placeholder: kTransparentImage,
                  //     image: image.url,
                  //     fit: BoxFit.cover,
                  //   ),
                  // ),
                ),
              );
            },
            staggeredTileBuilder: (index) {
              return StaggeredTile.count(1, index.isEven ? 1.2 : 1.8);
            })

        /*GridView.builder(
        padding: const EdgeInsets.only(top: 12.0),
        itemCount: this.images.length,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          var image = this.images[index];
          return Container(
            margin: const EdgeInsets.only(left: 8.0, right: 8.0),
            height: 150,
            // width: 180.0,

            child: Column(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) {
                      return FullScreenImage(
                        imageUrl: image.url,
                        tag: "gallery_img_$index",
                      );
                    }));
                  },
                  child: Hero(
                    tag: "gallery_img_$index",
                    child: CachedNetworkImage(
                      width: 120,
                      imageUrl: image.url,
                    ),
                  ),
                ),
                if (1 == 2)
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 12.0),
                    child: Text(
                      image.caption,
                      textAlign: TextAlign.center,
                    ),
                  )
              ],
            ),
          );
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, mainAxisSpacing: 8.0, childAspectRatio: 1.1),
      ),
      */
        );
  }
}
