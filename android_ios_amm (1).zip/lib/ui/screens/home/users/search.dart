import 'package:amm/app/route_constants.dart';
import 'package:amm/core/models/other_user.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../utils.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  bool _isLoading = false;
  List<OtherUser> _users = [];
  final TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0.0,
        centerTitle: true,
        leading: IconButton(
            icon: platformBackButton(),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: TextField(
          controller: _searchController,
          autofocus: true,
          cursorColor: AmmColor.secondaryColor,
          decoration: InputDecoration(
              hintText: "Enter username or name here ...",
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: AmmColor.secondaryColor))),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: searchUsers,
          ),
        ],
      ),
      body: _isLoading
          ? loadingUsers()
          : _users.isEmpty
              ? emptyFriends()
              : ListView.separated(
                  padding: const EdgeInsets.only(top: 12.0),
                  itemCount: _users.length,
                  itemBuilder: (BuildContext context, int index) {
                    var user = _users[index];
                    return Container(
                      padding: const EdgeInsets.only(bottom: 4.0),
                      child: ListTile(
                          onTap: () => Navigator.pushNamed(
                                  context, RouteConstants.UserProfileScreen,
                                  arguments: {
                                    'uid': user.uid,
                                    'isFromChat': false
                                  }),
                          leading: CircleAvatar(
                            radius: 24.0,
                            backgroundImage: user.photo == null
                                ? AssetImage("assets/images/default_user.png")
                                : CachedNetworkImageProvider(user.photo),
                          ),
                          title: Text("${user.name}"),
                          subtitle: Text(
                            user.dob == null
                                ? "@${user.username}"
                                : "${(DateTime.now().difference(user.dob).inDays / 365).round()} years",
                          )),
                    );
                  },
                  separatorBuilder: (_, __) {
                    return Divider();
                  },
                ),
    );
  }

  void searchUsers() async {
    if (_searchController.text.trim().length < 2) {
      showToast("Try a longer name");
      return;
    }
    setState(() {
      _isLoading = true;
    });
    try {
      var result = await Provider.of<UserProvider>(context, listen: false)
          .searchUsers(_searchController.text);
      if (result is List<OtherUser>) {
        setState(() {
          _users = result;
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      throw e;
    }
  }

  Widget emptyFriends() {
    return
        // Container(
        //   height: SizeMargin.fullScreenHeight(context, h: 0.8),
        //   child:
        Padding(
      padding: const EdgeInsets.all(8.0),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 60.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.search,
                size: 60.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "No search result",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              "try searching people's profile and get to meet new people",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
              textAlign: TextAlign.center,
            ),
          ],
          // ),
        ),
      ),
    );
  }

  Widget loadingUsers() {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.grey[100],
        enabled: true,
        child: ListView(
            padding: const EdgeInsets.all(8.0),
            children: List.generate(6, (index) {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 60.0,
                          width: 60.0,
                          decoration: ShapeDecoration(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0)),
                            color: Colors.white,
                          ),
                        ),
                        SizeMargin.width(16.0),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 10.0,
                              width: 120.0,
                              color: Colors.white,
                            ),
                            SizeMargin.height(16.0),
                            Container(
                              height: 10.0,
                              width: 200.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                        Spacer(),
                        Container(
                          height: 6.0,
                          width: 20.0,
                          color: Colors.white,
                        ),
                      ],
                    ),
                    Divider(),
                  ],
                ),
              );
            })));
  }
}
