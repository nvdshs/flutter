import 'dart:io';
import 'dart:async';

import 'package:amm/app/route_constants.dart';
import 'package:amm/core/models/chat_message.dart';
import 'package:amm/core/providers/chat_provider.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/ui/widgets/full_screen_image.dart';
import 'package:amm/ui/widgets/show_image.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:image_picker/image_picker.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../../../utils.dart';

class ChatScreen extends StatefulWidget {
  final Map<String, dynamic> arguments;
  ChatScreen(this.arguments);
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  //detect user fetching state
  bool _isFetching = false;
  // if there is still data to fetch
  bool _hasData = true;
  // show pull down button if user is not at the end
  bool _isScrollPositionAtBottom = true;
  // current chat page
  int _currentPage = 1;
  int _otherUserId = 0;
  int _selectedId = 0;
  bool _isTyping = false;
  bool _isLoggedIn = false;
  bool _isLoading = true;
  bool _isSendingFile = false;
  bool _isSending = false;
  final ImagePicker picker = ImagePicker();
  IO.Socket _socket;
  final TextEditingController _messageController = TextEditingController();
  ScrollController chatScrollController = ScrollController();

  // String socketUrl = "http://192.168.43.194:3000";
  String socketUrl = "https://amm-server-socket.herokuapp.com";
  List<ChatMessage> _messages = [];

  ChatProvider _chatProvider;

  // Platform.isIOS
  // : "http://192.168.43.194:3000/api/v1";
  @override
  void initState() {
    super.initState();
    _chatProvider = Provider.of(context, listen: false);
    _otherUserId = int.tryParse(widget.arguments['room'].split("-").last) ?? 0;
    createSocketConnection();
    fetchChats();
  }

  @override
  void dispose() {
    super.dispose();
    _socket.dispose();
    chatScrollController.dispose();
  }

  createSocketConnection() {
    var room1 = widget.arguments['room'];
    var room2 = swapRoom(room1);
    print("Room 1: " + room1);
    print("Room 2: " + room2);
    _socket = IO.io(socketUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false
      // 'upgrade': false
    });

    _socket.on("connect", (_) => print('Connected'));
    _socket.on("disconnect", (_) {
      print('Disconnected');
      _socket.emit("loggedout", {'room': room1});
    });

    _socket.on("typing", (data) {
      setState(() {
        _isTyping = data;
      });
    });
    _socket.on("logged_in", (data) {
      setState(() {
        _isLoggedIn = data;
      });
      _socket.emit("logged_in", {'room': room1});
    });
    _socket.emit("join_pm", {'room1': room1, 'room2': room2});
    _socket.on("new_private_message", (data) {
      setState(() {
        _messages.add(ChatMessage.fromMap(data));
      });
    });
    _socket.connect();
  }

  String swapRoom(String room) {
    var temp = room.split("-");
    return '${temp.last}-${temp.first}';
  }

  void fetchChats() async {
    try {
      var result = await _chatProvider
          .fetchChatMessage(widget.arguments['room'].split("-").last);
      if (result.isNotEmpty && result is List<ChatMessage>) {
        setState(() {
          _isLoading = false;
          _messages = result;
          if (result.length < 50) _hasData = false;
        });
        Future.delayed(Duration(seconds: 1), () {
          chatScrollController.animateTo(
            chatScrollController.position.maxScrollExtent,
            duration: Duration(milliseconds: 200),
            curve: Curves.ease,
          );
        });
      } else
        setState(() {
          _hasData = false;
          _isLoading = false;
        });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      print(e);
      throw e;
    }
  }

  void sendMessage(dynamic message) {
    if (_isSending) return;
    setState(() {
      _isSending = true;
    });
    _socket.emitWithAck('send_private_message', {
      'message': message,
      'sender': widget.arguments['room'].split('-').first,
      'receiver': widget.arguments['room'].split('-').last,
      'room': widget.arguments['room']
    }, ack: (response) {
      print('sent m');
      _messageController.text = "";
      chatScrollController.animateTo(
        chatScrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 200),
        curve: Curves.ease,
      );
      setState(() {
        _isSending = false;
      });
    });
  }

  void sendImageMessage(dynamic message, String publicId) {
    _socket.emitWithAck('send_private_image_message', {
      'message': message,
      'sender': widget.arguments['room'].split('-').first,
      'receiver': widget.arguments['room'].split('-').last,
      'room': widget.arguments['room'],
      'publid_id': publicId
    }, ack: (response) {
      print('sent image');
      _messageController.text = "";
      chatScrollController.animateTo(
        chatScrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 200),
        curve: Curves.ease,
      );
    });
  }

  emitTyping() {
    print("typing");

    _socket.emitWithAck('typing', {'room': widget.arguments['room']}, ack: () {
      // _messageController.text = "";
    });
  }

  emitNotTyping() {
    print("stop typing");
    _socket.emitWithAck('nottyping', {'room': widget.arguments['room']},
        ack: () {
      // _messageController.text = "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
            icon: platformBackButton(),
            onPressed: () {
              Navigator.pop(context);
            }),
        toolbarHeight: 80.0,
        title: Row(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, RouteConstants.UserProfileScreen,
                    arguments: {
                      'uid': _otherUserId,
                      'isFromChat': true,
                    });
              },
              // onTap: () =>
              //     Navigator.pushNamed(context, RouteConstants.ChatScreen),
              child: CircleAvatar(
                radius: 27.0,
                backgroundImage: widget.arguments['image'] == null
                    ? AssetImage("assets/images/default_user.png")
                    : CachedNetworkImageProvider(widget.arguments['image']),
              ),
            ),
            SizeMargin.width(8.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.arguments['username']),
                SizeMargin.height(2.0),
                Text(
                  _isTyping
                      ? "typing ..."
                      : _isLoggedIn
                          ? "Online"
                          : "Offline",
                  style: TextStyle(fontSize: 12.0),
                ),
              ],
            )
          ],
        ),
        actions: [
          if (_selectedId > 0)
            IconButton(
                icon: Icon(Icons.delete),
                onPressed: () async {
                  try {
                    progressModal(context);
                    bool result =
                        await _chatProvider.deleteUserChat(_selectedId);
                    if (result) {
                      showToast("Chat deleted");
                      _messages.removeWhere((m) => m.id == _selectedId);
                      setState(() {
                        _selectedId = 0;
                      });
                    } else {
                      showToast("Unable to delete, try again");
                    }
                    Navigator.pop(context);
                  } catch (e) {
                    Navigator.pop(context);
                    showToast("An unknown error occured, try again");
                  }
                }),
          PopupMenuButton(
              icon: Icon(Icons.more_vert),
              onSelected: (val) {},
              itemBuilder: (_) => [
                    PopupMenuItem(
                      value: 0,
                      child: Text("Report"),
                    ),
                    // PopupMenuItem(
                    //   value: 1,
                    //   child: Text("Block"),
                    // ),
                  ])
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                  ))
                : _messages.isEmpty
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            FeatherIcons.messageCircle,
                            size: 50.0,
                          ),
                          SizeMargin.height(16.0),
                          Card(
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "No messages here yet...",
                              ),
                            ),
                          )
                        ],
                      )
                    : NotificationListener(
                        onNotification: _scrollNotificationHandler,
                        child: Stack(
                          children: [
                            ListView.builder(
                                controller: chatScrollController,
                                padding: EdgeInsets.all(
                                  20.0,
                                ),
                                itemCount: _messages.length,
                                itemBuilder: (_, index) {
                                  final message = _messages[index];
                                  return chatItem(message);
                                }),
                            if (_isFetching)
                              Align(
                                // top: 20.0,
                                alignment: Alignment.topCenter,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: CircularProgressIndicator(),
                                ),
                              ),
                          ],
                        ),
                      ),
          ),
          chatBottomInput(),
        ],
      ),
      floatingActionButton: _isScrollPositionAtBottom
          ? Container()
          : Container(
              margin: const EdgeInsets.only(bottom: 70.0),
              child: MaterialButton(
                minWidth: 20.0,
                color: AmmColor.white,
                shape: CircleBorder(),
                onPressed: () {
                  chatScrollController
                      .jumpTo(chatScrollController.position.maxScrollExtent);
                },
                child: Icon(Icons.keyboard_arrow_down_sharp),
              ),
            ),
    );
  }

  void _fetchMoreChats() async {
    if (_isFetching) return;

    print("fetching");

    try {
      var result = await _chatProvider.fetchMoreChatMessage(
          widget.arguments['room'].split("-").last, _currentPage);
      if (result.isNotEmpty && result is Map) {
        if (this.mounted)
          setState(() {
            _isFetching = false;
            _hasData = result['messages'].length > 49;
            _messages.insertAll(0, result['messages']);
            _currentPage = result['page'];
            if (_isScrollPositionAtBottom) _isScrollPositionAtBottom = false;
          });
      }
      print("fetched");
    } catch (e) {
      print(e);
    }
  }

  bool _scrollNotificationHandler(Notification notification) {
    // return true;
    if (notification is ScrollNotification) {
      var metrics = chatScrollController.position;
      // print(metrics);
      // if (notification.metrics.atEdge) {
      if (metrics.pixels != metrics.maxScrollExtent)
        setState(() {
          _isScrollPositionAtBottom = false;
        });
      else
        setState(() {
          _isScrollPositionAtBottom = true;
        });
      // }
      // return false;
    }
    // return true;
    if (notification is ScrollEndNotification) {
      if (_isFetching || !_hasData) return true;
      double height = chatScrollController.position.pixels;
      print(height);
      // if(_scrollController.position.maxScrollExtent)
      // print(notification.metrics.pixels);
      if (height <= 1) {
        _fetchMoreChats();
        setState(() {
          _isFetching = true;
        });
      }
      // print(_scrollController.);
    }
    return true;
  }

  Widget chatBottomInput() {
    bool hasSubscribed = context.watch<UserProvider>().isSubscriptionActive;
    return Container(
      height: 80.0,
      margin: EdgeInsets.symmetric(
          horizontal: 20.0, vertical: Platform.isIOS ? 12.0 : 4.0),
      child: Row(
        children: [
          Expanded(
              child: TextField(
            controller: _messageController,
            cursorColor: Colors.grey,
            minLines: 1,
            maxLines: 8,
            onChanged: _onChangeHandler,
            decoration: InputDecoration(
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 12.0, horizontal: 8.0),
              filled: true,
              hintText: "Type your message...",
              border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0)),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0)),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0)),
              suffixIcon: IconButton(
                icon: Icon(
                  FeatherIcons.send,
                  color: Colors.grey,
                ),
                onPressed: _isSendingFile
                    ? null
                    : () {
                        if (_messageController.text.trim().isEmpty) {
                          showToast("Enter a message");
                          return;
                        }
                        sendMessage(_messageController.text);

                        print('sent');
                      },
              ),
            ),
          )),

          if (_messageController.text.trim().length < 1) ...[
            SizeMargin.width(16.0),
            GestureDetector(
              onTap: hasSubscribed
                  ? _imageBottomSheet
                  : () => showToast(
                      "Upgrade to premium subscription to share images"),
              child: Container(
                height: 45.0,
                width: 50.0,
                child: _isSendingFile
                    ? SizedBox(
                        height: 5.0,
                        width: 5.0,
                        child: Center(
                            child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: CircularProgressIndicator(
                            valueColor:
                                AlwaysStoppedAnimation(AmmColor.primaryColor),
                          ),
                        )))
                    : Icon(Icons.camera_alt),
                decoration: ShapeDecoration(
                  color: Colors.grey.shade200,
                  shape: RoundedRectangleBorder(
                      side: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(8.0)),
                ),
              ),
            ),
          ]
          // FlatButton(
          //     minWidth: 20.0,
          //     height: 40.0,
          //     onPressed: () {},
          //     child: Icon(Icons.attach_file))
        ],
      ),
    );
  }

  Widget chatItem(ChatMessage message) {
    var sender = widget.arguments['room'].split('-').first;
    // print(sender);
    // print(""+message.senderId);
    return Container(
      color: message.id == _selectedId
          ? AmmColor.primaryColor.withOpacity(0.2)
          : Colors.transparent,
      padding: EdgeInsets.symmetric(
          horizontal: message.id == _selectedId ? 8.0 : 0.0),
      child: GestureDetector(
        onLongPress: () {
          setState(() {
            _selectedId = message.id;
          });
        },
        onTap: () {
          if (_selectedId > 0)
            setState(() {
              _selectedId = 0;
            });
        },
        child: Row(
          mainAxisAlignment: message.senderId != int.tryParse(sender)
              ? MainAxisAlignment.start
              : MainAxisAlignment.end,
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 6.0),
              constraints: BoxConstraints(
                maxWidth: SizeMargin.fullScreenWidth(context, w: 0.7),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child:
                    // Column(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //   mainAxisSize: MainAxisSize.min,
                    //   children: [
                    message.type == 'image'
                        ? GestureDetector(
                            onTap: () {
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (_) {
                                return FullScreenImage(
                                  imageUrl: message.message,
                                  tag: message.publicId,
                                );
                              }));
                            },
                            child: Hero(
                              tag: message.publicId,
                              child: CachedNetworkImage(
                                imageUrl: message.message,
                                placeholder: (_, __) => Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                        message.senderId == int.tryParse(sender)
                                            ? Colors.white
                                            : AmmColor.primaryColor),
                                  ),
                                ),
                                errorWidget: (_, __, ___) => Center(
                                    child:
                                        Icon(Icons.broken_image, size: 60.0)),
                                height:
                                    SizeMargin.fullScreenWidth(context, w: 0.5),
                                width:
                                    SizeMargin.fullScreenWidth(context, w: 0.5),
                              ),
                            ),
                          )
                        : RichText(
                            text: TextSpan(
                              text: "${message.message}",
                              children: <InlineSpan>[
                                TextSpan(
                                  text:
                                      "   ${DateTime.now().difference(message.date).inDays > 2 ? DateFormat.yMEd().format(message.date) : timeago.format(message.date)}",
                                  style: GoogleFonts.lato(
                                      textStyle: TextStyle(
                                        fontSize: 10.0,
                                      ),
                                      height: 1.8),
                                ),
                              ],
                              style: GoogleFonts.lato(
                                textStyle: TextStyle(
                                    color:
                                        message.senderId != int.tryParse(sender)
                                            ? Colors.black
                                            : Colors.white),
                              ),
                            ),
                          ),
              ),
              decoration: ShapeDecoration(
                color: message.type == 'image'
                    ? Colors.grey
                    : message.senderId != int.tryParse(sender)
                        ? Colors.grey.shade200
                        : AmmColor.primaryColor,
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(8.0)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _uploadImage(ImageSource source) async {
    Navigator.pop(context);
    final PickedFile pickedFile = await picker.getImage(source: source);
    if (pickedFile != null) {
      var result = await Navigator.push(context,
          MaterialPageRoute(builder: (_) => ShowImage(File(pickedFile.path))));
      if (result is File) {
        uploadChatImage(result);
      } else {
        showToast("Operation has been cancelled");
      }
    } else {
      showToast("Operation was cancelled");
    }
  }

  void _imageBottomSheet() {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10.0),
          topRight: Radius.circular(10.0),
        ),
      ),
      context: context,
      builder: (_) {
        return Container(
          height: 150.0,
          padding: const EdgeInsets.all(36.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  _uploadImage(ImageSource.gallery);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.file_upload,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Gallery", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
              SizeMargin.width(24.0),
              GestureDetector(
                onTap: () {
                  _uploadImage(ImageSource.camera);
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24.0,
                      backgroundColor: AmmColor.primaryColor,
                      child: Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(6.0),
                    Text("Camera", style: TextStyle(fontSize: 16.0))
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void uploadChatImage(File image) async {
    setState(() {
      _isSendingFile = true;
    });
    try {
      var result = await Provider.of<ChatProvider>(context, listen: false)
          .addChatImage(image);
      if (result.isNotEmpty) {
        sendImageMessage(result['url'], result['public_id']);
      }
      setState(() {
        _isSendingFile = false;
      });
    } catch (e) {
      setState(() {
        _isSendingFile = false;
      });
      showToast("Unable to upload image");
      throw e;
    }
  }

  Timer searchOnStoppedTyping;

  _onChangeHandler(String value) {
    const duration = Duration(
        milliseconds:
            800); // set the duration that you want call search() after that.
    if (searchOnStoppedTyping != null) {
      emitTyping();
      setState(() => searchOnStoppedTyping.cancel()); // clear timer
    }
    setState(() => searchOnStoppedTyping = new Timer(duration, emitNotTyping));
  }
}
