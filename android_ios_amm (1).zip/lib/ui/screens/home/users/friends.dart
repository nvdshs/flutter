import 'package:amm/app/route_constants.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../utils.dart';

class FriendsScreen extends StatefulWidget {
  @override
  _FriendsScreenState createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  bool _isLoadingFriends = true;
  bool _isLoadingFriendRequests = true;
  @override
  void initState() {
    super.initState();
    fetchFriends();
    fetchFriendRequests();
  }

  void fetchFriends() async {
    try {
      await Provider.of<UserProvider>(context, listen: false).fetchFriends();
      setState(() {
        _isLoadingFriends = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingFriends = false;
      });
    }
  }

  void fetchFriendRequests() async {
    try {
      await Provider.of<UserProvider>(context, listen: false)
          .fetchFriendRequests();
      setState(() {
        _isLoadingFriendRequests = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingFriendRequests = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0.0,
          centerTitle: true,
          leading: IconButton(
              icon: platformBackButton(),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: Image.asset(
            "assets/images/logo1.png",
            width: 80.0,
          ),
          bottom: TabBar(
            indicatorColor: AmmColor.primaryColor,
            tabs: [
              Tab(
                text: "Friends List",
              ),
              Tab(
                text: "Friend Requests",
              )
            ],
          ),
        ),
        body: Consumer<UserProvider>(
            //
            builder: (_, uProvider, __) {
          return TabBarView(
            children: [
              _isLoadingFriends
                  ? loadingFriends()
                  : uProvider.friends.isEmpty
                      ? emptyFriends(true)
                      : ListView.separated(
                          padding: const EdgeInsets.only(top: 12.0),
                          itemCount: uProvider.friends.length,
                          itemBuilder: (BuildContext context, int index) {
                            var user = uProvider.friends[index];
                            return Container(
                              padding: const EdgeInsets.only(bottom: 4.0),
                              child: ListTile(
                                onTap: () => Navigator.pushNamed(
                                    context, RouteConstants.UserProfileScreen,
                                    arguments: {
                                      'uid': user.uid,
                                      'isFromChat': false
                                    }),
                                leading: CircleAvatar(
                                  radius: 35.0,
                                  backgroundImage: user.photo == null
                                      ? AssetImage(
                                          "assets/images/default_user.png")
                                      : CachedNetworkImageProvider(user.photo),
                                ),
                                title: Text(user.name),
                                subtitle: Text(
                                  user.dob == null
                                      ? "@${user.username}"
                                      : "${(DateTime.now().difference(user.dob).inDays / 365).round()} years",
                                ),
                              ),
                            );
                          },
                          separatorBuilder: (_, __) {
                            return Divider();
                          },
                        ),
              _isLoadingFriendRequests
                  ? loadingFriends()
                  : uProvider.friendsRequests.isEmpty
                      ? emptyFriends(false)
                      : ListView.separated(
                          padding: const EdgeInsets.only(top: 12.0),
                          itemCount: uProvider.friendsRequests.length,
                          itemBuilder: (BuildContext context, int index) {
                            var user = uProvider.friendsRequests[index];
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 4.0, horizontal: 12.0),
                              margin: EdgeInsets.only(bottom: 8.0),
                              child: Row(
                                children: [
                                  GestureDetector(
                                    onTap: () => Navigator.pushNamed(context,
                                        RouteConstants.UserProfileScreen,
                                        arguments: {
                                          'uid': user.uid,
                                          'isFromChat': false
                                        }),
                                    child: CircleAvatar(
                                      radius: 35.0,
                                      backgroundImage: user.photo == null
                                          ? AssetImage(
                                              "assets/images/default_user.png")
                                          : CachedNetworkImageProvider(
                                              user.photo),
                                    ),
                                  ),
                                  SizeMargin.width(12.0),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        GestureDetector(
                                          onTap: () => Navigator.pushNamed(
                                              context,
                                              RouteConstants.UserProfileScreen,
                                              arguments: {
                                                'uid': user.uid,
                                                'isFromChat': false
                                              }),
                                          child: Text(
                                            user.name,
                                            style: GoogleFonts.lato(
                                              textStyle: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ),
                                        SizeMargin.height(12.0),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: MaterialButton(
                                                elevation: 0.0,
                                                // height: 50.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          6.0),
                                                  // side: BorderSide(
                                                  //   color: AmmColor.primaryColor,
                                                  // ),
                                                ),
                                                textColor: AmmColor.white,
                                                color: AmmColor.primaryColor,
                                                child: Text(
                                                  "Confirm",
                                                  style: TextStyle(),
                                                ),
                                                onPressed: () =>
                                                    _confirmFriendRequest(
                                                        user.uid, index),
                                              ),
                                            ),
                                            SizeMargin.width(16.0),
                                            Expanded(
                                              child: MaterialButton(
                                                elevation: 0.0,
                                                // height: 50.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          6.0),
                                                  side: BorderSide(
                                                    color:
                                                        AmmColor.primaryColor,
                                                  ),
                                                ),
                                                // color: AmmColor.primaryColor,
                                                textColor:
                                                    AmmColor.primaryColor,
                                                child: Text(
                                                  "Delete",
                                                  style: TextStyle(),
                                                ),
                                                onPressed: () =>
                                                    showCancelFriendRequestModal(
                                                        user.uid, index),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                          separatorBuilder: (_, __) {
                            return Divider();
                          },
                        ),
            ],
          );
        }),
      ),
    );
  }

  Widget emptyFriends(bool isFriend) {
    return
        // Container(
        //   height: SizeMargin.fullScreenHeight(context, h: 0.8),
        //   child:
        Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 60.0,
              backgroundColor: AmmColor.primaryColor,
              child: Icon(
                FeatherIcons.users,
                size: 60.0,
              ),
            ),
            SizeMargin.height(16.0),
            Text(
              isFriend
                  ? "You have no friends presently"
                  : "You have no friend requests presently",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
              ),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(16.0),
            Text(
              isFriend
                  ? "Add friends so they can display here"
                  : "When people send you friend requests they display here",
              style: GoogleFonts.lato(
                textStyle:
                    TextStyle(fontSize: 16.0, color: AmmColor.secondaryColor),
              ),
              textAlign: TextAlign.center,
            ),
          ],
          // ),
        ),
      ),
    );
  }

  Widget loadingFriends() {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.grey[100],
        enabled: true,
        child: ListView(
            padding: const EdgeInsets.all(8.0),
            children: List.generate(6, (index) {
              return Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 60.0,
                          width: 60.0,
                          decoration: ShapeDecoration(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0)),
                            color: Colors.white,
                          ),
                        ),
                        SizeMargin.width(16.0),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 10.0,
                              width: 120.0,
                              color: Colors.white,
                            ),
                            SizeMargin.height(16.0),
                            Container(
                              height: 10.0,
                              width: 200.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                        Spacer(),
                        Container(
                          height: 6.0,
                          width: 20.0,
                          color: Colors.white,
                        ),
                      ],
                    ),
                    Divider(),
                  ],
                ),
              );
            })));
  }

  void _confirmFriendRequest(int uid, int index) async {
    _onLoading();
    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .acceptFriendRequest(uid);
      if (result) {
        Provider.of<UserProvider>(context, listen: false)
            .removeFriendRequest(index);
        showToast("Friend request accepted");
        Navigator.pop(context);
      } else {
        showToast("Unable to accept request");
        Navigator.pop(context);
      }
    } catch (e) {
      Navigator.pop(context);
      showToast("an error occured");
      throw e;
    }
  }

  void _rejectFriendRequest(int uid, int index) async {
    _onLoading();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .rejectFriendRequest(uid);
      if (result) {
        Provider.of<UserProvider>(context, listen: false)
            .removeFriendRequest(index);
        Navigator.pop(context);
        showToast("Friend request rejected");
      } else {
        Navigator.pop(context);
        showToast("Unable to reject friend request");
      }
    } catch (e) {
      showToast("Something is wrong, try again!");
      Navigator.pop(context);
    }
  }

  void _onLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () => Future.value(false),
          child: Dialog(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AmmColor.primaryColor),
                  ),
                  SizeMargin.width(8.0),
                  const Text("Please wait..."),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void showCancelFriendRequestModal(int uid, int index) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text("Are you sure ?"),
              actions: [
                MaterialButton(
                  elevation: 0.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6.0),
                    side: BorderSide(color: AmmColor.primaryColor),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  textColor: AmmColor.primaryColor,
                  child: Text("Cancel"),
                ),
                MaterialButton(
                  elevation: 0.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6.0),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    _rejectFriendRequest(uid, index);
                  },
                  child: Text("Proceed"),
                  textColor: Colors.white,
                  color: AmmColor.primaryColor,
                ),
              ],
            ));
  }
}
