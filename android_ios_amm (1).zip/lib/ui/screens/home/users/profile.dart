import 'package:amm/app/route_constants.dart';
import 'package:amm/core/models/friend.dart';
import 'package:amm/core/models/gallery_image.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/ui/screens/home/gallery.dart';
import 'package:amm/ui/widgets/profile_header.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../utils.dart';

class UserProfileScreen extends StatefulWidget {
  final int uid;
  final bool isFromChat;
  UserProfileScreen({@required this.uid, @required this.isFromChat});
  @override
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  List<GalleryImage> _galleryImages = [];
  Friend _theUser;
  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    print(widget.uid);
    // if (widget.friend is Friend) {
    //   _theUser = widget.friend;
    // } else {
    fetchProfile();
    // }
  }

  void fetchProfile() async {
    try {
      var result = await Provider.of<UserProvider>(context, listen: false)
          .fetchUserProfile(widget.uid);

      if (result is Friend) {
        var res = await Provider.of<UserProvider>(context, listen: false)
            .fetchUserGalleryImages(result.uid);
        setState(() {
          if (res is List<GalleryImage>) _galleryImages = res;
          _theUser = result;
        });
      }
    } catch (e) {
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    var user = context.watch<UserProvider>().currentUser;
    return Scaffold(
      body: SafeArea(
        child: _theUser == null
            ? loadingUser()
            : SingleChildScrollView(
                child: Column(
                  children: [
                    Stack(
                      children: [
                        ProfileHeader(
                          imageUrl: _theUser.photo,
                          coverUrl: _theUser.cover,
                          avatar: _theUser.photo == null
                              ? AssetImage("assets/images/default_user.png")
                              : CachedNetworkImageProvider(_theUser.photo),
                          coverImage: _theUser.cover == null
                              ? null
                              : CachedNetworkImageProvider(_theUser.cover),
                          title: "${_theUser.name}",
                          subtitle: "@${_theUser.username}",
                          actions: <Widget>[
                            // MaterialButton(
                            //   color: Colors.white,
                            //   shape: CircleBorder(),
                            //   elevation: 0,
                            //   child: Icon(Icons.edit),
                            //   onPressed: () {},
                            // )
                          ],
                        ),
                        IconButton(
                            icon: platformBackButton(),
                            color: Colors.white,
                            onPressed: () {
                              Navigator.pop(context);
                            })
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (_theUser.bio != null)
                            Text(
                              _theUser.bio,
                              style: GoogleFonts.poppins(
                                color: Color(0XFFA0A0A0),
                              ),
                              textAlign: TextAlign.center,
                            ),
                          SizeMargin.height(16.0),
                          Row(
                            children: [
                              Expanded(
                                child: _buildFriendButton(_theUser),
                              ),
                              if (_theUser.isFriend) ...[
                                SizeMargin.width(16.0),
                                Expanded(
                                  child: MaterialButton(
                                    elevation: 0.0,
                                    height: 50.0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      // side: BorderSide(
                                      //   color: AmmColor.primaryColor,
                                      // ),
                                    ),
                                    textColor: AmmColor.white,
                                    color: AmmColor.primaryColor,
                                    child: Text(
                                      "Chat",
                                      style: TextStyle(),
                                    ),
                                    onPressed: () {
                                      if (widget.isFromChat) {
                                        Navigator.pop(context);
                                      } else {
                                        Navigator.pushNamed(
                                            context, RouteConstants.ChatScreen,
                                            arguments: {
                                              'username': _theUser.username,
                                              'image': _theUser.photo,
                                              'room':
                                                  '${user.uid}-${_theUser.uid}'
                                            });
                                      }
                                    },
                                  ),
                                ),
                              ]
                            ],
                          ),
                          SizeMargin.height(16.0),
                          if (_theUser.dob != null)
                            _tile("Born on",
                                DateFormat.yMMMd().format(_theUser.dob)),
                          if (_theUser.gender != null)
                            _tile("Gender", _theUser.gender),
                          if (_theUser.likes != null)
                            _tile("Hobbies", _theUser.likes),
                          if (_theUser.dislikes != null)
                            _tile("Interests", _theUser.dislikes),
                          if (_theUser.ethnicity != null)
                            _tile(
                                "Ethnicity", getEthnicity(_theUser.ethnicity)),
                          if (_theUser.city != null)
                            _tile("State/Country", _theUser.city),
                          if (_theUser.church != null)
                            _tile("Church", _theUser.church),
                          if (_theUser.doctrine != null)
                            _tile("Denomination", _theUser.doctrine),
                          SizeMargin.height(4.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Photos",
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 18.0,
                                ),
                              ),
                              MaterialButton(
                                elevation: 0.0,
                                onPressed: () {
                                  if (_galleryImages.isEmpty) return;
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => GalleryScreen(
                                              _theUser.username,
                                              _galleryImages)));
                                },
                                child: Text("Gallery"),
                                textColor: AmmColor.primaryColor,
                                height: 28.0,
                              )
                            ],
                          ),
                          Divider(
                            height: 2.0,
                          ),
                          _galleryImages.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.image_search,
                                        size: 80.0,
                                      ),
                                      SizeMargin.height(16.0),
                                      Text(
                                        "${_theUser.username} gallery is empty!",
                                        style: TextStyle(fontSize: 18.0),
                                      ),
                                      SizeMargin.height(8.0),
                                      Text(
                                        "Their gallery images appear here when they post.",
                                        style: TextStyle(
                                          fontSize: 12.0,
                                          color: Colors.grey,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                )
                              : GridView.builder(
                                  padding: const EdgeInsets.only(top: 12.0),
                                  itemCount: _galleryImages.take(8).length,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    var image =
                                        _galleryImages.take(8).toList()[index];
                                    return Container(
                                      margin: const EdgeInsets.only(
                                          left: 8.0, right: 8.0),
                                      height: 150,
                                      // width: 180.0,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: CachedNetworkImageProvider(
                                            image.url,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          mainAxisSpacing: 8.0,
                                          childAspectRatio: 1.1),
                                )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _tile(String title, String content) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
          ),
          SizeMargin.height(2.0),
          Text(
            content,
            style: GoogleFonts.poppins(fontSize: 12.0),
          ),
        ],
      ),
    );
  }

  Widget loadingUser() {
    return Column(
      children: [
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: IconButton(
                  icon: platformBackButton(),
                  onPressed: () {
                    Navigator.pop(context);
                  }),
            ),
          ],
        ),
        Expanded(
          child: Shimmer.fromColors(
            baseColor: Colors.grey[300],
            highlightColor: Colors.grey[100],
            enabled: true,
            child: ListView(
              //m
              padding: const EdgeInsets.all(16.0),
              children: [
                Container(
                  height: 120.0,
                  width: 60.0,
                  decoration: ShapeDecoration(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2.0)),
                    color: Colors.white,
                  ),
                ),
                SizeMargin.height(4.0),
                Column(
                  children: [
                    Container(
                      height: 80.0,
                      width: 80.0,
                      decoration: ShapeDecoration(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(40.0)),
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizeMargin.height(4.0),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        height: 10.0,
                        width: 150.0,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(16.0),
                    Center(
                      child: Container(
                        height: 10.0,
                        width: 200.0,
                        color: Colors.white,
                      ),
                    ),
                    SizeMargin.height(16.0),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 50.0,
                            width: 150.0,
                            decoration: ShapeDecoration(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6.0)),
                              color: Colors.white,
                            ),
                          ),
                          Container(
                            height: 50.0,
                            width: 150.0,
                            decoration: ShapeDecoration(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6.0)),
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizeMargin.height(16.0),
                    ...List.generate(
                      5,
                      (index) => Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 8.0,
                              width: 200.0,
                              color: Colors.white,
                            ),
                            SizeMargin.height(16.0),
                            Container(
                              height: 8.0,
                              width: 250.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ],
    );
    // ]));
  }

  Widget _buildFriendButton(Friend user) {
    if (user.sentFriendRequest)
      return TextButton.icon(
        style: ButtonStyle(
          minimumSize: MaterialStateProperty.resolveWith(
              (_) => Size(double.minPositive, 50.0)),
          shape:
              MaterialStateProperty.resolveWith((_) => RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  )),
          foregroundColor: MaterialStateProperty.resolveWith(
            (_) => Colors.white,
          ),
          backgroundColor: MaterialStateProperty.resolveWith(
            (_) => AmmColor.primaryColor,
          ),
        ),
        label: _isLoading
            ? loader()
            : Text(
                "Respond",
                style: TextStyle(),
              ),
        icon: Icon(FeatherIcons.userCheck),
        onPressed: _isLoading ? () {} : _showRequestBottomSheet,
      );
    else if (user.youSentRequest)
      return MaterialButton(
        elevation: 0.0,
        height: 50.0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
            side: BorderSide(
              color: AmmColor.primaryColor,
            )),
        textColor: AmmColor.primaryColor,
        // color: AmmColor.primaryColor,
        child: _isLoading
            ? loader(color: AmmColor.primaryColor)
            : Text(
                "Cancel request",
                style: TextStyle(),
              ),
        onPressed: _isLoading ? () {} : _cancelFriendRequest,
      );
    else if (user.isFriend)
      return TextButton.icon(
        style: ButtonStyle(
          minimumSize: MaterialStateProperty.resolveWith(
              (_) => Size(double.minPositive, 50.0)),
          shape: MaterialStateProperty.resolveWith(
            (_) => RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
              side: BorderSide(color: AmmColor.primaryColor),
            ),
          ),
          foregroundColor: MaterialStateProperty.resolveWith(
            (_) => AmmColor.primaryColor,
          ),
        ),
        label: _isLoading
            ? loader(color: AmmColor.primaryColor)
            : Text(
                "Unfriend",
                style: TextStyle(),
              ),
        icon: Icon(FeatherIcons.userMinus),
        onPressed: showDeleteFriendModal,
      );
    else
      return TextButton.icon(
          style: ButtonStyle(
            minimumSize: MaterialStateProperty.resolveWith(
                (_) => Size(double.minPositive, 50.0)),
            shape: MaterialStateProperty.resolveWith(
              (_) => RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(
                  color: AmmColor.primaryColor,
                ),
              ),
            ),
            foregroundColor: MaterialStateProperty.resolveWith(
              (_) => AmmColor.primaryColor,
            ),
          ),
          label: _isLoading
              ? loader(color: AmmColor.primaryColor)
              : Text(
                  "Add friend",
                  style: TextStyle(),
                ),
          icon: Icon(Icons.person_add),
          onPressed: _isLoading ? () {} : _addFriend);
  }

  /*
    * METHODS FOR FRIEND SERVICES
  */
  void _addFriend() async {
    setBusy();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .addFriend(_theUser.uid);
      if (result) {
        setState(() {
          _theUser.youSentRequest = result;
          _isLoading = false;
        });
        showToast("Friend request sent");
      } else {
        showToast("Unable to send friend request, try again");
        setBusy(busy: false);
      }
    } catch (e) {
      showToast("Unable to send friend request");
      setBusy(busy: false);
    }
  }

  void _cancelFriendRequest() async {
    setBusy();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .cancelFriendRequest(_theUser.uid);
      if (result) {
        setState(() {
          _theUser.youSentRequest = false;
          _isLoading = false;
        });
        showToast("Friend request cancelled");
      } else {
        setBusy(busy: false);
      }
    } catch (e) {
      showToast("Unable to cancel friend request");
      setBusy(busy: false);
    }
  }

  void _confirmFriendRequest() async {
    setBusy();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .acceptFriendRequest(_theUser.uid);
      if (result) {
        setState(() {
          _theUser.sentFriendRequest = false;
          _theUser.isFriend = true;
          _isLoading = false;
        });
        showToast("Friend request accepted");
      } else {
        setBusy(busy: false);
      }
    } catch (e) {
      showToast("Unable to accept friend request");
      setBusy(busy: false);
    }
  }

  void _rejectFriendRequest() async {
    setBusy();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .rejectFriendRequest(_theUser.uid);
      if (result) {
        setState(() {
          _theUser.sentFriendRequest = false;
          _isLoading = false;
        });
        showToast("Friend request rejected");
      } else {
        setBusy(busy: false);
      }
    } catch (e) {
      showToast("Unable to reject friend request");
      setBusy(busy: false);
    }
  }

  void _deleteFriend() async {
    setBusy();

    try {
      bool result = await Provider.of<UserProvider>(context, listen: false)
          .deleteFriend(_theUser.uid);
      if (result) {
        setState(() {
          _theUser.isFriend = false;
          _isLoading = false;
        });
        showToast("Friend deleted");
      } else {
        setBusy(busy: false);
      }
    } catch (e) {
      showToast("Unable to delete friend");
      setBusy(busy: false);
    }
  }

  /*
    * METHODS FOR FRIEND SERVICES
  */

  Widget loader({Color color = Colors.white}) {
    return SizedBox(
      height: 20,
      width: 20,
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation(color),
        strokeWidth: 2.0,
      ),
    );
  }

  void setBusy({bool busy = true}) {
    setState(() {
      _isLoading = busy;
    });
  }

  void _showRequestBottomSheet() {
    showModalBottomSheet(
        context: context,
        builder: (_) {
          return Container(
            padding: EdgeInsets.only(top: 12.0),
            height: 150.0,
            child: Column(
              children: [
                ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    _confirmFriendRequest();
                  },
                  leading: CircleAvatar(
                    backgroundColor: Colors.green,
                    child: Icon(Icons.check),
                  ),
                  title: Text("Confirm"),
                ),
                ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    _rejectFriendRequest();
                  },
                  leading: CircleAvatar(
                    backgroundColor: AmmColor.primaryColor,
                    child: Icon(Icons.clear),
                  ),
                  title: Text("Delete request"),
                ),
              ],
            ),
          );
        });
  }

  void showDeleteFriendModal() {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text("Are you sure ?"),
              actions: [
                MaterialButton(
                  elevation: 0.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6.0),
                    side: BorderSide(color: AmmColor.primaryColor),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  textColor: AmmColor.primaryColor,
                  child: Text("Cancel"),
                ),
                MaterialButton(
                  elevation: 0.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6.0),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    _deleteFriend();
                  },
                  child: Text("Proceed"),
                  textColor: Colors.white,
                  color: AmmColor.primaryColor,
                ),
              ],
            ));
  }
}
