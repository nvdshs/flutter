import 'package:amm/app/route_constants.dart';
import 'package:amm/core/models/user.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/core/services/location_service.dart';
import 'package:amm/ui/widgets/show_webview.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import './subscription_screen.dart';
import '../../utils.dart';
import 'edit_password.dart';
import 'edit_profile.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0.0,
        leading: IconButton(
            icon: platformBackButton(),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: Text(
          "Settings",
          style: Theme.of(context).textTheme.headline5,
        ),
      ),
      body: Consumer<UserProvider>(
          //
          builder: (_, uProvider, __) {
        var user = uProvider.currentUser;
        return SingleChildScrollView(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              _subscriptionCard(user),
              ListTile(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => EditProfileScreen()));
                },
                title: Text("Edit Profile"),
              ),
              Divider(),
              ListTile(
                // onTap: () {},
                title: Text("Notifications"),
                trailing: Switch.adaptive(
                    value: uProvider.notificationPreference,
                    activeTrackColor: Colors.green,
                    onChanged: (val) {
                      Provider.of<UserProvider>(context, listen: false)
                          .setNotification(val);
                      // setState(() {
                      //   _isNotifcationActive = !_isNotifcationActive;
                      // });
                    }),
              ),
              Divider(),
              ListTile(
                // onTap: () {},
                title: Text("Search Preferences"),
                trailing: Switch.adaptive(
                    value: uProvider.searchPreference,
                    activeTrackColor: Colors.green,
                    onChanged: (val) {
                      Provider.of<UserProvider>(context, listen: false)
                          .setSearchPreference(val);
                      // setState(() {
                      //   _isSearchPreferenceActive = !_isSearchPreferenceActive;
                      // });
                    }),
              ),
              Divider(),
              ListTile(
                // onTap: () {},
                title: Text("Enable Location Search"),
                subtitle: Text(
                  "Get to see people close to you in search results and also be visible to others.",
                  style: TextStyle(fontSize: 12.0),
                ),
                trailing: Switch.adaptive(
                    value: uProvider.isSubscriptionActive
                        ? uProvider.locationPreference
                        : false,
                    activeTrackColor: Colors.green,
                    onChanged: (val) async {
                      if (uProvider.isSubscriptionActive) {
                        if (val) {
                          var location = await getUserLocation();
                          if (location is LocationData) {
                            Provider.of<UserProvider>(context, listen: false)
                                .setLocationPreference(val);
                          } else {
                            showToast("Unable to get location");
                          }
                        } else {
                          Provider.of<UserProvider>(context, listen: false)
                              .setLocationPreference(val);
                        }
                      } else {
                        showToast("Upgrade to premium to use this feature");
                      }
                    }),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => DisplayWebview(
                                url: "https://myammapp.com/terms",
                              )));
                },
                title: Text("Terms & Privacy"),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => EditPasswordScreen(),
                    ),
                  );
                },
                title: Text("Change password"),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => DisplayWebview(
                                url: "https://myammapp.com",
                              )));
                },
                title: Text("About"),
              ),
              Divider(),
              SizeMargin.height(24.0),
              ListTile(
                onTap: _logoutModal,
                title: Text(
                  "Logout",
                  style: TextStyle(
                    color: AmmColor.primaryColor.withOpacity(0.5),
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        );
      }),
      bottomNavigationBar: Container(
        height: 80.0,
        alignment: Alignment.center,
        child: Text(
          "v 1.0.0",
          style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
        ),
      ),
    );
  }

  Widget _subscriptionCard(User user) {
    return GestureDetector(
      onTap: () => showSubscriptionDialog(
          user.subscriptionStatus, user.subscriptionExpiry),
      child: Card(
        elevation: 0.0,
        margin: EdgeInsets.symmetric(vertical: 16.0),
        color: AmmColor.primaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Subscription \nPackage",
                    style: GoogleFonts.lato(
                      textStyle: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20.0),
                    ),
                  ),
                  SizeMargin.height(8.0),
                  // Spacer(),
                  RichText(
                    text: TextSpan(
                      text: user.subscriptionExpiry == null
                          ? "Inactive "
                          : user.subscriptionExpiry.isAfter(DateTime.now())
                              ? "Active"
                              : "Inactive",
                      children: <InlineSpan>[
                        TextSpan(
                          text: " .  ${_getStatus(user.subscriptionStatus)}",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                              // color: Colors.white,
                              fontWeight: FontWeight.bold,
                              // fontSize: 20.0
                            ),
                          ),
                        ),
                      ],
                      style: GoogleFonts.lato(
                        textStyle: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  )
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CircleAvatar(
                    radius: 28.0,
                    backgroundColor: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Image.asset("assets/images/logo4.png"),
                    ),
                  ),
                  MaterialButton(
                    height: 30.0,
                    shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(12.0)),
                    textColor: Colors.white,
                    // minWidth: double.infinity,
                    onPressed: _navigateToSubscriptionPage,
                    child: Text(
                      "Info",
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _logoutModal() {
    showDialog(
        context: context,
        builder: (_) {
          return AlertDialog(
            title: Text("Are you sure you want to logout?"),
            actions: [
              MaterialButton(
                elevation: 0.0,
                child: Text("No"),
                onPressed: () {
                  Navigator.pop(context);
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4.0),
                ),
                color: AmmColor.blue,
              ),
              MaterialButton(
                elevation: 0.0,
                child: Text("Yes"),
                onPressed: () async {
                  try {
                    await Provider.of<UserProvider>(context, listen: false)
                        .logout();
                    Navigator.pushNamedAndRemoveUntil(
                        context,
                        RouteConstants.LoginScreen,
                        (_) => !Navigator.canPop(context));
                  } catch (e) {
                    showToast("Unable to logout");
                  }
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4.0),
                    side: BorderSide(color: Colors.red[700])),
                textColor: Colors.red[700],
              )
            ],
          );
        });
  }

  String _getStatus(String status) {
    switch (status) {
      case 'free':
        return 'Free';
      case 'none':
        return 'Inactive';
      case '1_month':
        return 'Monthly';
      case '3_month':
        return '3 Months';
      default:
        return 'none';
    }
  }

  void showSubscriptionDialog(String subType, DateTime expiry) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) {
          return Dialog(
            backgroundColor: Colors.transparent,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Card(
                  elevation: 0.0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(36.0),
                    child: Column(
                      children: [
                        Text(
                          "Subscription status",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 22.0, fontWeight: FontWeight.bold),
                          ),
                        ),
                        if (expiry != null && expiry is DateTime) ...[
                          SizeMargin.height(6.0),
                          RichText(
                            text: TextSpan(
                              text: "Expires On: ",
                              children: <InlineSpan>[
                                TextSpan(
                                  text: DateFormat.yMMMEd().format(expiry),
                                  style: GoogleFonts.lato(
                                    textStyle: TextStyle(
                                        // color: Colors.white,
                                        fontSize: 12.0),
                                  ),
                                ),
                              ],
                              style: GoogleFonts.lato(
                                color: AmmColor.black,
                                fontWeight: FontWeight.bold,
                                textStyle: TextStyle(fontSize: 14.0),
                              ),
                            ),
                          ),
                        ],
                        SizeMargin.height(12.0),
                        Text(
                          expiry == null
                              ? "Inactive"
                              : DateTime.now().isAfter(expiry)
                                  ? "Inactive"
                                  : "Active",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 18.0,
                                color: expiry == null
                                    ? Colors.red
                                    : DateTime.now().isAfter(expiry)
                                        ? Colors.red
                                        : Colors.green),
                          ),
                        ),
                        SizeMargin.height(24.0),
                        if (expiry == null)
                          MaterialButton(
                            height: 40.0,
                            shape: RoundedRectangleBorder(
                                side: BorderSide(color: Colors.green),
                                borderRadius: BorderRadius.circular(12.0)),
                            textColor: Colors.green,
                            minWidth: double.infinity,
                            onPressed: _navigateToSubscriptionPage,
                            child: Text(
                              "Subscribe Now",
                            ),
                          )
                        else if (DateTime.now().isAfter(expiry))
                          MaterialButton(
                            height: 40.0,
                            shape: RoundedRectangleBorder(
                                side: BorderSide(color: Colors.green),
                                borderRadius: BorderRadius.circular(12.0)),
                            textColor: Colors.green,
                            minWidth: double.infinity,
                            onPressed: _navigateToSubscriptionPage,
                            child: Text(
                              "Subscribe Now",
                            ),
                          )
                        else if (subType == 'free')
                          MaterialButton(
                            height: 40.0,
                            shape: RoundedRectangleBorder(
                                side: BorderSide(color: Colors.green),
                                borderRadius: BorderRadius.circular(12.0)),
                            textColor: Colors.green,
                            minWidth: double.infinity,
                            onPressed: _navigateToSubscriptionPage,
                            child: Text(
                              "Upgrade",
                            ),
                          )
                      ],
                    ),
                  ),
                ),
                SizeMargin.height(36.0),
                MaterialButton(
                  height: 45.0,
                  child: Icon(Icons.clear),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  color: Colors.white,
                  shape: CircleBorder(),
                )
              ],
            ),
          );
        });
  }

  void _navigateToSubscriptionPage() {
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => SubscriptionScreen()));
  }
}
