import 'package:amm/core/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';
import '../../utils.dart';
import '../../../app/route_constants.dart';
import '../search_country_city.dart';

class ProfileMatchScreen extends StatefulWidget {
  final bool isFromProfile;
  ProfileMatchScreen({Key key, this.isFromProfile = false}) : super(key: key);

  @override
  _ProfileMatchScreenState createState() => _ProfileMatchScreenState();
}

class _ProfileMatchScreenState extends State<ProfileMatchScreen> {
  SfRangeValues _values = SfRangeValues(25.0, 32.0);
  _GenderType _gender = _GenderType.female;
  String doctrine = 'Catholic';
  String city = '';
  String ethnicity = '';
  List<String> _doctrines = [
    'Catholic',
    'Pentecostal',
    'Celestial',
    'Anglican',
    'Baptist'
  ];
  @override
  void initState() {
    var pref =
        Provider.of<UserProvider>(context, listen: false).friendPreference;
    if (pref != null) {
      doctrine = pref.doctrine;
      ethnicity = pref.ethnicity;
      _gender = pref.gender == 'male' ? _GenderType.male : _GenderType.female;
      city = pref.city;
      _values = SfRangeValues(pref.minAge.toDouble(), pref.maxAge.toDouble());
    }

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0.0,
        automaticallyImplyLeading: false,
        title: Image.asset(
          "assets/images/logo1.png",
          width: 80.0,
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              if (widget.isFromProfile) {
                Navigator.pop(context);
              } else {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    RouteConstants.IndexScreen,
                    (route) => !Navigator.canPop(context));
              }
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // SizeMargin.height(24.0),
            Text(
              "Let’s find the right partner for you!",
              style: GoogleFonts.poppins(
                  fontSize: 22.0, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
            SizeMargin.height(24.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Gender",
                  style: GoogleFonts.poppins(fontSize: 16.0),
                ),
                SizeMargin.height(4.0),
                Row(
                  children: [
                    Expanded(
                      child: _CustomRadio(
                        label: "Male",
                        value: _GenderType.male,
                        groupValue: _gender,
                        onChanged: (_GenderType value) {
                          setState(() {
                            _gender = value;
                          });
                        },
                      ),
                    ),
                    SizeMargin.width(16.0),
                    Expanded(
                      child: _CustomRadio(
                        label: "Female",
                        value: _GenderType.female,
                        groupValue: _gender,
                        onChanged: (_GenderType value) {
                          setState(() {
                            _gender = value;
                          });
                        },
                      ),
                    )
                  ],
                ),
                SizeMargin.height(16.0),
                Text(
                  "Age Range",
                  style: GoogleFonts.poppins(fontSize: 16.0),
                ),
                SizeMargin.height(4.0),
                SfRangeSlider(
                  min: 18.0,
                  max: 100.0,
                  values: _values,
                  interval: 7,
                  showTicks: true,
                  showDivisors: true,
                  // trackShape: SfTrackShape(),
                  showLabels: true,
                  enableTooltip: true,
                  tooltipTextFormatterCallback: (n, m) {
                    return m.substring(0, 2);
                  },
                  activeColor: AmmColor.primaryColor,
                  minorTicksPerInterval: 1,
                  onChanged: (SfRangeValues values) {
                    setState(() {
                      _values = values;
                    });
                    print(values.start.floor());
                    print(values.end.floor());
                  },
                ),
                SizeMargin.height(16.0),
                Text(
                  "Denomination",
                  style: GoogleFonts.poppins(fontSize: 16.0),
                ),
                SizeMargin.height(4.0),
                Container(
                  height: 50.0,
                  padding: const EdgeInsets.all(8.0),
                  decoration: ShapeDecoration(
                      shape: RoundedRectangleBorder(
                    side: BorderSide(color: Color(0XFFE5E5E5)),
                    borderRadius: const BorderRadius.all(
                      const Radius.circular(10.0),
                    ),
                  )),
                  child: DropdownButton(
                    isExpanded: true,
                    underline: Container(),
                    value: doctrine,
                    items: _doctrines
                        .map((doc) => DropdownMenuItem(
                              value: doc,
                              child: Text(doc),
                            ))
                        .toList(),
                    onChanged: (val) {
                      setState(() {
                        doctrine = val;
                      });
                    },
                  ),
                ),
                /*TextField(
                    onChanged: (val) {
                      if (val.trim().length < 20)
                        setState(() {
                          doctrine = val;
                        });
                    },
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0XFFE5E5E5),
                      hintText: "Enter prefered doctrine",
                      border: OutlineInputBorder(
                          borderRadius: const BorderRadius.all(
                            const Radius.circular(10.0),
                          ),
                          borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 12.0),
                    ),
                  ), */
                // Text(
                //   "Enter 'any' to ignore this preference",
                //   style:
                //       GoogleFonts.poppins(fontSize: 12.0, color: Colors.grey),
                // ),
                SizeMargin.height(16.0),
                Text(
                  "State/Country",
                  style: GoogleFonts.poppins(fontSize: 16.0),
                ),
                SizeMargin.height(4.0),
                TextFormField(
                  initialValue: city,
                  readOnly: true,
                  onTap: _handleCityTap,
                  // onChanged: (val) {
                  //   if (val.trim().length < 20)
                  //     setState(() {
                  //       city = val;
                  //     });
                  // },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color(0XFFE5E5E5),
                    hintText: city.isEmpty
                        ? "Enter your prefered state/country"
                        : city,
                    border: OutlineInputBorder(
                        borderRadius: const BorderRadius.all(
                          const Radius.circular(10.0),
                        ),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 12.0),
                  ),
                ),
                SizeMargin.height(16.0),
                Text(
                  "Ethnicity",
                  style: GoogleFonts.poppins(fontSize: 16.0),
                ),
                SizeMargin.height(4.0),
                TextFormField(
                  initialValue:
                      ethnicity.isEmpty ? '' : getEthnicity(ethnicity),
                  readOnly: true,
                  onTap: _showEthnicsBottomSheet,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color(0XFFE5E5E5),
                    hintText: ethnicity.isEmpty
                        ? "Select your prefered ethnicity"
                        : getEthnicity(ethnicity),
                    border: OutlineInputBorder(
                        borderRadius: const BorderRadius.all(
                          const Radius.circular(10.0),
                        ),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 12.0),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
        child: Row(
          children: [
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                // minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                textColor: Colors.white,
                color: AmmColor.primaryColor,
                child: Text(
                  "Find Match",
                  style: TextStyle(),
                ),
                onPressed: () async {
                  if (city.length < 3 || doctrine.length < 3) {
                    showToast("Enter a city and denomination");
                    return;
                  }
                  String gender =
                      _gender == _GenderType.male ? 'male' : 'female';
                  int minAge = _values.start.floor();
                  int maxAge = _values.end.floor();

                  await Provider.of<UserProvider>(context, listen: false)
                      .setPreference(gender, minAge, maxAge, doctrine, city);
                  if (widget.isFromProfile) {
                    Navigator.pop(context, true);
                  } else {
                    Navigator.pushNamedAndRemoveUntil(
                        context,
                        RouteConstants.IndexScreen,
                        (route) => !Navigator.canPop(context));
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleCityTap() async {
    var result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SearchCountryCity()),
    );
    if (result is String)
      setState(() {
        city = result;
      });
  }

  void _showEthnicsBottomSheet() {
    showModalBottomSheet(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        isScrollControlled: true,
        context: context,
        builder: (_) {
          return StatefulBuilder(builder: (_, stateSetter) {
            return Container(
              // height: 400,
              constraints: BoxConstraints(
                  maxHeight: SizeMargin.fullScreenHeight(context, h: 0.8)),
              padding:
                  const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
              child: ListView.builder(
                  // shrinkWrap: true,
                  // physics: Never,
                  itemCount: ethnics.length,
                  itemBuilder: (_, index) {
                    return ListTile(
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          print(ethnics[index]);
                          ethnicity = ethnics[index].slug;
                          // updateUserDetail(ethnics[index].slug, "ethnicity");
                        });
                      },
                      title: Text(ethnics[index].title),
                    );
                  }),
            );
          });
        });
  }
}

class _CustomRadio<T> extends StatelessWidget {
  final String label;
  final T value;
  final T groupValue;
  final ValueChanged<T> onChanged;
  const _CustomRadio(
      {Key key,
      @required this.label,
      @required this.value,
      @required this.groupValue,
      @required this.onChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      elevation: 0.0,
      onPressed: () {
        this.onChanged(this.value);
      },
      child: Text(this.label),
      color: this.value == this.groupValue
          ? AmmColor.primaryColor
          : Color(0XFFE5E5E5),
      textColor:
          this.value == this.groupValue ? AmmColor.white : Color(0XFF000000),
      height: 50.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
    );
  }
}

enum _GenderType { male, female }
