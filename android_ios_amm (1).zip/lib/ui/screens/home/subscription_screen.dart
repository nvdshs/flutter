import 'dart:io';

import 'package:amm/core/providers/user_provider.dart';
import 'package:amm/core/services/payment_service.dart';
import 'package:amm/ui/utils.dart';
import 'package:amm/ui/widgets/show_webview.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({Key key}) : super(key: key);

  @override
  _SubscriptionScreenState createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  /// [$11.99 monthly]
  /// [$30 for 3 months subscription]

  List<_SubscriptionModel> _subscriptions = [
    _SubscriptionModel('3_month', '3 months', "30.00"),
    _SubscriptionModel('1_month', '1 month', "11.99"),
  ];
  _SubscriptionModel _selectedSubscription;

  @override
  void initState() {
    super.initState();
    StripeService.init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        title: Consumer<UserProvider>(builder: (_, uProvider, __) {
          return RichText(
            text: TextSpan(
              text: "Status: ",
              children: [
                TextSpan(
                  text: uProvider.isSubscriptionActive ? 'Active' : 'Inactive',
                  style: TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold),
                ),
              ],
              style: TextStyle(
                color: AmmColor.black,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          );
        }),
        backgroundColor: Color(0XFFFFFFFF),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: CircleAvatar(
              backgroundColor: AmmColor.lightGrey,
              child: IconButton(
                  icon: Icon(
                    Icons.clear,
                    color: AmmColor.black,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  }),
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 36.0,
              backgroundColor: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Image.asset("assets/images/logo4.png"),
              ),
            ),
            SizeMargin.height(12.0),
            Text(
              "Activate Premium",
              style: TextStyle(fontSize: 22.0),
            ),
            SizeMargin.height(8.0),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "Access to all chat features, Get to see people based on your location, enjoy limitless searches, get to set custom preferences, ...etc.",
                textAlign: TextAlign.center,
              ),
            ),
            Row(
              children: [
                Expanded(child: Divider()),
                Chip(
                    label: Text(
                  "Best offers",
                  style: TextStyle(color: Colors.black45),
                )),
                Expanded(child: Divider()),
              ],
            ),
            SizeMargin.height(8.0),
            ..._subscriptions
                .map((subscription) => GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedSubscription = subscription;
                        });
                      },
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 16.0),
                        shape: RoundedRectangleBorder(
                            side: _selectedSubscription == null ||
                                    _selectedSubscription.slug !=
                                        subscription.slug
                                ? BorderSide.none
                                : BorderSide(color: AmmColor.primaryColor),
                            borderRadius: BorderRadius.circular(6.0)),
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: RichText(
                            text: TextSpan(
                              text: "Unlock our premium features for only ",
                              children: [
                                TextSpan(
                                  text: "\$${subscription.amount}",
                                  children: [
                                    TextSpan(
                                      text: "\n${subscription.month}",
                                      style: TextStyle(
                                          fontSize: 18.0,
                                          backgroundColor:
                                              Colors.black.withOpacity(.05),
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                              style: TextStyle(color: AmmColor.black),
                            ),
                          ),

                          // Text(
                          //   "Unlock our premium features for only \$10 monthly",
                          // ),
                        ),
                      ),
                    ))
                .toList(),
            SizeMargin.height(36.0),
            MaterialButton(
              height: 50.0,
              minWidth: double.infinity,
              color: AmmColor.primaryColor,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0)),
              textColor: Colors.white,
              // minWidth: double.infinity,
              onPressed: Platform.isIOS
                  ? _activateNativeSubscription
                  : _activateSubscription,
              child: Text(
                "Activate Now",
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 90.0,
        padding: const EdgeInsets.all(12.0),
        alignment: Alignment.center,
        child: InkWell(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => DisplayWebview(
                          url: "https://myammapp.com/terms",
                        )));
          },
          child: Text("Our T&C and Privacy policy applies"),
        ),
      ),
    );
  }

  void _activateSubscription() async {
    if (_selectedSubscription == null) {
      showToast("Please select a subscription plan");
      return;
    }
    try {
      var result = await StripeService.payWithNewCard(
        context,
        amount: _selectedSubscription.amount,
      );
      if (result.status) {
        await Provider.of<UserProvider>(context, listen: false)
            .updateUserSubscription(_selectedSubscription.slug);
        Navigator.pop(context);
        showToast("Your subscription has been upgraded");
      } else {
        Navigator.pop(context);
        showToast(result.message);
      }
    } catch (e) {
      Navigator.pop(context);
      showToast(e);
    }
  }

  void _activateNativeSubscription() async {
    try {
      var result = await StripeService.payWithNativePay(context, amount: "10");
      if (result.status) {
        showToast(result.message);
      } else {
        // Navigator.pop(context);
        showToast(result.message);
      }
    } catch (e) {
      showToast("Unable to process");
      // Navigator.pop(context);
    }
  }
}

class _SubscriptionModel {
  final String slug;
  final String month;
  final String amount;
  _SubscriptionModel(this.slug, this.month, this.amount);
}
