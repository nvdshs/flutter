import 'package:amm/app/route_constants.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../utils.dart';

class OnboardingScreen extends StatefulWidget {
  OnboardingScreen({Key key}) : super(key: key);

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _current = 0;
  final List<Map<String, dynamic>> _infos = [
    {'title': 'Meet new people', 'content': 'Are You Ready To Find True Love '},
    {'title': 'Find Love', 'content': 'Want To Fall In Love Again'},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AmmColor.primaryColor,
      body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white,
                  AmmColor.primaryColor,
                ],
                tileMode: TileMode.repeated,
                stops: [0.1, 0.9]),
            image: DecorationImage(
              image: AssetImage('assets/images/onboarding${_current + 1}.png'),
              // scale: 1.1,
              alignment: Alignment.topCenter,
              fit: BoxFit.cover,
              colorFilter: new ColorFilter.mode(
                  Colors.red.withOpacity(0.6), BlendMode.dstATop),
            ),
          ),
          height: SizeMargin.fullScreenHeight(context),
          width: double.infinity,
          child: Column(
            children: [
              Expanded(
                child: CarouselSlider(
                  options: CarouselOptions(
                      autoPlay: true,
                      // autoPlayCurve: Curves.,
                      viewportFraction: 1.0,
                      autoPlayAnimationDuration: Duration(seconds: 1),
                      height: double.infinity,
                      onPageChanged: (index, reason) {
                        setState(() {
                          _current = index;
                        });
                      }),
                  items: _infos.map((info) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          width: MediaQuery.of(context).size.width,
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          padding: EdgeInsets.all(20.0),
                          // decoration: BoxDecoration(color: Colors.amber),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Image.asset(
                                "assets/images/logo6.png",
                                width: 70.0,
                              ),
                              SizeMargin.height(16.0),
                              Text(
                                info['title'],
                                style: TextStyle(
                                    fontSize: 24.0,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white),
                              ),
                              SizeMargin.height(16.0),
                              Text(
                                info['content'],
                                style: TextStyle(color: Colors.white),
                              ),
                              SizeMargin.height(36.0),
                            ],
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _infos
                    .map((info) => Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: CircleAvatar(
                            radius: 4.0,
                            backgroundColor: _infos[_current] == info
                                ? Colors.white
                                : Colors.white.withOpacity(0.4),
                          ),
                        ))
                    .toList(),
              )
            ],
          )
          /*  Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image.asset(
              "assets/images/logo6.png",
              width: 70.0,
            ),
            SizeMargin.height(16.0),
            Text(
              "Meet new people",
              style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.w600,
                  color: Colors.white),
            ),
            SizeMargin.height(16.0),
            Text(
              "Are You Ready To Find True Love",
              style: TextStyle( color: Colors.white),
            ),
            SizeMargin.height(16.0),
          ],
        ), */
          ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
        child: Row(
          children: [
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                // minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                color: Colors.white,
                textColor: AmmColor.primaryColor,
                child: Text(
                  "Get Started",
                  style: TextStyle(),
                ),
                onPressed: () {
                  Navigator.popAndPushNamed(
                      context, RouteConstants.SignupScreen);
                },
              ),
            ),
            SizeMargin.width(15.0),
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                // minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                color: Colors.white.withOpacity(0.3),
                textColor: AmmColor.white,
                child: Text(
                  "Login",
                  style: TextStyle(),
                ),
                onPressed: () {
                  Navigator.popAndPushNamed(
                      context, RouteConstants.LoginScreen);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
