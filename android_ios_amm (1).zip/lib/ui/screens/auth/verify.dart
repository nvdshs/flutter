import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/user_provider.dart';
import '../../utils.dart';
import '../../../app/route_constants.dart';

class VerifyUserScreen extends StatefulWidget {
  final String email;
  VerifyUserScreen({Key key, @required this.email}) : super(key: key);

  @override
  _VerifyUserScreenState createState() => _VerifyUserScreenState();
}

class _VerifyUserScreenState extends State<VerifyUserScreen> {
  StreamController<ErrorAnimationType> errorController =
      StreamController<ErrorAnimationType>();
  TextEditingController textEditingController = TextEditingController();
  bool _isSettingPage = true;
  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    setLastPage();
  }

  @override
  void dispose() {
    super.dispose();
    errorController.close();
  }

  void setLastPage() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('page', 'forgot_password');
      await prefs.setString('email', widget.email);
      setState(() {
        _isSettingPage = false;
      });
    } catch (e) {
      setState(() {
        _isSettingPage = false;
      });
      throw e;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(child: Container()),
                      Flexible(child: Container()),
                      Image.asset(
                        "assets/images/logo4.png",
                        width: 80.0,
                      ),
                      Flexible(child: Container()),
                      CircleAvatar(
                        child: IconButton(
                            icon: Icon(Icons.clear),
                            onPressed: () async {
                              SharedPreferences prefs =
                                  await SharedPreferences.getInstance();
                              await prefs.remove('page');
                              await prefs.remove('email');
                              Navigator.popAndPushNamed(
                                  context, RouteConstants.LoginScreen);
                            }),
                      )
                    ]),
                SizeMargin.height(16.0),
                Text(
                  "Your’re almost there!",
                  style: GoogleFonts.poppins(
                      fontSize: 24.0, fontWeight: FontWeight.w600),
                ),
                SizeMargin.height(12.0),
                Center(
                  child: Text(
                    "We sent a 6-digit code to ${widget.email}",
                    style: GoogleFonts.poppins(
                        fontSize: 16.0, color: Color(0XFFA0A0A0)),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizeMargin.height(36.0),
                Column(
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PinCodeTextField(
                      length: 6,
                      obscureText: false,
                      animationType: AnimationType.fade,
                      keyboardType: TextInputType.number,
                      pinTheme: PinTheme(
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(5),
                          fieldHeight: 50,
                          fieldWidth: 40,
                          activeFillColor: Colors.white,
                          inactiveFillColor: Color(0XFFE5E5E5),
                          inactiveColor: Color(0XFFE5E5E5),
                          selectedColor: Color(0XFFE5E5E5),
                          activeColor: Colors.green,
                          selectedFillColor: AmmColor.primaryColor),
                      animationDuration: Duration(milliseconds: 300),
                      backgroundColor: Colors.transparent,
                      enableActiveFill: true,
                      errorAnimationController: errorController,
                      controller: textEditingController,
                      onCompleted: (v) {
                        print("Completed");
                      },
                      onChanged: (value) {
                        print(value);
                        //do nothing
                        // setState(() {
                        //   currentText = value;
                        // });
                      },
                      beforeTextPaste: (text) {
                        print("Allowing to paste $text");
                        //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                        //but you can show anything you want here, like your pop up saying wrong paste format or etc
                        return true;
                      },
                      appContext: context,
                    ),
                    SizeMargin.height(40.0),
                    GestureDetector(
                      onTap: _handleResendCode,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: RichText(
                          text: TextSpan(
                              text: "Didn’t get the code ?\n",
                              children: [
                                TextSpan(
                                    text: "Send again",
                                    style: GoogleFonts.poppins(
                                        color: AmmColor.primaryColor,
                                        fontWeight: FontWeight.bold))
                              ],
                              style: GoogleFonts.poppins(color: Colors.black)),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar:
            // Transform.translate(
            //     offset: Offset(0.0, -1 * MediaQuery.of(context).viewInsets.bottom),
            //     child:
            Container(
          margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
          child: Row(
            children: [
              Expanded(
                child: MaterialButton(
                  elevation: 0.0,
                  // minWidth: double.infinity,
                  height: 50.0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  textColor: Colors.white,
                  color: AmmColor.primaryColor,
                  disabledColor: AmmColor.primaryColor.withOpacity(0.5),
                  child: _isLoading
                      ? CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(Colors.white),
                        )
                      : Text(
                          "Verify",
                          style: TextStyle(),
                        ),
                  onPressed: _isSettingPage
                      ? null
                      : _isLoading
                          ? () {}
                          : () {
                              if (textEditingController.text.isEmpty ||
                                  int.tryParse(textEditingController.text) ==
                                      null ||
                                  textEditingController.text.length < 6) {
                                errorController.add(ErrorAnimationType.shake);
                                showToast("Enter your 6-digit code");
                              } else {
                                verifyUser();
                              }
                            },
                ),
              ),
            ],
          ),
        )
        // ),
        );
  }

  void _handleResendCode() async {
    progressModal(context);
    try {
      var result = await context
          .read<UserProvider>()
          .resendVerificationToken({"email": widget.email});

      Navigator.pop(context);
      showInfoDialog(context, result.message);
    } catch (e) {
      Navigator.pop(context);
      showToast("Unable to complete process, please try again");
    }
  }

  void verifyUser() async {
    setBusy(true);
    try {
      var result = await context
          .read<UserProvider>()
          .verifySignUpToken(textEditingController.text);
      if (result.status == true)
        Navigator.popAndPushNamed(context, RouteConstants.LoginScreen,
            arguments: true);
      showToast(result.message);
      if (this.mounted) setBusy(false);
    } catch (e) {
      showToast("Unable to complete process, please try again");
      if (this.mounted) setBusy(false);
    }
  }

  void setBusy(value) {
    setState(() {
      _isLoading = value;
    });
  }
}
