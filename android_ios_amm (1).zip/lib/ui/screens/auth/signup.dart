import 'package:amm/ui/widgets/show_webview.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/user_provider.dart';
import '../../utils.dart';
import '../../../app/route_constants.dart';

class SignupScreen extends StatefulWidget {
  SignupScreen({Key key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen>
// with TickerProviderStateMixin
{
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _isHidden = true;
  bool _agree = false;
  Map<String, dynamic> _formdata = {
    'email': '',
    'name': '',
    'username': '',
    'password': '',
  };
  // AnimationController _controller;
  // Animation<double> _animation;
  /* @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      lowerBound: 1,
      duration: const Duration(seconds: 1),
      // reverseDuration: const Duration(seconds: 5),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // FadeTransition(
              //   opacity: _animation,
              //   child:
              Image.asset(
                "assets/images/logo4.png",
                width: 80.0,
              ),
              // ),
              SizeMargin.height(16.0),
              Text(
                "Here, there is someone for everyone!!",
                style: GoogleFonts.poppins(
                    fontSize: 18.0, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
              SizeMargin.height(12.0),
              Text(
                "Let’s create your account.",
                style: TextStyle(fontSize: 16.0),
              ),
              SizeMargin.height(24.0),
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Full name",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty) return "This field is required";
                        return null;
                      },
                      onSaved: (val) {
                        _formdata['name'] = val;
                      },
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0XFFE5E5E5),
                        hintText: "Enter your full name",
                        border: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(10.0),
                            ),
                            borderSide: BorderSide.none),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 12.0),
                      ),
                    ),
                    SizeMargin.height(12.0),
                    Text(
                      "Username",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        RegExp regExp = RegExp(
                          r"^[a-zA-Z0-9_]+$",
                          caseSensitive: false,
                        );
                        if (val.trim().isEmpty)
                          return "This field is required";
                        else if (val.trim().length > 20)
                          return "Username cannot be more than 20 characters";
                        else if (!regExp.hasMatch(val))
                          return "Can only contain letters, numbers and underscore";
                        return null;
                      },
                      onSaved: (val) {
                        _formdata['username'] = val.toLowerCase();
                      },
                      decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0XFFE5E5E5),
                          hintText: "Enter your username",
                          border: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(10.0),
                              ),
                              borderSide: BorderSide.none),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 12.0)),
                    ),
                    SizeMargin.height(12.0),
                    Text(
                      "Email",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty)
                          return "This field is required";
                        else if (!EmailValidator.validate(val))
                          return "Enter a valid email address";
                        else
                          return null;
                      },
                      onSaved: (val) {
                        _formdata['email'] = val;
                      },
                      decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0XFFE5E5E5),
                          hintText: "Enter your email",
                          border: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(10.0),
                              ),
                              borderSide: BorderSide.none),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 12.0)),
                    ),
                    SizeMargin.height(12.0),
                    Text(
                      "Password",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty)
                          return "This field is required";
                        else if (val.trim().length < 6)
                          return "Password should be at least 6 characters";
                        else
                          return null;
                      },
                      onSaved: (val) {
                        _formdata['password'] = val;
                      },
                      obscureText: _isHidden,
                      decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0XFFE5E5E5),
                          hintText: "Enter your password",
                          border: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(10.0),
                              ),
                              borderSide: BorderSide.none),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 12.0),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _isHidden = !_isHidden;
                              });
                            },
                            icon: Icon(_isHidden
                                ? Icons.visibility_off
                                : Icons.visibility),
                            color: Colors.black87,
                            iconSize: 20.0,
                          )),
                    )
                  ],
                ),
              ),
              SizeMargin.height(12.0),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Checkbox(
                    value: _agree,
                    activeColor: AmmColor.primaryColor,
                    onChanged: (val) {
                      setState(() {
                        _agree = val;
                      });
                    },
                  ),
                  SizeMargin.height(4.0),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => DisplayWebview(
                                      url: "https://myammapp.com/terms",
                                    )));
                      },
                      child: Text(
                        "By signing up, you agree to our terms and conditions.",
                        style: TextStyle(fontSize: 13.0),
                      ),
                    ),
                  ),
                  // tristate: ,
                ],
              ),
              SizeMargin.height(12.0),
              _bottomWidget(),
              SizeMargin.height(24.0),
            ],
          ),
        ),
      ),
      // bottomNavigationBar: Container(
      //   margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
      //   child: ,
      // ),
    );
  }

  Widget _bottomWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: MaterialButton(
                elevation: 0.0,
                // minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                textColor: Colors.white,
                color: AmmColor.primaryColor,
                child: _isLoading
                    ? CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(Colors.white),
                      )
                    : Text(
                        "Register",
                        style: TextStyle(),
                      ),
                onPressed: _isLoading ? () {} : registerUser,
              ),
            ),
          ],
        ),
        GestureDetector(
          onTap: () {
            if (Navigator.canPop(context))
              Navigator.pop(context);
            else
              Navigator.pushNamed(context, RouteConstants.LoginScreen);
          },
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: RichText(
              text: TextSpan(
                  text: "Already have an account ? ",
                  children: [
                    TextSpan(
                        text: "Login",
                        style:
                            GoogleFonts.poppins(color: AmmColor.primaryColor))
                  ],
                  style: GoogleFonts.poppins(color: Colors.black)),
            ),
          ),
        ),
      ],
    );
  }

  void registerUser() async {
    if (!_agree) {
      showToast("Agree to our terms before proceeding");
      return;
    }
    if (!_formKey.currentState.validate()) return;
    _formKey.currentState.save();
    setBusy(true);
    try {
      var result = await context.read<UserProvider>().signup(_formdata);
      if (result.status == true)
        Navigator.pushNamed(context, RouteConstants.VerifyUserScreen,
            arguments: _formdata['email']);
      showToast(result.message);
      if (this.mounted) setBusy(false);
    } catch (e) {
      showToast("Unable to complete process, please try again");
      if (this.mounted) setBusy(false);
    }
  }

  void setBusy(value) {
    setState(() {
      _isLoading = value;
    });
  }
}
