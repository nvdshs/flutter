import 'package:amm/app/route_constants.dart';
import 'package:amm/core/providers/user_provider.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../utils.dart';
// import '../../../app/route_constants.dart';

class ForgotPasswordScreen extends StatefulWidget {
  ForgotPasswordScreen({Key key}) : super(key: key);

  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _email;
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Image.asset(
                "assets/images/logo2.png",
                width: 80.0,
              ),
              SizeMargin.height(16.0),
              Text(
                "Forgot Password",
                style: GoogleFonts.poppins(
                    fontSize: 24.0, fontWeight: FontWeight.w600),
              ),
              SizeMargin.height(12.0),
              Text("We got you covered, continue below!"),
              SizeMargin.height(36.0),
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Email",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty) return "This field is required";
                        if (!EmailValidator.validate(val))
                          return "Enter a valid email";
                        return null;
                      },
                      onSaved: (val) {
                        _email = val.trim();
                      },
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0XFFE5E5E5),
                        hintText: "Enter your email",
                        border: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(10.0),
                            ),
                            borderSide: BorderSide.none),
                      ),
                    ),
                    SizeMargin.height(36.0),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: RichText(
                          text: TextSpan(
                              text: "Remember Password? ",
                              children: [
                                TextSpan(
                                    text: "Back to Login",
                                    style: GoogleFonts.poppins(
                                        color: AmmColor.primaryColor))
                              ],
                              style: GoogleFonts.poppins(color: Colors.black)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
        child: Row(
          children: [
            Expanded(
              child: MaterialButton(
                // minWidth: double.infinity,
                height: 50.0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                textColor: Colors.white,
                color: AmmColor.primaryColor,
                child: Text(
                  "Continue",
                  style: TextStyle(),
                ),
                onPressed: _handleForgotPassword,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleForgotPassword() async {
    if (!_formKey.currentState.validate()) {
      return;
    }
    _formKey.currentState.save();
    progressModal(context);
    try {
      var result = await context.read<UserProvider>().forgotPassword(_email);
      if (result.status) {
        showToast(result.message);
        Navigator.pop(context);
        Navigator.popAndPushNamed(context, RouteConstants.ResetPasswordScreen, arguments: _email);
      } else {
        Navigator.pop(context);
        showInfoDialog(context, result.message);
      }
    } catch (e) {
      print(e);
      Navigator.pop(context);
      showToast("Unable to complete process, please try again");
    }
  }
}
