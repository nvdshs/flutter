import 'package:amm/ui/screens/home/profile_match.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:email_validator/email_validator.dart';
import '../../../core/providers/user_provider.dart';
import '../../utils.dart';
import '../../../app/route_constants.dart';

class LoginScreen extends StatefulWidget {
  final bool isFromVerify;
  LoginScreen({Key key, this.isFromVerify = false}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  bool _isHidden = true;
  AnimationController _controller;
  Animation<double> _animation;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String email;
  String password;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      reverseDuration: const Duration(seconds: 5),
      vsync: this,
    )..repeat(reverse: true);
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.fastLinearToSlowEaseIn,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              ScaleTransition(
                scale: _animation,
                child: Image.asset(
                  "assets/images/logo4.png",
                  width: 80.0,
                ),
              ),
              SizeMargin.height(16.0),
              Text(
                "Hey there!",
                style: GoogleFonts.poppins(
                    fontSize: 24.0, fontWeight: FontWeight.w600),
              ),
              SizeMargin.height(12.0),
              Text("Welcome back!!!"),
              SizeMargin.height(36.0),
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Email",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty)
                          return "This field is required";
                        else if (!EmailValidator.validate(val))
                          return "Enter a valid email address";
                        else
                          return null;
                      },
                      onSaved: (val) {
                        email = val;
                      },
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0XFFE5E5E5),
                        hintText: "Enter your email",
                        border: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(10.0),
                            ),
                            borderSide: BorderSide.none),
                      ),
                    ),
                    SizeMargin.height(12.0),
                    Text(
                      "Password",
                      style: GoogleFonts.poppins(fontSize: 16.0),
                    ),
                    SizeMargin.height(4.0),
                    TextFormField(
                      validator: (val) {
                        if (val.trim().isEmpty)
                          return "This field is required";
                        else
                          return null;
                      },
                      onSaved: (val) {
                        password = val;
                      },
                      cursorColor: Colors.black,
                      obscureText: _isHidden,
                      decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0XFFE5E5E5),
                          hintText: "Enter your password",
                          border: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(10.0),
                              ),
                              borderSide: BorderSide.none),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _isHidden = !_isHidden;
                              });
                            },
                            icon: Icon(_isHidden
                                ? Icons.visibility_off
                                : Icons.visibility),
                            color: Colors.black87,
                            iconSize: 20.0,
                          )),
                    ),
                    SizeMargin.height(8.0),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(
                            context, RouteConstants.ForgotPasswordScreen);
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: RichText(
                          text: TextSpan(
                              text: "Forgot password ? ",
                              children: [
                                TextSpan(
                                    text: "Click here",
                                    style: GoogleFonts.poppins(
                                        color: AmmColor.primaryColor))
                              ],
                              style: GoogleFonts.poppins(color: Colors.black)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.symmetric(vertical: 32.0, horizontal: 16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Expanded(
                  child: MaterialButton(
                    elevation: 0.0,
                    // minWidth: double.infinity,
                    height: 50.0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    textColor: Colors.white,
                    color: AmmColor.primaryColor,
                    child: _isLoading
                        ? CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          )
                        : Text(
                            "Login",
                            style: TextStyle(),
                          ),
                    onPressed: _isLoading ? () {} : loginUser,
                  ),
                ),
              ],
            ),
            GestureDetector(
              onTap: () {
                if (Navigator.canPop(context))
                  Navigator.pop(context);
                else
                  Navigator.pushNamed(context, RouteConstants.SignupScreen);
              },
              child: Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: RichText(
                  text: TextSpan(
                      text: "Don’t have an account ? ",
                      children: [
                        TextSpan(
                            text: "Register",
                            style: GoogleFonts.poppins(
                                color: AmmColor.primaryColor))
                      ],
                      style: GoogleFonts.poppins(color: Colors.black)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void loginUser() async {
    if (!_formKey.currentState.validate()) return;
    _formKey.currentState.save();
    setBusy(true);
    try {
      var result = await Provider.of<UserProvider>(context, listen: false)
          .login(email, password);
      if (result.status == true){ if (widget.isFromVerify)
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProfileMatchScreen(
              isFromProfile: false,
            ),
          ),
        );
      else
        Navigator.popAndPushNamed(context, RouteConstants.IndexScreen);
      }
      else{
        if(result.message == 'Your account is not verified'){
 Navigator.popAndPushNamed(context, RouteConstants.VerifyUserScreen,
            arguments: email);
        }
         showToast(result.message);
      if (this.mounted) setBusy(false);
      }
       
    } catch (e) {
      showToast("Unable to complete process, please try again");
      if (this.mounted) setBusy(false);
    }
  }

  void setBusy(value) {
    setState(() {
      _isLoading = value;
    });
  }

  bool _isLoading = false;
}
