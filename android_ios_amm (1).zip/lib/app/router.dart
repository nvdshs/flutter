import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'route_constants.dart';

//import screens
import 'routes.dart';

class Routers {
  // static const String indexRoute = RouteConstants.OnboardingScreen;
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case 'onboard':
        return MaterialPageRoute(builder: (_) => OnboardingScreen());
      // case 'onboard':
      //   return MaterialPageRoute(builder: (_) => OnboardingScreen());
      // case RouteConstants.OnboardingScreen:
      //   return MaterialPageRoute(builder: (_) => OnboardingScreen());

      case RouteConstants.LoginScreen:
        return PageTransition(
          child: LoginScreen(),
          type: PageTransitionType.fade,
        );
      case RouteConstants.SignupScreen:
        return PageTransition(
          child: SignupScreen(),
          type: PageTransitionType.bottomToTop,
        );

      case RouteConstants.VerifyUserScreen:
        return MaterialPageRoute(
          builder: (_) => VerifyUserScreen(
            email: settings.arguments,
          ),
        );

      case RouteConstants.ResetPasswordScreen:
        return MaterialPageRoute(
          builder: (_) => ResetPasswordScreen(
            email: settings.arguments,
          ),
        );

      case RouteConstants.ForgotPasswordScreen:
        return PageTransition(
          child: ForgotPasswordScreen(),
          type: PageTransitionType.fade,
        );

      case RouteConstants.ProfileMatchScreen:
        return PageTransition(
          child: ProfileMatchScreen(
            isFromProfile: settings.arguments,
          ),
          type: PageTransitionType.bottomToTop,
        );

      case RouteConstants.IndexScreen:
        return PageTransition(
          child: IndexScreen(
            currentIndex: settings.arguments ?? 0,
          ),
          type: PageTransitionType.scale,
        );
      //  MaterialPageRoute(builder: (_) => LoginScreen());

      case RouteConstants.ChatScreen:
        return PageTransition(
            child: ChatScreen(settings.arguments),
            type: PageTransitionType.topToBottom);

      case RouteConstants.UserProfileScreen:
        return PageTransition(
            child: UserProfileScreen(
              uid: (settings.arguments as Map)['uid'],
              isFromChat: (settings.arguments as Map)['isFromChat'],
            ),
            type: PageTransitionType.leftToRight);
      // case RouteConstants.ProfileSetup:
      //   return MaterialPageRoute(
      //       builder: (_) => ProfileSetup(name: settings.arguments));

      default:
        return MaterialPageRoute(
            builder: (_) => Scaffold(
                  body: Center(
                      child: Text('No route defined for ${settings.name}')),
                ));
    }
  }

  static String initialRoute(String page) {
    switch (page) {
      case 'forgot_password':
        return RouteConstants.VerifyUserScreen;
      case 'reset_password':
        return RouteConstants.VerifyUserScreen;
      case 'home':
        return RouteConstants.IndexScreen;
      // case 'login':
      //   return RouteConstants.LoginScreen;
      default:
        return 'onboard';
    }
  }

  static Widget home = IndexScreen(
    currentIndex: 0,
  );

  static Widget initialPage(page, email) {
    switch (page) {
      case 'forgot_password':
        return VerifyUserScreen(email: email);
      case 'reset_password':
        return ResetPasswordScreen(email: email);
      case 'home':
        return IndexScreen(
          currentIndex: 0,
        );
      // case 'login':
      //   return RouteConstants.LoginScreen;
      default:
        return OnboardingScreen();
    }
  }
}
