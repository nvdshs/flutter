import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'router.dart';
import '../core/providers/user_provider.dart';
import '../core/services/navigation_service.dart';
import '../ui/utils.dart';

class AmmBaseApp extends StatelessWidget {
  final String page;
  final String userData;
  final String date;
  final String bVerse;
  final String userKey;
  final String email;
  final String friendPref;
  final bool notifyPref;
  final bool searchPref;
  const AmmBaseApp(
      {Key key,
      this.page = '/',
      this.userData,
      this.userKey,
      this.date,
      this.bVerse,
      this.email,
      this.friendPref,
      this.searchPref,
      this.notifyPref})
      : super(key: key);
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(
        // consumes the user provider
        builder: (_, uProvider, __) {
      if (uProvider.currentUser == null)
        uProvider.tryLogin(this.userData, this.userKey, this.date,
            this.friendPref, this.searchPref, this.notifyPref, this.bVerse);
      return MaterialApp(
        navigatorKey: NavigationService.instance.navigationKey,
        title: 'AMM',
        theme: ThemeData(
          primarySwatch: AmmColor.white,
          scaffoldBackgroundColor: AmmColor.white,
          textTheme: GoogleFonts.poppinsTextTheme(
            Theme.of(context).textTheme,
          ),
          // fontFamily: GoogleFonts.montserrat(),
          // This makes the visual density adapt to the platform that you run
          // the app on. For desktop platforms, the controls will be smaller and
          // closer together (more dense) than on mobile platforms.
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        onGenerateRoute: Routers.generateRoute,
        debugShowCheckedModeBanner: false,
        home: uProvider.userToken != null
            ? Routers.home
            : Routers.initialPage(this.page, this.email),
      );
    });
  }
}

/*
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'app/router.dart';
import 'providers/competition_provider.dart';
import 'providers/user_provider.dart';
import 'screens/onboarding.dart';
import 'utils/utils.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: UserProvider()),
        ChangeNotifierProvider.value(value: CompetitionProvider()),

        // ChangeNotifierProvider<StoreState>(create: (_) => StoreState())
      ],
      child: MaterialApp(
        title: 'Finerge',
        theme: ThemeData(
          fontFamily: "Gilroy",
          primarySwatch: FinergeColor.primaryColor,

          // This makes the visual density adapt to the platform that you run
          // the app on. For desktop platforms, the controls will be smaller and
          // closer together (more dense) than on mobile platforms.

          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        /* darkTheme: ThemeData(
          fontFamily: "Gilroy",
          brightness: Brightness.dark,
          primarySwatch: FinergeColor.primaryColorDark,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ), */
        onGenerateRoute: Routers.generateRoute,
        debugShowCheckedModeBanner: false,
        home: OnboardingScreen(),
      ),
    );
  }
}
*/
