class RouteConstants {
  static const OnboardingScreen = "/onboardingscreen";
  static const LoginScreen = "/loginscreen";
  static const SignupScreen = '/signupscreen';
  static const VerifyUserScreen = '/verifyuserscreen';
  static const ResetPasswordScreen = '/resetpasswordscreen';
  static const ForgotPasswordScreen = '/forgotpasswordscreen';
  static const ProfileMatchScreen = '/profilematchscreen';
  static const IndexScreen = '/indexscreen';
  static const UserProfileScreen = '/userprofilescreen';
  static const ChatScreen = '/chatscreen';
}
