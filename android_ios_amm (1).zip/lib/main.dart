import 'package:amm/core/services/onesignal_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:path_provider/path_provider.dart' as pathProvider;
import 'app/index.dart';
import 'core/providers/user_provider.dart';
import 'core/providers/chat_provider.dart';

// add failed variable in state-country search and give button to try again

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  OneSignalService.init();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Directory directory = await pathProvider.getApplicationDocumentsDirectory();
  SharedPreferences prefs = await SharedPreferences.getInstance();

  String page = prefs.getString('page') ?? '/';
  // String userData = box.get('userdata');
  // String userKey = box.get('userkey');
  String userData = prefs.getString('userdata');
  String userKey = prefs.getString('userkey');
  String date = prefs.getString('timer');
  String bVerse = prefs.getString('bible_verse');
  String email = prefs.getString('email');
  String friendPref = prefs.getString("friend_pref");
  bool notifyPref = prefs.getBool("notify_pref") ?? true;
  bool searchPref = prefs.getBool("search_pref") ?? true;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: UserProvider()),
        ChangeNotifierProxyProvider<UserProvider, ChatProvider>(
            create: (_) => ChatProvider(),
            update: (BuildContext context, UserProvider userProvider,
                    ChatProvider chatProvider) =>
                chatProvider..update(userProvider)
            /* update: (BuildContext context, UserProvider userProvider,
                  CourseProvider courseProvider) =>
              CourseProvider(userProvider: userProvider),*/
            )
      ],
      child: AmmBaseApp(
        page: page,
        userData: userData,
        userKey: userKey,
        date: date,
        bVerse: bVerse,
        email: email,
        friendPref: friendPref,
        notifyPref: notifyPref,
        searchPref: searchPref,
      ),
    ),
  );
}
