const pool = require("../../config/db_config");
const errorlog = require('../helpers/error_log');
const {
    generateDigit
} = require('../helpers/random');

let queries = {
    getUserByEmail: async (email, callback) => {
        try {
            const results = await pool.query(
                `SELECT * FROM users WHERE email = ?`,
                [email]);
            return callback(null, results[0]);
        } catch (e) {
            // print(e);
            errorlog(e);
            return callback(e);
        }
    },
    getUserById: async (id) => {
        try {
            let $query = `SELECT * FROM users WHERE id = ?`;
            const results = await pool.query($query, [id]);
            return Promise.resolve(results[0]);
        } catch (e) {
            return Promise.reject(new Error(e));
        }
    },
    getUserByToken: async (token) => {
        try {
            let $query = `SELECT email FROM users WHERE token = ?`;
            const results = await pool.query($query, [token]);
            return Promise.resolve(results[0]);
        } catch (e) {
            return Promise.reject(new Error(e));
        }
    },
    updatePasswordWithToken: async (token, email, password) => {
        try {
            let query = `UPDATE users SET password = ?, token = NULL WHERE email = ? AND token = ?`;
            await pool.query(query, [password, email, token]);
            return Promise.resolve();
        } catch (e) {
            return Promise.reject(new Error(e));
        }
    },
    updatePassword: async (uid, password) => {
        try {
            let query = `UPDATE users SET password = ? WHERE id = ?`;
            await pool.query(query, [password, uid]);
            return Promise.resolve();
        } catch (e) {
            return Promise.reject(new Error(e));
        }
    },
    emailExists: async (email) => {
        try {
            const results = await pool.query(
                `SELECT * FROM users WHERE email = ?`,
                [email]);
            if (results[0] === undefined)
                return Promise.resolve(results[0]);
            return Promise.reject(new Error("Email already exists, please try another"));

        } catch (e) {
            errorlog(e);
            Promise.reject(new Error("Unable to complete process, try again"))
            // return callback(e);
        }
    },
    usernameExists: async (username) => {
        try {
            const results = await pool.query(
                `SELECT * FROM users WHERE username = ?`,
                [username]);
            if (results[0] === undefined)
                return Promise.resolve(results[0]);
            return Promise.reject(new Error("Username already exists, please try another"));

        } catch (e) {
            errorlog(e);
            Promise.reject(new Error(
                "Unable to complete process, please try again"
            ))
            // return callback(e);
        }
    },
    forgotPassword: async (email) => {
        let digit = generateDigit();
        // let expiry = new Date(date.getTime() + (7 * 24 * 60 * 60 * 1000));

        try {
            let query = `UPDATE users SET token = ? WHERE email = ?`;
            await pool.query(query, [digit, email]);
            return Promise.resolve(digit);
        } catch (e) {
            return Promise.reject(new Error(e));
        }
    },
    signupUser: async (u, callback) => {
        let current_date = new Date();
        current_date.setDate(current_date.getDate() + 7);
        // var newDate = new Date(current_date.setMonth(current_date.getMonth() + 1));
        let token = generateDigit();
        try {
            const results = await pool.query(
                `INSERT INTO users(fullname, username, email, password, token,subscription_expiry) VALUES (?,?,?,?,?,?)`,
                [u.name, u.username, u.email, u.password, token, current_date]);
            return callback(null, token);
        } catch (e) {
            errorlog(e);
            return callback(e);
        }
    },
    verifyToken: async (token, callback) => {
        try {
            const results = await pool.query(
                `SELECT email FROM users WHERE token = ?`,
                [token]);
            // delete results[0].password;
            return callback(null, results[0]);
        } catch (e) {
            errorlog(e);
            return callback(e);
        }
    },
    verifyUser: async (email, token, callback) => {
        try {
            const results = await pool.query(
                `UPDATE users SET is_verified = 'true', token = NULL WHERE token = ? AND email = ?`,
                [token, email]);
            // delete results[0].password;
            return callback(null, true);
        } catch (e) {
            errorlog(e);
            return callback(e);
        }
    },
    checkUserSubscriptionStatus: async () => {
        try {
            await pool.query(
                `UPDATE users SET subscription_status = 'none', subscription_expiry = NULL, lat = 0, lng = 0 WHERE subscription_expiry < CURDATE()`,
                []);
            return Promise.resolve("user subscriptions checked");
        } catch (e) {
            errorlog(e);
            Promise.reject(new Error(
                "Unable to complete process, please try again"
            ))
            // return callback(e);
        }
    },
    searchUsers: async (uid, filter, callback) => {
        try {
            const results = await pool.query(
                `SELECT id,fullname,username,email,dob,profile_photo FROM users WHERE (username LIKE ? OR fullname LIKE ?) AND is_verified = 'true' AND id != ? AND subscription_status != 'none'`,
                ['%' + filter + '%', '%' + filter + '%', uid]);
            // delete results[0].password;
            return callback(null, results);
        } catch (e) {
            errorlog(e);
            return callback(e);
        }
    },
    randomUsers: async (uid, filter, lat, lng, callback) => {
        try {
            let query;
            let results;
            const USERS_LAT = "lat";
            const USERS_LON = "lng";
            if (filter == 'random') {
                query = `SELECT id,fullname,username,email,gender,city,dob,profile_photo FROM users WHERE is_verified = 'true' AND id != ? AND subscription_status != 'none' ORDER BY RAND() LIMIT 200`;
                results = await pool.query(query, [uid]);
            } else {
                query = `SELECT id,fullname,username,email,gender,city,dob,profile_photo, ` + USERS_LAT + ` AS lat, ` + USERS_LON + ` AS lon, ( 6371 * acos( cos( radians(?) ) * cos( radians( ` + USERS_LAT + ` ) )
                * cos(radians(` + USERS_LON + `) - radians(?)) + sin(radians(?)) * sin(radians(` + USERS_LAT + `))) ) AS distance FROM users WHERE is_verified = 'true' AND id != ? AND subscription_status != 'none' HAVING distance < 100 ORDER BY distance,RAND() LIMIT 200`;
                results = await pool.query(query, [lat, lng, lat, uid]);
            }
            // delete results[0].password;
            return callback(null, results);
        } catch (e) {
            // console.log(e)
            errorlog(e);
            return callback(e);
        }
    },
    searchUsersByPreference: async (params, callback) => {
        try {
            const results = await pool.query(
                `SELECT id,fullname,username,email,gender,city,dob,profile_photo FROM users WHERE 
                ( TIMESTAMPDIFF(YEAR, dob, CURDATE()) >= ? AND TIMESTAMPDIFF(YEAR, dob, CURDATE()) <= ?) 
                AND gender = ? AND (doctrine LIKE ? OR city LIKE ?) AND ethnicity = ? AND subscription_status != 'none' AND id != ? ORDER BY RAND() LIMIT 100`,
                [params.min_age, params.max_age, params.gender, '%' + params.doc + '%', '%' + params.city + '%', params.ethnicity, params.uid]);
            // delete results[0].password;
            return callback(null, results);
        } catch (e) {
            errorlog(e);
            return callback(e);
        }
        // http://localhost:3000/api/v1/users/preference/search?gender=male&min_age=6&max_age=40&doc=mado&city=mado
    },
    addUserNotification: async (title, content, userId, has_user) => {
        try {
            let sql;
            let params;
            if (has_user) {
                sql = "INSERT INTO notifications(title, content, user_id, has_user) VALUES(?, ?, ?, ?)";
                params = [title, content, userId, has_user];
            } else {
                sql = "INSERT INTO notifications(title, content, user_id) VALUES(?, ?, ?)";
                params = [title, content, userId];
            }
            await pool.query(sql, params);
            // return callback(null, fullname);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
            // return callback(e);
        }
    },
    fetchUserNotifications: async (uid) => {
        try {
            let results = await pool.query(`SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC`, [uid]);
            // return callback(null, fullname);
            return Promise.resolve(results);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
            // return callback(e);
        }
    },

    deleteUserNotification: async (uid, id) => {
        try {
            await pool.query(`DELETE FROM notifications WHERE id = ? AND user_id = ?`, [id, uid]);
            // return callback(null, fullname);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
            // return callback(e);
        }
    },

    fetchUserProfile: async (uid) => {
        try {
            let results = await pool.query(`SELECT id,username,fullname,profile_photo,cover_photo,bio,dob,likes,dislikes,church,gender,city,doctrine,ethnicity FROM users WHERE id = ?`, [uid]);
            // return callback(null, fullname);
            return Promise.resolve(results[0]);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
            // return callback(e);
        }
    },

    /**
     * UPDATE PROFILE DATA
     * @description [ update name and date]
     */
    updateName: async (uid, fullname) => {
        try {
            await pool.query(`UPDATE users SET fullname = ? WHERE id = ?`, [fullname, uid]);
            // return callback(null, fullname);
            return Promise.resolve(fullname);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
            // return callback(e);
        }
    },
    updateDob: async (uid, dob) => {
        try {
            await pool.query(`UPDATE users SET dob = ? WHERE id = ?`, [dob, uid]);
            return Promise.resolve(dob);

        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    updateUsername: async (uid, username) => {
        try {
            await pool.query(`UPDATE users SET username = ? WHERE id = ?`, [username, uid]);
            return Promise.resolve(username);

        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    updateUserDetail: async (uid, type, data) => {
        try {
            await pool.query(`UPDATE users SET ${type} = ? WHERE id = ?`, [data, uid]);
            return Promise.resolve(data);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },

    upgradeUserSubscription: async (uid, plan) => {
        let current_date = new Date();
        let monthToAdd = plan == '3_month' ? 3 : 1;
        let newDate = new Date(current_date.setMonth(current_date.getMonth() + monthToAdd));
        try {
            await pool.query(`UPDATE users SET subscription_status = ?, subscription_expiry = ? WHERE id = ?`, [plan, newDate, uid]);
            return Promise.resolve(plan);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },

    /**
     * @end UPDATE PROFILE DATA
     */

    /**
     * PHOTOS SERVICES
     * @description [no desc]
     */
    addPhoto: async (uid, url, public_id) => {
        try {
            let res = await pool.query(`INSERT INTO photos(user_id, photo_url, public_id) VALUES(?,?,?)`, [uid, url, public_id]);
            console.log(res);
            return Promise.resolve(res.insertId);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    fetchPhotos: async (uid) => {
        let $sql = "SELECT id,photo_url,caption,public_id FROM photos WHERE user_id = ?";
        try {
            let results = await pool.query($sql, [uid]);
            return Promise.resolve(results);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    deletePhoto: async (uid, id) => {
        let $sql = "DELETE FROM photos WHERE user_id = ? AND id = ?";
        try {
            await pool.query($sql, [uid, id]);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    addProfilePhoto: async (uid, url, publicId) => {
        try {
            await pool.query(`UPDATE users SET profile_photo = ?, profile_photo_id = ? WHERE id = ?`, [url, publicId, uid]);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },
    addCoverPhoto: async (uid, url, publicId) => {
        try {
            await pool.query(`UPDATE users SET cover_photo = ?, cover_photo_id = ? WHERE id = ?`, [url, publicId, uid]);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },
    deleteProfilePhoto: async (uid) => {
        try {
            await pool.query(`UPDATE users SET profile_photo = NULL, profile_photo_id = NULL WHERE id = ?`, [uid]);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },
    deleteCoverPhoto: async (uid) => {
        try {
            await pool.query(`UPDATE users SET cover_photo = NULL, cover_photo_id = NULL WHERE id = ?`, [uid]);
            return Promise.resolve(true);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },

    /**
     * FRIENDS SERVICES
     * @description [no desc]
     * @params [sender_id, receiver_id, status]
     */

    friendsList: async (uid) => {
        let $sql = "SELECT id, username, fullname, dob, profile_photo FROM `users` WHERE `users`.`id` IN (SELECT `receiver_id` AS `friends` FROM usersfriends WHERE `sender_id` = ? AND `status` = 'true' UNION SELECT `sender_id` FROM usersfriends WHERE `receiver_id` = ? AND `status` = 'true')";
        try {
            let results = await pool.query($sql, [uid, uid]);
            return Promise.resolve(results);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    friendRequests: async (uid) => {
        let $sql = "SELECT `users`.`id`, `users`.`fullname`, `users`.`profile_photo`, `users`.`dob` FROM `users` WHERE `users`.`id` IN (SELECT `sender_id` FROM usersfriends WHERE `receiver_id` = ? AND `status` = 'false') LIMIT 0, 1000";
        try {
            let results = await pool.query($sql, [uid, uid]);
            return Promise.resolve(results);
        } catch (e) {
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    addFriend: async (uid, userId) => {
        let $sql = "INSERT INTO usersfriends (sender_id,receiver_id) VALUES (?,?)";
        try {
            await pool.query($sql, [uid, userId]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    acceptFriend: async (uid, userId) => {
        let sql = "UPDATE `usersfriends` SET `status` = 'true' WHERE `usersfriends`.`receiver_id` = ? AND `usersfriends`.`sender_id` = ?";
        try {
            await pool.query(sql, [uid, userId]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    cancelFriendRequest: async (uid, userId) => {
        let sql = "DELETE FROM `usersfriends` WHERE `sender_id` = ? AND `receiver_id` = ?  AND `status` = 'false'";
        try {
            await pool.query(sql, [uid, userId]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    rejectFriend: async (uid, userId) => {
        let sql = "DELETE FROM `usersfriends` WHERE `receiver_id` = ? AND `sender_id` = ?  AND `status` = 'false'";
        try {
            await pool.query(sql, [uid, userId]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    deleteFriend: async (uid, userId) => {
        let sql = "DELETE FROM `usersfriends` WHERE (`receiver_id` = ? AND `sender_id` = ?) OR (`sender_id` = ? AND `receiver_id` = ?) AND `status` = 'true'";
        try {
            await pool.query(sql, [uid, userId, uid, userId]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    // SOME USEFUL FRIEND SERVICES WHEN FETCHING PROFILE
    hasSentFriendRequest: async (uid, userId) => {
        let sql = "SELECT * FROM `usersfriends` WHERE (`receiver_id` = ? AND `sender_id` = ?  AND `status` = 'false')";
        try {
            let results = await pool.query(sql, [uid, userId]);
            return Promise.resolve(results[0] !== undefined);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    youSentFriendRequest: async (uid, userId) => {
        let sql = "SELECT * FROM `usersfriends` WHERE `receiver_id` = ? AND `sender_id` = ? AND `status` = 'false'";
        try {
            let results = await pool.query(sql, [userId, uid]);
            return Promise.resolve(results[0] !== undefined);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    isFriend: async (uid, userId) => {
        let sql = "SELECT * FROM `usersfriends` WHERE (`usersfriends`.`receiver_id` = ? AND `usersfriends`.`sender_id` = ? AND `usersfriends`.`status` = 'true') OR (`usersfriends`.`sender_id` = ? AND `usersfriends`.`receiver_id` = ? AND `usersfriends`.`status` = 'true')";
        try {
            let results = await pool.query(sql, [uid, userId, uid, userId]);
            return Promise.resolve(results[0] !== undefined);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },

    /**
    * CHAT SERVICES
    * @description [no desc]
    * @params [sender_id, receiver_id, status]
    */

    fetchRecentChats: async (uid) => {
        let query = `SELECT t1.*,u1.username,u1.profile_photo
        FROM chats AS t1
        INNER JOIN
        (
            SELECT
                LEAST(sender_id, receiver_id) AS sender_id,
                GREATEST(sender_id, receiver_id) AS receiver_id,
                MAX(id) AS max_id
            FROM chats 
            GROUP BY
                LEAST(sender_id, receiver_id),
                GREATEST(sender_id, receiver_id)
        ) AS t2
            ON LEAST(t1.sender_id, t1.receiver_id) = t2.sender_id AND
               GREATEST(t1.sender_id, t1.receiver_id) = t2.receiver_id AND
               t1.id = t2.max_id JOIN users AS u1 ON (GREATEST(t1.sender_id, t1.receiver_id ) = u1.id AND u1.id != ?) 
               OR (LEAST(t1.sender_id, t1.receiver_id ) = u1.id AND u1.id != ? )
            WHERE t1.sender_id = ? OR t1.receiver_id = ? ORDER BY t1.created_at DESC`;

        try {
            let results = await pool.query(query, [uid, uid, uid, uid]);
            return Promise.resolve(results);
        } catch (e) {
            console.log(e)
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },
    fetchSingleChat: async (uid, data) => {
        let query = `SELECT COUNT(id) as all_messages FROM chats WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ? AND visible_for_receiver = 'true')`;
        let totalRec = 0,
            pageSize = 50,
            pageCount = 0;
        let start = 0;
        let currentPage = 1;
        try {
            let res = await pool.query(query, [uid, data.userId, data.userId, uid]);
            totalRec = res[0]['all_messages'];
            pageCount = Math.ceil(totalRec / pageSize);
            if (typeof data.currentPage !== 'undefined') {
                currentPage = data.currentPage;
            }
            if (currentPage > 1) {
                start = (currentPage - 1) * pageSize;
            }
            let results = await pool.query(`SELECT * FROM chats WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ? AND visible_for_receiver = 'true') LIMIT ?,?`, [uid, data.userId, data.userId, uid, start, pageSize]);
            return Promise.resolve(results);
        } catch (e) {
            console.log(e);
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    addChat: async (sender, receiver, message) => {
        try {
            let res = await pool.query(`INSERT INTO chats(sender_id, receiver_id, message) VALUES(?,?,?)`, [sender, receiver, message]);
            return Promise.resolve(res.insertId);
        } catch (e) {
            console.log(e);
            errorlog(e);
            return Promise.reject(new Error(e))
        }
    },
    addImageChat: async (sender, receiver, message, publidId) => {
        let type = 'image';
        try {
            let res = await pool.query(`INSERT INTO chats(sender_id, receiver_id, message, public_id, type) VALUES(?,?,?,?,?)`, [sender, receiver, message, publidId, type]);
            return Promise.resolve(res.insertId);
        } catch (e) {
            console.log(e);
            errorlog(e);
            return Promise.reject(new Error(e));
        }
    },
    deleteChat: async (chatId, uid) => {
        let selectQuery = `SELECT id, sender_id AS sender, receiver_id AS receiver FROM chats WHERE id = ?`;
        try {
            let getChats = await pool.query(selectQuery, [chatId]);
            let getChat = getChats[0];
            if (!getChat) return Promise.resolve(false);
            if (getChat.sender == uid)
                await pool.query(`DELETE FROM chats WHERE id = ? AND sender_id = ?`, [chatId, uid]);
            else
                await pool.query(`UPDATE chats SET visible_for_receiver = 'false' WHERE id = ? AND receiver_id = ?`, [chatId, uid]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e)
            return Promise.reject(new Error(e))
        }
    },

    /**
    * PUSH NOTIFICATIONS SERVICES
    * @description [no desc]
    */

    fetchPlayerIds: async (uid) => {
        try {
            let result = await pool.query(`SELECT signal_id FROM users WHERE id = ? AND notify = 'true'`, [uid]);
            return Promise.resolve(result[0]);
        } catch (e) {
            console.log(e)
            return Promise.reject(new Error(e))
        }
    },
    addPlayerId: async (sig, uid) => {
        try {
            await pool.query(`UPDATE users SET signal_id = ? WHERE id = ?`, [sig, uid]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e);
            return Promise.reject(new Error(e));
        }
    },
    updateNotification: async (notify, uid) => {
        try {
            await pool.query(`UPDATE users SET notify = ? WHERE id = ?`, [notify, uid]);
            return Promise.resolve(true);
        } catch (e) {
            console.log(e);
            return Promise.reject(new Error(e));
        }
    }
}

module.exports = queries;