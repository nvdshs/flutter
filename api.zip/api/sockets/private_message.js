const { addChat, addImageChat } = require('../services/users');

module.exports = function (io) {
    io.on('connection', function (socket) {
        // send a response message to the console
        console.log("user connected to the socket :", socket.id);


        socket.on('join_pm', (pm) => {
            socket.join(pm.room1);
            socket.join(pm.room2);
            console.log(pm.room1, pm.room2);
            socket.broadcast.to(pm.room1).emit('logged_in', true);
            // callback('pm joined');
        });

        // socket for typing
        socket.on('typing', function (data) {
            socket.broadcast.to(data.room).emit('typing', true);
        });

        // socket for typing
        socket.on('nottyping', function (data) {
            socket.broadcast.to(data.room).emit('typing', false);
        });

        socket.on('send_private_message', async (data, callback) => {
            try{
                let date = new Date();
                let id = await addChat(data.sender, data.receiver, data.message);
                io.to(data.room).emit('new_private_message', {
                    id: id,
                    message: data.message,               
                    sender_id: parseInt(data.sender),
                    receiver_id: parseInt(data.receiver),
                    is_read: 'false',
                    type: 'text',
                    created_at: date
                });
                callback(true);
                console.log(
                    data
                )
            }catch(e){
                callback(false);
                throw e;
            }
            
        });

        socket.on('send_private_image_message', async (data, callback) => {
            try{
                let date = new Date();
                let id = await addImageChat(data.sender, data.receiver, data.message, data.publid_id);
                io.to(data.room).emit('new_private_message', {
                    id: id,
                    message: data.message,               
                    sender_id: parseInt(data.sender),
                    receiver_id: parseInt(data.receiver),
                    public_id: data.publid_id,
                    is_read: 'false',
                    type: 'image',
                    created_at: date
                });
                callback(true);
                console.log(
                    data
                )
            }catch(e){
                callback(false);
                throw e;
            }
            
        });
        

        // socket for chat
        socket.on('loggedout', function (data) {
            socket.broadcast.to(data.room).emit('logged_in', false);
            socket.broadcast.to(data.room).emit('typing', false);
        });

        socket.on('logged_in', function (data) {
            socket.broadcast.to(data.room).emit('logged_in', true);
        });
        
        //         socket.on('send_message', function (data) {
        //       io.sockets.emit('receive_message', data);
        //   }); 




        socket.on('disconnect', function (data) {
            console.log("user disconnected");
            // socket.broadcast.to(data.room).emit('logged_in', false);
            // io.sockets.emit('chat', data);
        });
    });
}