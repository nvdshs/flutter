let router = require('express').Router();

const multer = require("multer");

var fileUpload = multer();

// const fs = require('fs');
// const path = require('path');
const verifyHtml = require('../templates/verify')
const {
    checkToken: verifyAuthToken
} = require('../helpers/auth')
const {
    loginUser,
    createUser,
    getUserDetails,
    verifyToken,
    forgotPassword,
    updatePasswordWithToken,
    resendVerificationToken,
    updatePassword,
    searchUsers,
    randomUsers,
    searchUsersByPreference,
    updateName,
    updateDob,
    updateUsername,
    updateUserDetails,
    upgradeUserSubscription,
    uploadChatPhoto,
    uploadPhoto,
    fetchPhotos,
    deletePhoto,
    uploadProfilePhoto,
    deleteProfilePhoto,
    uploadCoverPhoto,
    deleteCoverPhoto,
    fetchUserNotifications,
    deleteUserNotification,
    friendsList,
    friendRequests,
    addFriend,
    acceptFriend,
    rejectFriend,
    cancelFriendRequest,
    deleteFriend,
    fetchUserProfile,
    addToChat,
    addToChatImage,
    fetchRecentChats,
    fetchSingleChat,
    deleteSingleChat,
    updateSignalId
} = require('../controllers/users');

const { removeNotification } = require('../helpers/firebase_admin');


router.post('/login', loginUser);

router.post('/signup', createUser);

router.post('/signup/resend_verification', resendVerificationToken);

router.get('/verify/:token', verifyToken);

//new
router.post('/forgot_password', forgotPassword);

router.post('/update_forgot_password', updatePasswordWithToken);

router.post('/update_password', verifyAuthToken, updatePassword);
// end new 

router.get('/details', verifyAuthToken, getUserDetails);

router.post('/update_push_token', verifyAuthToken, updateSignalId);

router.get('/search/:search', verifyAuthToken, searchUsers);

router.get('/random', randomUsers);
// router.get('/random', verifyAuthToken, randomUsers);

router.get('/preference/search', verifyAuthToken, searchUsersByPreference);

router.get('/profile/:uid', verifyAuthToken, fetchUserProfile); // -

router.post('/update_name', verifyAuthToken, updateName);

router.post('/update_dob', verifyAuthToken, updateDob); //-

router.post('/update_username', verifyAuthToken, updateUsername);

// generic updates
router.put('/update/:type', verifyAuthToken, updateUserDetails);

router.post('/upgrade', verifyAuthToken, upgradeUserSubscription);

router.get('/notifications', verifyAuthToken, fetchUserNotifications); // -

router.post('/notifications/delete/', verifyAuthToken, deleteUserNotification); // -

/**
 *  PHOTOS ROUTES
 */

router.post('/chat/photo', fileUpload.single('image'), verifyAuthToken, uploadChatPhoto);

router.post('/upload/photo', fileUpload.single('image'), verifyAuthToken, uploadPhoto);

router.get('/photos/:userId', verifyAuthToken, fetchPhotos);

router.post('/photos/delete', verifyAuthToken, deletePhoto);

router.post('/profile_photo/upload', fileUpload.single('image'), verifyAuthToken, uploadProfilePhoto);

router.post('/cover_photo/upload', fileUpload.single('image'), verifyAuthToken, uploadCoverPhoto);

router.post('/profile_photo/delete', verifyAuthToken, deleteProfilePhoto);

router.post('/cover_photo/delete', verifyAuthToken, deleteCoverPhoto);


/**
 *  FRIENDS ROUTES
 */
router.get('/friends', verifyAuthToken, friendsList); // -

router.get('/friend_requests', verifyAuthToken, friendRequests); // - 

router.post('/friends/add', verifyAuthToken, addFriend); //-

router.post('/friends/accept', verifyAuthToken, acceptFriend); // - 

router.post('/friends/reject', verifyAuthToken, rejectFriend); // - 

router.post('/friends/cancel', verifyAuthToken, cancelFriendRequest); // -

router.post('/friends/delete', verifyAuthToken, deleteFriend); // -

/**
 * CHATS ROUTES
 * 
 */

router.get('/recent_chats', verifyAuthToken, fetchRecentChats);

router.get('/chat/:userId', verifyAuthToken, fetchSingleChat);

router.post('/chat/text', addToChat);

router.post('/chat/image', addToChatImage);

router.delete('/chat/:chatId', verifyAuthToken, deleteSingleChat);


router.put('/remove_notification/:type', verifyAuthToken, async (user, req, res, next) => {
    const type = req.params.type;
    if (!type || (type != "chat" && type != "notification")) {
        return res.status(422).json({
            status: false,
            message: "No type passed"
        });
    }
    try {
        await removeNotification(user.id, type);
        return res.json({
            status: true,
            message: "successfully updated",
        });
    } catch (e) {
        return res.status(500).json({
            status: false,
            message: "error occurred",
        });
    }

});

//// end of routes

router.get('/test', function (req, res) {
    // fs.readFile(path.join(__dirname, '../templates/verify.html'), 'utf8', function(err, html){
    res.send(verifyHtml({
        username: "jdoe",
        token: "124567"
    }));
    // })
});

module.exports = router;