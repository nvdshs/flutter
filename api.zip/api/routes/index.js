let router = require('express').Router();

// require('dotenv').config();
// 2.3.0

const { getStripePaymentIntent } = require('../controllers/index');
const { checkUserSubscriptionStatus } = require('../services/users');


router.get('/', (_, res) => {
    return res.json({
        status: true,
        message: "Angelic match maker API",
        data: []
    });
});

router.post('/contact', (_, res) => {
    return res.json({
        status: true,
        message: "Message successfully sent",
        data: []
    });
});


router.post('/create_payment_intents', getStripePaymentIntent);

router.get('/check_user_subscription', async (req, res, next) => {
    try {
        await checkUserSubscriptionStatus();
        return res.status(200).json({
            status: true,
            message: "Updated all subscription status"
        })
    } catch (e) {
        return res.status(500).json({
            status: false,
            message: "Unable to update subscriptions"
        })
    }
});

module.exports = router;