const stripe = require('stripe')(process.env.STRIPE_TEST_SECRET_KEY);


module.exports = async (amount, currency) => {
    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: amount,
            currency: currency,
            payment_method_types: ['card'],
        });
        return Promise.resolve(paymentIntent);
    } catch (e) {
        // console.log(e)
        return Promise.resolve(e);
    }
}