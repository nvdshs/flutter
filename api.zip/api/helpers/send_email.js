require("dotenv").config();
const nodemailer = require('nodemailer');

module.exports = (email,subject,message,callback) => {
    let transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST, // 'server244.web-hosting.com',
        port: process.env.MAIL_PORT, //465,
        secure: true,
        auth: {
            user: process.env.MAIL_USER, // 'contact@thevenditt.com',
            pass:  process.env.MAIL_PASS  // 'thevenditt1st#'
        },
    });
    const mailOptions = {
        from: `"Angelic match makers" <${process.env.MAIL_USER}>`, 
        to: email,
        subject: subject || 'Hello there',
        html: message
    };
    transporter.sendMail(mailOptions, (err, response) => {
        if (err) {
            return callback(err);
        } else {
            return callback(null, response);
        }
    });
}
