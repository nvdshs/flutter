const fs = require('fs');

module.exports = function errorlog(err) {
    if (typeof err === 'object') {
        if (err.message) {
            fs.appendFileSync('error_log.txt', err.message + '\n\n');
        }
        if (err.stack) {
            fs.appendFileSync('error_log.txt', err.stack + '\n\n');
        }
    } else {
        fs.appendFileSync('error_log.txt', err + '\n\n');
    }
}