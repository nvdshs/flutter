const axios = require('axios');


module.exports = async (playerIds, title, content) => {
    try {
        const response = await axios.post(`https://onesignal.com/api/v1/notifications`, {
            "app_id": process.env.ONE_SIGNAL_APP_ID,
            // "included_segments": ["Subscribed Users"],
            "include_player_ids": [playerIds],
            "headings": { "en": title },
            "contents": { "en": content }
        }, {
            headers: {
                'Authorization': `Basic ${process.env.ONE_SIGNAL_API_KEY}`,
                'Content-Type': "application/json; charset=utf-8"
            }
        });
        return Promise.resolve(response.data);
    } catch (e) {
        // console.log(e)
        return Promise.reject(e.response);
    }
}