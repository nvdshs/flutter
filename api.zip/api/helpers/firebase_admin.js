var admin = require("firebase-admin");

var serviceAccount = require("../../config/google-services.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

module.exports = {

    addNotification: async (uid, type) => {
        uid = parseInt(uid);
        let userNotif = await admin.firestore().collection("notifications")
            .where("uid", "==", uid)
            .get();

        if (userNotif.empty) {
            let chat = type == 'chat';
            let notification = type == 'notification';
            await admin.firestore().collection("notifications").add({
                uid,
                chat,
                notification
            });
        } else {
            if (type == 'chat') {
                await admin.firestore()
                    .collection("notifications")
                    .doc(userNotif.docs[0].id)
                    .update({
                        chat: true,
                    });
            } else {
                await admin.firestore()
                    .collection("notifications")
                    .doc(userNotif.docs[0].id)
                    .update({
                        notification: true,
                    });
            }
        }
    },
    removeNotification: async (uid, type) => {
        uid = parseInt(uid);
        let userNotif = await admin.firestore().collection("notifications")
            .where("uid", "==", uid)
            .get();
        if (!userNotif.empty) {
            if (type == 'chat') {
                await admin.firestore()
                    .collection("notifications")
                    .doc(userNotif.docs[0].id)
                    .update({
                        chat: false,
                    });
            } else {
                await admin.firestore()
                    .collection("notifications")
                    .doc(userNotif.docs[0].id)
                    .update({
                        notification: false,
                    });
            }

        }
    }
}