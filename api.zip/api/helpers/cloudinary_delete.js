let cloudinary = require('cloudinary').v2;
cloudinary.config({
    cloud_name: 'geeky-bucket',
    api_key: '323847354164454',
    api_secret: '5p2gjB7S46KTu0ZvMCkGtxsIVYs'
});


module.exports = (publicId) => {
    return new Promise((resolve, reject) => {
        cloudinary.uploader.destroy(
            publicId,
            (error, result) => {
                if (result) {
                    resolve(result);
                } else {
                    reject(error);
                }
            }
        );
    });
};