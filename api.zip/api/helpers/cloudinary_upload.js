let cloudinary = require('cloudinary').v2;
cloudinary.config({ 
    cloud_name: 'geeky-bucket', 
    api_key: '323847354164454', 
    api_secret: '5p2gjB7S46KTu0ZvMCkGtxsIVYs' 
  });

let streamifier = require('streamifier');

module.exports = (req) => {
    return new Promise((resolve, reject) => {
        let stream = cloudinary.uploader.upload_stream(
          (error, result) => {
            if (result) {
              resolve(result);
            } else {
              reject(error);
            }
          }
        );
       streamifier.createReadStream(req.file.buffer).pipe(stream);
    });
};