require("dotenv").config();
// const fs = require('fs');
// const path = require('path');

//import the packages
const {
    genSaltSync,
    hashSync,
    compareSync
} = require("bcrypt");
const {
    sign
} = require("jsonwebtoken");
//import helpers
const validator = require('../helpers/validator');
const sendEmail = require('../helpers/send_email');
const cloudinaryUpload = require('../helpers/cloudinary_upload');
const cloudinaryDelete = require("../helpers/cloudinary_delete");
const verifyHtml = require('../templates/verify');
const forgotPasswordHtml = require('../templates/forgot_password');
//import services
const {
    getUserByEmail,
    getUserByToken,
    getUserById,
    emailExists,
    usernameExists,
    signupUser,
    forgotPassword,
    updatePasswordWithToken,
    updatePassword,
    verifyToken,
    verifyUser,
    searchUsers,
    randomUsers,
    searchUsersByPreference,
    updateName,
    updateDob,
    updateUsername,
    updateUserDetail,
    upgradeUserSubscription,
    addPhoto,
    fetchPhotos,
    deletePhoto,
    addProfilePhoto,
    addCoverPhoto,
    deleteCoverPhoto,
    deleteProfilePhoto,
    addUserNotification,
    fetchUserNotifications,
    deleteUserNotification,
    fetchUserProfile,
    friendsList,
    friendRequests,
    addFriend,
    acceptFriend,
    rejectFriend,
    deleteFriend,
    cancelFriendRequest,
    hasSentFriendRequest,
    youSentFriendRequest,
    isFriend,
    addChat,
    addImageChat,
    fetchRecentChats,
    fetchSingleChat,
    deleteChat,
    fetchPlayerIds,
    addPlayerId
} = require('../services/users');

const pushToUser = require('../helpers/push_notification');
const { addNotification } = require('../helpers/firebase_admin');


module.exports = {
    loginUser: (req, res) => {
        const body = req.body;
        if (!body.email || !body.password) {
            return res.status(400).json({
                success: false,
                message: "Fill in all fields"
            });
        }
        body.email = body.email.toLowerCase();
        getUserByEmail(body.email, (err, result) => {
            console.log(err);

            if (err) return res.status(503).json({
                success: false,
                message: "Unable to complete request, please try again"
            });
            if (!result)
                return res.status(404).json({
                    success: false,
                    message: "Email or password does not match our records",
                });
            if (result.is_verified == 'false') return res.status(401).json({
                success: false,
                message: "Your account is not verified"
            });
            const passwordValid = compareSync(body.password, result.password);
            if (passwordValid) {
                result.password = undefined;
                result.token = undefined;
                const jsonToken = sign({
                    result: result
                }, process.env.ACCESS_TOKEN_SECRET, {
                    expiresIn: "28d"
                });
                return res.status(200).json({
                    success: true,
                    message: "User record found",
                    data: result,
                    token: jsonToken
                });
            } else {
                return res.status(404).json({
                    success: false,
                    message: "Email or password does not match our records"
                });
            }
        });
    },
    createUser: async (req, res) => {
        const body = req.body;
        if (!body.name || !body.email ||
            !body.username || !body.password) {
            return res.status(400).json({
                success: false,
                message: "Fill in all fields"
            });
        }
        if (!validator.validateEmail(body.email)) {
            return res.status(422).json({
                success: false,
                message: "Email format not accepted"
            });
        }
        body.email = body.email.toLowerCase();
        body.username = body.username.toLowerCase();
        try {
            await emailExists(body.email);
            await usernameExists(body.username);
            const salt = genSaltSync(10);
            body.password = hashSync(body.password, salt);
            signupUser(body, (err, token) => {
                if (err) {
                    console.log(err);
                    return res.status(500).json({
                        success: false,
                        message: "Unable to process request, try again"
                    });
                }

                sendEmail(body.email, `Hello ${body.username}, welcome to AMM`, verifyHtml({
                    username: body.username,
                    token: token
                }), (err, data) => {

                })
                return res.status(201).json({
                    success: true,
                    message: "Your account has been created sucessfully",
                    data: token
                });
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: e.message
            });
        }

    },
    getUserDetails: async (user, req, res, next) => {

        try {
            let userDetails = await getUserById(user.id);
            if (!userDetails) return res.status(400).json({
                success: false,
                message: "User not found"
            });
            userDetails.password = undefined;
            userDetails.token = undefined;

            return res.status(200).json({
                success: true,
                message: "User record found",
                data: userDetails
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: 'Unable to process request, please try again!',
            });
        }

    },
    resendVerificationToken: (req, res) => {
        const body = req.body;
        if (!body.email) {
            return res.status(400).json({
                success: false,
                message: "Fill in all fields"
            });
        }
        body.email = body.email.toLowerCase();
        getUserByEmail(body.email, async (err, result) => {
            console.log(err);

            if (err) return res.status(503).json({
                success: false,
                message: "Unable to complete request, please try again"
            });
            if (!result)
                return res.status(404).json({
                    success: false,
                    message: "Email or password does not match our records",
                });
            if (result.is_verified == 'true') return res.status(400).json({
                success: false,
                message: "Your account is already verified"
            });

            let token = await forgotPassword(body.email);

            sendEmail(result.email, `Hello ${result.username}, you requested for a verification token`, verifyHtml({
                username: result.username,
                token: token
            }), (err, data) => {

            });

            return res.status(200).json({
                success: true,
                message: "Verification code has been sent to your email",
            });

        });
    },
    verifyToken: (req, res) => {
        const token = req.params.token;
        verifyToken(token, (err, result) => {
            console.log(result)
            if (err) return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
            if (!result) return res.status(400).json({
                success: false,
                message: "6-digit token is invalid"
            });
            verifyUser(result.email, token, (err, _) => {
                if (err) return res.status(500).json({
                    success: false,
                    message: "Unable to complete process"
                });
                return res.status(200).json({
                    success: true,
                    message: "You account has been verified"
                });
            })

        })
    },
    forgotPassword: async (req, res) => {
        const body = req.body;
        if (!body.email) return res.status(422).json({
            success: false,
            message: 'Email is required!',
        });
        try {

            getUserByEmail(body.email, async (err, result) => {
                console.log(err);

                if (err) return res.status(503).json({
                    success: false,
                    message: "Unable to complete request, please try again"
                });
                if (!result)
                    return res.status(404).json({
                        success: false,
                        message: "Email does not match our records",
                    });

                let token = await forgotPassword(body.email);
                // let emailsuccess = await sendEmail(body.email, forgotHtml(token));
                sendEmail(result.email, `Hello ${result.username}, you requested to change your password`, forgotPasswordHtml({
                    username: result.username,
                    token: token
                }), (err, data) => {

                });
                return res.status(200).json({
                    success: true,
                    message: 'Check your email for verification code to change your password',
                });

            });

        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: 'Unable to process request, please try again!',
            });
        }
    },
    updatePasswordWithToken: async (req, res) => {
        const body = req.body;
        if (!body.token || !body.password)
            return res.status(422).json({
                success: false,
                message: 'token and password is required!',
            });
        try {
            let result = await getUserByToken(body.token);
            if (!result) return res.status(404).json({
                success: false,
                message: 'No record was matched',
            });
            const salt = genSaltSync(10);
            body.password = hashSync(body.password, salt);

            await updatePasswordWithToken(body.token, result.email, body.password);
            return res.status(200).json({
                success: true,
                message: 'Your password has been updated successfully!',
            });

        } catch (e) {
            return res.status(500).json({
                success: false,
                message: 'Unable to complete process, try again',
            });
        }
    },
    updatePassword: async (user, req, res, next) => {
        const body = req.body;
        if (!body.oldpassword || !body.newpassword)
            return res.status(422).json({
                success: false,
                message: 'passwords are required!',
            });
        try {
            getUserByEmail(body.email, async (err, result) => {
                console.log(err);

                if (err) return res.status(503).json({
                    success: false,
                    message: "Unable to complete request, please try again"
                });
                if (!result)
                    return res.status(404).json({
                        success: false,
                        message: "User does not match our records",
                    });
                const passwordValid = compareSync(body.oldpassword, result.password);
                if (passwordValid) {
                    const salt = genSaltSync(10);
                    body.newpassword = hashSync(body.newpassword, salt);

                    await updatePassword(user.id, body.newpassword);
                    return res.status(200).json({
                        success: true,
                        message: 'Your password has been updated successfully!',
                    });

                } else {
                    return res.status(404).json({
                        success: false,
                        message: 'Old password is incorrect!',
                    });
                }

            });

        } catch (e) {
            return res.status(500).json({
                success: false,
                message: 'Unable to complete process, try again',
            });
        }
    },
    updateSignalId: async (user, req, res, next) => {
        const { signal_id } = req.body;
        if (!signal_id)
            return res.status(422).json({
                success: false,
                message: 'signal ID is required!',
            });
        try {
            await addPlayerId(signal_id, user.id);
            return res.status(200).json({
                success: true,
                message: 'Signal ID has been updated',
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: 'Unable to complete process, try again',
            });
        }
    },
    searchUsers: (user, req, res, next) => {
        const filter = req.params.search;
        searchUsers(user.id, filter, (err, results) => {
            if (err) return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
            return res.status(200).json({
                success: true,
                message: "Search results",
                data: results
            });
        })
    },
    randomUsers: (req, res, next) => {
        const { filter, lat, lng } = req.query;
        if (filter != 'random' && filter != 'location')
            return res.json({ status: false, message: 'Unable to resolve request' })
        if (filter == 'location' && (lat < 1 || lng < 1))
            return res.json({ status: false, message: 'Unable to resolve request 2' })
        randomUsers(5, filter, lat, lng, (err, results) => {
            if (err) return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
            return res.status(200).json({
                success: true,
                message: "users results",
                data: results
            });
        })
    },
    searchUsersByPreference: (user, req, res, next) => {
        const params = req.query;
        if (!params.gender || !params.min_age || !params.max_age || !params.doc || !params.city || params.ethnicity) {
            return res.status(422).json({
                success: false,
                message: "Please add all required params"
            });
        }
        params.uid = user.id;
        console.log(params)
        searchUsersByPreference(params, (err, results) => {
            if (err) return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
            return res.status(200).json({
                success: true,
                message: "Search results",
                data: results
            });
        })
    },
    fetchUserNotifications: async (user, req, res, next) => {

        try {
            const results = await fetchUserNotifications(user.id);
            return res.status(200).json({
                success: true,
                message: "Notifications fetched successfully",
                data: results
            });
        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    deleteUserNotification: async (user, req, res, next) => {
        const body = req.params;
        if (!body.id) {
            res.status(422).json({
                success: false,
                message: "No notification identifier was sent"
            });
        }
        try {
            await deleteUserNotification(user.id, body.id);
            return res.status(200).json({
                success: true,
                message: "Notification deleted",
                data: []
            });
        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    fetchUserProfile: async (user, req, res, next) => {
        const body = req.params;
        if (!body.uid) {
            res.status(422).json({
                success: false,
                message: "No user identifier was sent"
            });
        }
        try {
            var result = await fetchUserProfile(body.uid);
            if (!result) return res.status(404).json({
                success: false,
                message: "No user found",
                data: []
            });
            let sentFriendRequest = await hasSentFriendRequest(user.id, body.uid);
            let youSentRequest = await youSentFriendRequest(user.id, body.uid);
            let isfriend = await isFriend(user.id, body.uid);

            let userProfile = { ...result, sent_friend_request: sentFriendRequest, you_sent_request: youSentRequest, is_friend: isfriend };

            return res.status(200).json({
                success: true,
                message: "user profile found",
                data: userProfile
            });

        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
        }
    },
    /** 
    /* @description [Update Profile controllers]
    */
    updateName: async (user, req, res, next) => {
        const body = req.body;
        if (!body.name) {
            res.status(422).json({
                success: false,
                message: "Please add all required param(s)"
            });
        }
        try {
            const response = await updateName(user.id, body.name);

            console.log(response);
            user.fullname = response;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "Profile name updated successfully",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });

        }

    },
    updateDob: async (user, req, res, next) => {
        const body = req.body;
        if (!body.dob) {
            res.status(422).json({
                success: false,
                message: "Please add all required param(s)"
            });
        }
        try {
            const response = await updateDob(user.id, body.dob);

            console.log(response);
            user.dob = response;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "Date of birth updated successfully",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });

        }

    },
    updateUsername: async (user, req, res, next) => {
        const body = req.body;
        if (!body.username) {
            res.status(422).json({
                success: false,
                message: "Please add all required param(s)"
            });
        }
        body.username = body.username.toLowerCase();
        try {
            await usernameExists(body.username);
            const response = await updateUsername(user.id, body.username);

            console.log(response);
            user.username = response;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "Username updated successfully",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: e.message
            });

        }

    },
    updateUserDetails: async (user, req, res, next) => {
        const body = req.body;
        const type = req.params.type;
        let mustInclude = ['bio', 'username', 'fullname', 'gender', 'address', 'doctrine', 'likes', 'dislikes', 'church', 'city'];
        if (!body.data) {
            return res.status(422).json({
                success: false,
                message: "Please add all required param(s)"
            });
        }
        if (!mustInclude.includes(type)) {
            return res.status(422).json({
                success: false,
                message: "Type to update not found"
            });
        }

        try {
            if (type == 'username') {
                body.data = body.data.toLowerCase();
                await usernameExists(body.data);
            }
            await updateUserDetail(user.id, type, body.data);
            const newUser = await getUserById(user.id);
            if (!newUser) return res.status(500).json({
                success: false,
                message: "Unable to update profile, try again"
            });

            newUser.password = undefined;
            newUser.token = undefined;
            const jsonToken = sign({
                result: newUser
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: `${type} updated successfully`,
                data: newUser,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: e.message
            });

        }

    },
    upgradeUserSubscription: async (user, req, res, next) => {
        const { plan } = req.body;
        try {
            if (!plan) {
                return res.status(422).json({
                    success: false,
                    message: "Please select a plan"
                });
            }
            await upgradeUserSubscription(user.id, plan);
            const newUser = await getUserById(user.id);
            if (!newUser) return res.status(500).json({
                success: false,
                message: "Unable to update subscription, try again"
            });
            newUser.password = undefined;
            newUser.token = undefined;
            const jsonToken = sign({
                result: newUser
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: `Your subscription has been upgraded to premium`,
                data: newUser,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: "An error occurred, please try again"
            });

        }

    },
    /** 
    /* @description [Update Profile controllers]
    */

    uploadChatPhoto: async (user, req, res, next) => {
        try {
            let result = await cloudinaryUpload(req);
            return res.status(200).json({
                success: true,
                message: "Photo uploaded successfully",
                data: {
                    photo_url: result.secure_url,
                    public_id: result.public_id,
                    format: result.format
                },
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
        }
    },

    /** 
    /* @description [Photos controllers]
    */
    uploadPhoto: async (user, req, res, next) => {
        // let caption;
        // if (req.body.caption) caption = req.body.caption;

        try {
            let result = await cloudinaryUpload(req);
            let response = await addPhoto(user.id, result.secure_url, result.public_id);
            console.log(response);
            return res.status(200).json({
                success: true,
                message: "Photo uploaded successfully",
                data: {
                    id: response,
                    photo_url: result.secure_url,
                    public_id: result.public_id,
                    format: result.format
                },
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process"
            });
        }
    },
    fetchPhotos: async (user, req, res, next) => {
        const body = req.params;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "No user received"
        });

        try {
            const results = await fetchPhotos(body.userId);
            return res.status(200).json({
                success: true,
                message: "Photos fetched succeesfully",
                data: results
            });
        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    deletePhoto: async (user, req, res, next) => {
        const body = req.body;
        if (!body.photoId || !body.publicId) return res.status(422).json({
            success: false,
            message: "No photoId or publicId in your request"
        });

        try {
            let result = await cloudinaryDelete(body.publicId);
            await deletePhoto(user.id, body.photoId);
            console.log(result);
            return res.status(200).json({
                success: true,
                message: "Photo deleted successfully",
                data: result
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },

    // profile photo controllers

    uploadProfilePhoto: async (user, req, res, next) => {

        try {
            let result = await cloudinaryUpload(req);
            await addProfilePhoto(user.id, result.secure_url, result.public_id);
            console.log(result);

            user.profile_photo = result.secure_url;
            user.profile_photo_id = result.public_id;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "profile photo updated successfully",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: e.message
            });

        }
    },

    deleteProfilePhoto: async (user, req, res, next) => {
        const body = req.body;
        if (!body.publicId) return res.status(422).json({
            success: false,
            message: "No publicId in your request"
        });

        try {
            let result = await cloudinaryDelete(body.publicId);
            await deleteProfilePhoto(user.id);
            console.log(result);

            user.profile_photo = null;
            user.profile_photo_id = null;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "profile photo deleted",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },

    // cover photo controllers

    uploadCoverPhoto: async (user, req, res, next) => {

        try {
            let result = await cloudinaryUpload(req);
            await addCoverPhoto(user.id, result.secure_url, result.public_id);
            console.log(result);

            user.cover_photo = result.secure_url;
            user.cover_photo_id = result.public_id;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "cover photo updated successfully",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            console.log(e);
            return res.status(500).json({
                success: false,
                message: e.message
            });

        }
    },

    deleteCoverPhoto: async (user, req, res, next) => {
        const body = req.body;
        if (!body.publicId) return res.status(422).json({
            success: false,
            message: "No publicId in your request"
        });

        try {
            let result = await cloudinaryDelete(body.publicId);
            await deleteCoverPhoto(user.id);
            console.log(result);

            user.cover_photo = null;
            user.cover_photo_id = null;
            const jsonToken = sign({
                result: user
            }, process.env.ACCESS_TOKEN_SECRET, {
                expiresIn: "28d"
            });
            return res.status(200).json({
                success: true,
                message: "cover photo deleted",
                data: user,
                token: jsonToken
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },

    /**
     * FRIENDS CONTROLLERS
     * @description [no desc]
     * @params [sender_id, receiver_id, status]
     */
    friendsList: async (user, req, res, next) => {
        try {
            const results = await friendsList(user.id);
            return res.status(200).json({
                success: true,
                message: "Friends fetched successfully",
                data: results
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    friendRequests: async (user, req, res, next) => {
        try {
            const results = await friendRequests(user.id);
            return res.status(200).json({
                success: true,
                message: "Friend requests successfully",
                data: results
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    addFriend: async (user, req, res, next) => {
        const body = req.body;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to add as friend"
        });
        try {
            await addFriend(user.id, body.userId);
            await addUserNotification(user.fullname, "sent you a friend request", body.userId, user.id);
            let playerId = await fetchPlayerIds(body.userId);
            if (playerId) {
                pushToUser(playerId.signal_id, "New friend request", `${user.fullname} just sent you a friend request`)
                    .then(v => console.log(v))
                    .catch(e => console.log(e));
            }
            addNotification(body.userId, 'notification').then(v => console.log(v))
                .catch(e => console.log(e));

            return res.status(200).json({
                success: true,
                message: "Friend request sent successfully",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    acceptFriend: async (user, req, res, next) => {
        const body = req.body;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to accept friend request"
        });
        try {
            await acceptFriend(user.id, body.userId);
            await addUserNotification(user.fullname, "has accepted your friend request", body.userId, user.id);
            let playerId = await fetchPlayerIds(body.userId);
            if (playerId) {
                pushToUser(playerId.signal_id, "Now friends", `${user.fullname} has accepted your friend request`)
                    .then(v => console.log(v))
                    .catch(e => console.log(e));
            }
            addNotification(body.userId, 'notification').then(v => console.log(v))
                .catch(e => console.log(e));
            return res.status(200).json({
                success: true,
                message: "Friend request accepted",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    rejectFriend: async (user, req, res, next) => {
        const body = req.body;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to reject friend request"
        });
        try {
            await rejectFriend(user.id, body.userId);
            return res.status(200).json({
                success: true,
                message: "Friend request rejected",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    cancelFriendRequest: async (user, req, res, next) => {
        const body = req.body;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to cancel friend request"
        });
        try {
            await cancelFriendRequest(user.id, body.userId);
            return res.status(200).json({
                success: true,
                message: "Friend request cancelled",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
    deleteFriend: async (user, req, res, next) => {
        const body = req.body;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to delete friend"
        });
        try {
            await deleteFriend(user.id, body.userId);
            return res.status(200).json({
                success: true,
                message: "Friend deleted",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },

    /**
    * CHAT CONTROLLERS
    * @description [no desc]
    * @params [sender_id, receiver_id, status]
    */

    addToChat: async (req, res, next) => {
        const { sender, receiver, message } = req.body;
        if (!sender || !receiver || !message) return res.status(422).json({
            success: false,
            message: "sender and receiver not found"
        });
        try {
            let insertId = await addChat(sender, receiver, message);
            let playerId = await fetchPlayerIds(receiver);
            if (playerId) {
                pushToUser(playerId.signal_id, "New message", message)
                    .then(v => console.log(v))
                    .catch(e => console.log(e));
            }
            addNotification(receiver, 'chat').then(v => console.log(v))
                .catch(e => console.log(e));
            return res.status(200).json({
                success: insertId !== undefined,
                message: "message response",
                data: {
                    id: insertId
                }
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process, please try again"
            });
        }

    },

    addToChatImage: async (req, res, next) => {
        const { sender, receiver, message, public_id } = req.body;
        if (!sender || !receiver || !message || !public_id) return res.status(422).json({
            success: false,
            message: "sender and receiver not found"
        });
        try {
            let insertId = await addImageChat(sender, receiver, message, public_id);
            addNotification(receiver, 'chat').then(v => console.log(v))
                .catch(e => console.log(e));
            return res.status(200).json({
                success: insertId !== undefined,
                message: "message response",
                data: {
                    id: insertId
                }
            });
        } catch (e) {
            console.log(e)
            return res.status(500).json({
                success: false,
                message: "Unable to complete process, please try again"
            });
        }

    },

    fetchRecentChats: async (user, req, res, next) => {
        try {
            let results = await fetchRecentChats(user.id);
            return res.status(200).json({
                success: true,
                message: "recent chats",
                data: results
            })
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process, please try again"
            })
        }
    },

    fetchSingleChat: async (user, req, res, next) => {
        const body = req.params;
        let page = 1;
        if (!body.userId) return res.status(422).json({
            success: false,
            message: "Add a user to view chat history"
        });
        if (typeof req.query.page !== 'undefined') {
            body.currentPage = req.query.page;
            page = req.query.page;
        }
        try {
            let results = await fetchSingleChat(user.id, body);
            if (results.length < 1) {
                return res.status(200).json({
                    success: true,
                    message: "single chat record",
                    data: results,
                    currentPage: page,
                    hasData: false
                });
            }
            return res.status(200).json({
                success: true,
                message: "single chat record",
                data: results,
                currentPage: page,
                hasData: true
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process, please try again"
            })
        }
    },
    deleteSingleChat: async (user, req, res, next) => {
        const { chatId } = req.params;
        if (!chatId) return res.status(422).json({
            success: false,
            message: "No chat was selected"
        });
        try {
            const result = await deleteChat(chatId, user.id);
            if (!result) return res.status(400).json({
                success: false,
                message: "Unable to delete chat, try again",

            });
            return res.status(200).json({
                success: true,
                message: "Chat deleted",
            });
        } catch (e) {
            return res.status(500).json({
                success: false,
                message: "Unable to complete process. please try again"
            });
        }
    },
}