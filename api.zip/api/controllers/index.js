const createPaymentIntent = require('../helpers/create_payment_intent');

let controllers = {
    getStripePaymentIntent: async (req, res, next) => {
        const { amount, currency } = req.body;
        if (!amount || !currency) {
            return res.status(422).json({ message: 'Amount and currency is required' });
        }
        try {
            let result = await createPaymentIntent(amount, currency);
            return res.status(200).json(result);
        } catch (e) {
            return res.status(500).json({ message: 'failed to create payment intent' });
        }
    }
}

module.exports = controllers;