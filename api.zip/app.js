var createError = require('http-errors');
var http = require('http');
var express = require('express');
var helmet = require('helmet');
var path = require('path');
var cookieParser = require('cookie-parser');
var socket = require('socket.io');
// var logger = require('morgan');
// var session = require('express-session');
// var flash = require('connect-flash');
var cron = require('node-cron');

require("dotenv").config();

//import apis
var usersApi = require('./api/routes/users');
var indexApi = require('./api/routes/index');
// var othersApi = require('./api/other/routes');


let pingSocketServer = require('./api/helpers/ping_socket_server');
let { checkUserSubscriptionStatus } = require('./api/services/users');

cron.schedule('0 0 * * *', function () {
  pingSocketServer().then(v => console.log(v)).catch(e => console.log(e));
  checkUserSubscriptionStatus().then(res => console.log(res)).catch(err => console.log(err));
});
//   {
//     scheduled: true,
//     timezone: "Africa/Lagos"
//   }
// );

const app = express();

// app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({
  extended: false,
  limit: "50mb"
}));
app.use(cookieParser());
// app.use(express.static(path.join(__dirname,'build')));
// app.use(express.static(path.join(__dirname, 'public')));

//**
/*APIS
 **/
//grant CORS permissions
app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type,Accept');
  if (req.method === "OPTIONS") {
    res.header("Access-Control-Allow-Methods", "PUT,POST,DELETE");
    res.status(200).json({});
  }
  next();
})

app.use(helmet());

//api routes
app.use('/api/v1/users', usersApi);
app.use('/api/v1/', indexApi);
//end of api routes


// catch api 404 and forward to error handler
app.use('/api/v1', function (req, res, next) {
  var err = new Error("Not found");
  err.status = 404;
  next(err);
});

// api error handler
app.use('/api/v1', function (err, req, res, next) {
  // display the error page
  res.status(err.status || 500);
  res.json({
    status: false,
    success: err.status,
    message: err.message,
    data: [],
  });
});

///////______Start of global error handler_________/////////
// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  res.redirect("https://myammapp.com");
  // res.sendFile(path.join(__dirname + '/index.html'));
});

/**
 * Get port from environment and store in Express.
 */

// var port = normalizePort(process.env.APP_PORT || '3001');
var port = normalizePort(process.env.PORT || '3000');
app.set('port', port);


var server = http.createServer(app);

/* ========== controller for the web socket ========== */
// setup the web socket
let io = socket(server);

// create a connection to the socket

require('./api/sockets/private_message')(io);

/* ========== controller for the web socket ========== */


/**
 * Listen on provided port, on all network interfaces.
 */

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);



// module.exports = app;
/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string' ?
    'Pipe ' + port :
    'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
  console.log("port ", port)
  var addr = server.address();
  var bind = typeof addr === 'string' ?
    'pipe ' + addr :
    'port ' + addr.port;
  console.log('Listening on ' + bind);
}

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}