
let pingSocketServer = require('./api/helpers/ping_socket_server');

let checkUserSubscriptionStatus = require('./api/helpers/check_subscription');

 pingSocketServer().then(v => console.log(v)).catch(e => console.log(e));
 
 checkUserSubscriptionStatus().then(res => console.log(res)).catch(err => console.log(err));